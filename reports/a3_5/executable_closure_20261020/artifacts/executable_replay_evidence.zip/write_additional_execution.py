from pathlib import Path
import json
R=Path('D:/Projekte/Code/FlexPlan_A35_EXEC_RUN');A='D:/Projekte/Code/FlexPlan_A35_EXEC_REVIEW/reports/a3_5/executable_closure_20261020';B='D:/Projekte/Code/FlexPlan_A35_EXEC_BASELINE'
items=[]
def add(id,log,exit,command,meaning):items.append(dict(id=id,log=log,actual_process_exit=exit,command=command,cwd=B,semantic_result=meaning,log_present=(R/log).is_file()))
J=['julia','+1.10.11','--startup-file=no','--project=.'];P='C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
add('environment','environment.log',0,J+['-e','using Pkg; Pkg.status(); Pkg.instantiate(); using JuMP, HiGHS, Clarabel, Pajarito'], 'instantiated_pinned_environment_no_tracked_changes')
for attempt,exit,meaning,out in [('01',1,'Clarabel_constant_singular_PSD_chordal_index_error',str(R)),('02',1,'audit_has_values_incorrectly_accepted_infeasibility_certificate',str(R/'moi_final')),('03',0,'42_passed_actual_MOI_and_boundaries',str(R/'moi_final03'))]:add('independent_moi_'+attempt,'independent_moi_attempt'+attempt+'.log',exit,J+[A+'/independent_jump_moi_audit.jl',out],meaning)
for attempt,exit,meaning,out in [('01',1,'audit_docstring_before_using_error',str(R)),('02',1,'audit_optimal_G0_seed_missing_for_event_case',str(R)),('03',0,'nine_fixed_pairs_and_two_diagnostic_native_scaling_variants',str(R/'integer_final'))]:add('integer_b1_'+attempt,'integer_b1_attempt'+attempt+'.log',exit,J+[A+'/independent_integer_b1_audit.jl',B,out],meaning)
add('integer_best','integer_best.log',0,J+[A+'/independent_integer_b1_audit.jl',B,str(R/'integer_best'),'fixed_only_best_historical_seed'],'nine_best_seed_case_pairs_freshly_solved_not_global_certification')
add('exact_native','b1_exact_native.log',0,J+[A+'/b1_exact_native_repro.jl',B,str(R)],'native_INFEASIBLE_is_observed_failure_not_PASS')
add('exact_full_transfer','b1_transfer.log',0,J+[A+'/b1_transfer_full_witness.jl',str(R)],'native_full_original_integer_model_feasible_at_7.515349e-12')
add('bridged_attempt01','b1_exact_bridged.log',1,J+[A+'/b1_exact_native_repro.jl',B,str(R)],'audit_direct_optimizer_index_failed_for_negative_bridged_variable_index')
add('bridged_attempt02','b1_exact_bridged_attempt02.log',0,J+[A+'/b1_exact_native_repro.jl',B,str(R)],'actual_affine_variable_bridge_transfer_verified_cone_distance_8.835e-11')
add('MOSEK','mosek_native24.log',-1,['C:/Program Files/Mosek/11.0/tools/platform/win64x86/bin/mosek.exe','-r','-d','MSK_IPAR_NUM_THREADS','1','-d','MSK_DPAR_MIO_MAX_TIME','120','-jsolo',str(R/'mosek_native24_solution.json'),str(R/'native24.cbf')],'actual_native_model_read_license_error_1001_no_solve')
for name,exit,meaning in [('domain_mutations.log',1,'strict_gate_correctly_rejected_parametric_unqualified_input_initial_probe'),('domain_mutations_attempt02.log',0,'16_passed_strict_rejection_plus_diagnostic_domain_mutations')]:add(name,name,exit,J+[A+'/independent_domain_mutations.jl',str(R),B],meaning)
for name,exit,meaning in [('linear_certificates.log',1,'AffExpr_object_isapprox_comparison_failure_order_roundoff'),('linear_certificates_attempt02.log',0,'34_passed_explicit_coefficient_and_constant_comparison')]:add(name,name,exit,J+[A+'/independent_linear_certificates.jl',B,str(R)],meaning)
for name,exit,meaning in [('independent_metrics_attempt01.log',1,'audit_python_parenthesis_syntax'),('independent_metrics_attempt02.log',0,'semantic_comparison_failure_source_ledger_order_687_rows'),('independent_metrics_attempt03.log',0,'all_124_historical_metrics_compared_no_differences'),('independent_metrics_final.log',0,'all_124_historical_and_fresh_metrics_compared_no_differences')]:add(name,name,exit,[P,A+'/independent_metric_audit.py',str(R),B],meaning)
add('oracle_final','oracle_final.log',0,[P,A+'/independent_reference_oracle.py',str(R),B],'exact_rational_and_1299_raw_states_232_solutions')
add('integer_summary_final','integer_summary_final.log',0,[P,A+'/independent_integer_summary.py',str(R),B],'nine_case_cost_matrix_and_signed_bound_audit')
add('unit_tests','fixed_units.log',0,J+[A+'/test_metric_units.jl','D:/Projekte/Code/FlexPlan_A35_EXEC_REVIEW'],'4_passed')
add('fixed_export','fixed_metric_reexport.log',0,J+['scripts/paper_a/ap3.jl','evaluate_strength_metrics',str(R/'matrices'),str(R/'metrics_unit_fix')],'cwd_is_fix_checkout_e1e0756_exported_61272_records')
items[-1]['cwd']='D:/Projekte/Code/FlexPlan_A35_EXEC_REVIEW'
for id,action,input,output in [('unknown','unknown_action','suite','negative_output'),('missing','reconstruct_strength_matrices','missing_input','negative_missing_output'),('overwrite','reconstruct_strength_matrices','suite','matrices')]:add('negative_'+id,'negative_cli_'+id+'.log',1,J+['scripts/paper_a/ap3.jl',action,str(R/input),str(R/output)],'expected_rejection')
add('first_finalizer_wrapper','finalize_replay.log',1,['&',str(R/'finalize_replay.ps1')],'PowerShell_script_invocation_in_existing_shell; all_individual_checks_completed_last_expected_negative_exit_leaked_wrapper_code; fixed_explicit_final_exit_0_in_published_script')
add('final_artifact_verification','final_artifact_verification.log',0,[P,str(R/'verify_and_package.py'),str(R),A,B,'verify'],'all_61272_rows_equal_except_3_units_and_version;171_export_hashes_equal')
assert all(x['log_present'] for x in items)
(R/'additional_execution.json').write_text(json.dumps(items,indent=2));print('additional_process_records',len(items))
