---
title: Integrated Voltage Stability, System Strength, Dynamic Stability, and Planning Formulations
document_type: dissertation_chapter
cluster: C2A
date: 2026-08-09
rewrite_mode: preservation_controlled_correction
reviewed_rewrite_sha: baa2f868ffc11fa7312d427af01ee3bc95bdbc8c
independent_review_commit: 3c3cf3cd1fa560abe600a8527a3d00ebf9bbaf45
scientific_freeze_commit: 2c2fce769b2ed6ffd4f1ced60c0798776acccc93
implementation_verified: false
numerical_validation_complete: false
production_readiness: not_established
scientific_closure: not_adjudicated_by_writer
---

# Integrated Voltage Stability, System Strength, Dynamic Stability, and Planning Formulations

## Abstract

Converter-dominated generation and transmission expansion planning requires several distinct notions of electrical security to be represented without conflating their physical or mathematical domains. This chapter reconstructs the C2A scientific formulation from the physical AC network upward. It begins with device incidence and the complex nodal admittance matrix, derives nonlinear AC equilibrium in polar and rectangular coordinates, derives the complete power-flow Jacobian and its reduced \(Q\)-\(V\) Schur complement, and then separates nonlinear static-voltage stability from system-strength screening and from dynamic/control stability. The system-strength layer develops the exact generalized-eigenvalue coordinate G0, local diagonal and row-impedance burdens, the sufficient G1/G2/G3 certificates, M1/M2, ordinary and generalized Schur complements, and exact Woodbury/Neumann identities with bounded finite truncation. The dynamic layer starts from a heterogeneous DAE, treats descriptor linearization before regular reduction, and retains the declared third-order C2A specialization. The common-DAE derivative objects are now explicitly distinguished from the historically retained isolated-theorem objects: \(H^{\mathrm{DAE}}\) is not identified with \(H^{(034)}\), and the common sine/skew cross-channel structure \(\Omega^{\mathrm{cross}}\) is not identified with \(\Omega^{(035)}\). The planning layer distinguishes installed, available, online, and dispatched quantities and separates energy-duration weighting from event-counted startup/shutdown costs. All frozen theorem IDs T-C2A-001 through T-C2A-040, their adjudicated verdicts and directions, accepted counterexamples, singular/range qualifications, and unresolved mappings are preserved. In particular, \(G0\not\Rightarrow M0\), a system-strength threshold does not imply nonlinear voltage-collapse security, and stable isolated dynamic blocks do not imply stability of the full coupled system. Implementation correctness and numerical validation remain Track-C questions.

# Part I — Scope, scientific status, and common mathematical language

## 1. Motivation, research questions, and claim boundaries

The central scientific difficulty is that several quantities discussed under *voltage stability*, *short-circuit strength*, *grid strength*, or *dynamic voltage stability* are defined on different mathematical objects. A dissertation-level formulation therefore answers separate questions.

1. **Physical AC system and equilibrium.** Which buses, branches, sources, converters, loads, storage devices, transformers, shunts, filters, references, limits, and controls define the nonlinear equilibrium?
2. **Static voltage stability.** Along a declared stress direction, where does a nonlinear equilibrium branch lose regularity or change active set, and how are full-Jacobian singularity, reduced \(Q\)-\(V\) singularity, CPF, saddle-node bifurcation, and limit-induced events related?
3. **System strength.** Given a declared lossless/reference-treated stiffness object and declared exposure, which generalized-eigenvalue or impedance quantities are exact, and which tractable certificates are only sufficient?
4. **Dynamic/control stability.** For a declared DAE and operating point, which finite modes, eigenvalues, Lyapunov inequalities, small-gain conditions, passivity/KYP relations, or impedance/return-ratio tests establish local stability?
5. **Planning tractability.** Which physical/scientific objects become investment-, commitment-, dispatch-, topology-, scenario-, or contingency-dependent, and what optimization class follows?
6. **Validation and implementation.** Which equations are frozen science and which repository/data/solver claims still require Track-C equation-to-code and numerical validation?

The exposition hierarchy is

\[
\boxed{
\text{scientific status and notation}
\rightarrow\text{physical AC system}
\rightarrow\text{nonlinear equilibrium and linearization}
\rightarrow\text{static voltage stability}
\rightarrow\text{system-strength mathematics}
\rightarrow\text{dynamic/control stability}
\rightarrow\text{planning embedding}
\rightarrow\text{validation}.}
\]

It is not an implication graph:

\[
\boxed{\text{static voltage stability}\not\equiv\text{system strength}\not\equiv\text{small-signal stability}.}
\]

No universal scalar stability index is claimed.

## 2. Scientific-status taxonomy

A **definition** introduces an object. An **exact identity** is an algebraic equality on the stated domain. An **exact equivalence** establishes both logical directions. A **necessary condition** follows from the target property; a **sufficient condition** implies it. An **exact reformulation** preserves the feasible set while changing representation. A **conservative inner certificate** implies a target condition but may reject valid target points. An **outer relaxation** contains the target set and may admit invalid target points. A **numerical approximation** replaces an exact object and requires an error domain. A **screening metric** supports ranking/filtering in a declared model. A **post-processing metric** is recomputed after optimization and is not necessarily an optimization constraint. A **rejected implication** has an accepted counterexample. An **unresolved relation** lacks evidence for a theorem or counterexample.

Scientific status is distinct from computational class. A matrix inequality is an LMI only if every matrix coefficient is affine in the actual optimization variables.

## 3. Sets, dimensions, units, bases, and sign conventions

Let

- \(\mathcal N=\{1,\ldots,N_b\}\): retained AC buses;
- \(\mathcal E\): undirected AC branches/transformers represented in the retained topology;
- \(\mathcal K\): physical devices and \(\mathcal K_i\) the devices at bus \(i\);
- \(\mathcal K_i^{SG},\mathcal K_i^{GFM},\mathcal K_i^{GFL},\mathcal K_i^{load},\mathcal K_i^{sh}\): bus-local device classes;
- \(\mathcal X\), \(\mathcal Z\): differential and algebraic coordinates;
- \(y\in\mathcal Y\): planning stage/year;
- \(d\in\mathcal D_y\): representative period;
- \(h\in\mathcal H_d\): snapshot within period;
- \(\omega\in\Omega\): scenario;
- \(c\in\mathcal C\): contingency/security state;
- \(m\in\mathcal M\): maintenance/outage state where used.

When a compact operating index \(t\) is used later, it is **only shorthand for the relevant intra-period operating coordinate**, normally \(t=(d,h)\) after \(y,\omega,c\) have been fixed or suppressed. It does not introduce a second independent chronology. Where ambiguity would arise, the full \((y,d,h,\omega,c)\) index is retained.

All per-unit quantities require a declared system MVA base and bus voltage bases. Unless a device equation states otherwise, positive \(P_i,Q_i\) denote injection into the AC network. Current \(I_i\) is positive into the network under the same nodal convention. Voltage-angle differences are \(\theta_{ij}=\theta_i-\theta_j\). One angle reference is removed or fixed per connected island.

## 4. Matrix spaces, orders, classes, and master assumptions

\(\mathbb S^n\), \(\mathbb S_+^n\), and \(\mathbb S_{++}^n\) denote real symmetric, PSD, and PD matrices. Loewner order and componentwise order are different:

\[
\boxed{A\succeq B\not\equiv A\ge B.}
\]

A Z-matrix has nonpositive off-diagonal entries. A nonsingular M-matrix is inverse positive, \(A^{-1}\ge0\) componentwise. For SPD matrices, \(A\succeq B\succ0\Rightarrow A^{-1}\preceq B^{-1}\) is a Loewner-order result; ordered nonsingular M-matrix inverse monotonicity is a different componentwise theorem.

A symmetric matrix is diagonally dominant (DD) when \(a_{ii}\ge\sum_{j\ne i}|a_{ij}|\), and scaled diagonally dominant (SDD) when a positive diagonal congruence scaling is DD. The closed SDD cone includes singular boundary points. Reducibility, range, nullspace, the Moore-Penrose pseudoinverse, and finite generalized eigenvalues are invoked explicitly below.

The theorem-critical assumptions are repeated locally: symmetry where Loewner/eigenvalue results are used; Z-sign structure for M-matrix arguments; PD before ordinary inversion; inverse positivity before componentwise multiplication by an inverse; nonnegative exposure before burden comparisons; fixed positive scaling for G2; complete edge coverage for G3; fixed active set for local PF Jacobians; descriptor regularity for finite-mode conclusions; and a fixed complete state matrix for ordinary Lyapunov equivalence.

# Part II — Complete physical AC system

## 5. \(N_b\)-bus topology and device incidence

Let \(C\in\{0,1\}^{N_b\times|\mathcal K|}\) be device-to-bus incidence, \(C_{ik}=1\) if device \(k\) is connected to bus \(i\). Several heterogeneous devices may share one bus. Counts of SG/GFM/GFL devices are therefore not a physical network model by themselves.

For every represented device class the model declares rating, own or converted system base, connection voltage, transformer/filter/source impedance where represented, control class, status, \(P/Q/S/I\) capability, and aggregation assumptions. Exact circuit aggregation, equivalent-source reduction, and planning aggregation are distinct. A GFM label is a control/interface class; it is not itself an admittance value, fault-current model, or complete dynamic model.

## 6. Physical nodal admittance construction

The parent equation is

\[
\boxed{I=Y_{\mathrm{bus}}V},\qquad Y_{\mathrm{bus}}=G+jB^{\mathrm{phys}}.
\]

For a reciprocal series branch \(i-j\) with series admittance \(y_{ij}\) and no tap, the primitive stamp adds \(+y_{ij}\) to \(Y_{ii},Y_{jj}\) and \(-y_{ij}\) to \(Y_{ij},Y_{ji}\). Half line charging, when used, enters terminal diagonals. A fixed shunt \(y_i^{sh}\) enters \(Y_{ii}\).

For an off-nominal transformer with complex tap \(a=\tau e^{j\phi}\) at the from side and series admittance \(y\), a conventional stamp is

\[
Y_{ff}\mathrel{+}=\frac{y+y_{sh,f}}{|a|^2},\quad
Y_{ft}\mathrel{+}=-\frac{y}{a^*},\quad
Y_{tf}\mathrel{+}=-\frac{y}{a},\quad
Y_{tt}\mathrel{+}=y+y_{sh,t},
\]

with charging convention declared by the network model. Phase shifting can destroy real symmetry. Filters/source interfaces are stamped by their circuit models; disconnected components contribute no in-service stamp; each island is reference-treated separately.

The no-double-counting rule is structural: source impedance, transformer leakage, filters, line charging, passive/switched shunts, synchronous condensers, converter-equivalent strengthening, and external reactive corrections are each represented once.

## 7. Augmented source-terminal circuit

Before source-node elimination,

\[
\begin{bmatrix}I_{\mathrm{int}}\\I_{\mathrm{bus}}\end{bmatrix}
=
\begin{bmatrix}Y_{ii}&Y_{ib}\\Y_{bi}&Y_{bb}\end{bmatrix}
\begin{bmatrix}E_{\mathrm{int}}\\V\end{bmatrix}
+\begin{bmatrix}0\\I_{\mathrm{inj}}\end{bmatrix}.
\]

Multiple sources may connect to one terminal through distinct interfaces. Thévenin/Norton equivalence is a circuit statement, not automatically a controller/dynamic equivalence.

A frozen one-to-one stiffness specialization is

\[
\mathcal B_{ext}=
\begin{bmatrix}\mathcal B_s&-\mathcal B_s\\-\mathcal B_s&\mathcal B_{net}+\mathcal B_s\end{bmatrix},\qquad \mathcal B_s\succ0.
\]

## 8. Positive network-stiffness specialization

Under the reciprocal lossless/loss-neglected reference-treated assumptions used by the frozen matrix theorems,

\[
\boxed{\mathcal B=-\Im(Y_{\mathrm{bus}})},\qquad
\mathcal B=\mathcal B^\top,\quad \mathcal B_{ij}\le0\;(i\ne j).
\]

These are predicates of the C2A stiffness class, not identities for every AC model. In particular,

\[
\boxed{B^{\mathrm{phys}}\neq\mathcal B\neq J_{QV}\neq J_{QV}^{red}.}
\]

# Part III — Nonlinear AC equilibrium and linearized power flow

## 9. Nonlinear AC power flow

For \(V_i=|V_i|e^{j\theta_i}\), \(I_i=\sum_jY_{ij}V_j\), \(S_i=P_i+jQ_i=V_iI_i^*\), and \(\theta_{ij}=\theta_i-\theta_j\),

\[
\boxed{P_i=|V_i|\sum_j|V_j|\left[G_{ij}\cos\theta_{ij}+B^{\mathrm{phys}}_{ij}\sin\theta_{ij}\right]},
\]

\[
\boxed{Q_i=|V_i|\sum_j|V_j|\left[G_{ij}\sin\theta_{ij}-B^{\mathrm{phys}}_{ij}\cos\theta_{ij}\right]}.
\]

Network injections equal the algebraic sum of in-service generation, conversion, storage, load/flexibility, shunts, and other declared devices under the active bus/control equations.

## 10. Rectangular formulation, bus/control types, and active sets

Let \(V_i=e_i+jf_i\). Then

\[
I_i^R=\sum_j(G_{ij}e_j-B^{\mathrm{phys}}_{ij}f_j),\qquad
I_i^I=\sum_j(B^{\mathrm{phys}}_{ij}e_j+G_{ij}f_j),
\]

\[
\boxed{P_i=e_iI_i^R+f_iI_i^I},\qquad
\boxed{Q_i=f_iI_i^R-e_iI_i^I}.
\]

Slack, PQ, PV, and converter-controlled buses use different algebraic equations. When reactive, voltage, apparent-power, or current limits bind, the active equation set changes; a pre-switch Jacobian is not silently reused.

## 11. Full AC power-flow Jacobian

For a fixed active equation set,

\[
\begin{bmatrix}\Delta P\\\Delta Q\end{bmatrix}
=
\underbrace{\begin{bmatrix}J_{P\theta}&J_{PV}\\J_{Q\theta}&J_{QV}\end{bmatrix}}_{J_{PF}}
\begin{bmatrix}\Delta\theta\\\Delta |V|\end{bmatrix}.
\]

For \(i\ne j\),

\[
\frac{\partial P_i}{\partial\theta_j}=|V_i||V_j|(G_{ij}\sin\theta_{ij}-B^{\mathrm{phys}}_{ij}\cos\theta_{ij}),
\]
\[
\frac{\partial Q_i}{\partial\theta_j}=-|V_i||V_j|(G_{ij}\cos\theta_{ij}+B^{\mathrm{phys}}_{ij}\sin\theta_{ij}),
\]
\[
\frac{\partial P_i}{\partial|V_j|}=|V_i|(G_{ij}\cos\theta_{ij}+B^{\mathrm{phys}}_{ij}\sin\theta_{ij}),
\]
\[
\frac{\partial Q_i}{\partial|V_j|}=|V_i|(G_{ij}\sin\theta_{ij}-B^{\mathrm{phys}}_{ij}\cos\theta_{ij}).
\]

The diagonal terms are

\[
\frac{\partial P_i}{\partial\theta_i}=-Q_i-B^{\mathrm{phys}}_{ii}|V_i|^2,
\qquad
\frac{\partial Q_i}{\partial\theta_i}=P_i-G_{ii}|V_i|^2,
\]
\[
\frac{\partial P_i}{\partial|V_i|}=\frac{P_i}{|V_i|}+G_{ii}|V_i|,
\qquad
\frac{\partial Q_i}{\partial|V_i|}=\frac{Q_i}{|V_i|}-B^{\mathrm{phys}}_{ii}|V_i|.
\]

The assembled Jacobian dimensions depend on reference removal, bus/control equations, active limits, and islands. Every block is an operating-point derivative, not a fixed admittance matrix.

## 12. Reduced \(Q\)-\(V\) Jacobian

If \(J_{P\theta}\) is nonsingular, elimination gives

\[
\boxed{J_{QV}^{red}=J_{QV}-J_{Q\theta}J_{P\theta}^{-1}J_{PV}}.
\]

This is an exact local Schur complement under the fixed active set. If \(J_{P\theta}\) is singular, the ordinary reduction is invalid; a pseudoinverse cannot be substituted without the corresponding generalized/descriptor range conditions.

# Part IV — Static voltage stability

## 13. Equilibrium families and stress directions

After the explicit AC equations are defined, use

\[
F(x,\lambda,u)=0,
\]

where \(\lambda\) is a declared stress/loading parameter and \(u\) contains controls/discrete states. Local regularity is not a global solvability theorem.

## 14. Continuation power flow

CPF augments the equilibrium equations with a continuation condition, predicts a tangent step, and corrects to the equilibrium manifold. Pseudo-arclength parameterization remains usable through an ordinary fold where \(\lambda\) alone is not a valid local parameter. Active-limit switching changes the algebraic equations. CPF therefore computes a nonlinear equilibrium branch; a system-strength coordinate does not determine CPF margin.

## 15. Jacobian singularity and bifurcation structure

**T-C2A-031.** Jacobian singularity corresponds to a regular saddle-node only under the additional regularity assumptions: simple zero eigenvalue, valid loading direction, transversality/nondegeneracy, fixed active equation set at the event, and no earlier unmodelled switching. While \(J_{P\theta}\) is nonsingular, full-Jacobian and reduced-\(Q\)-\(V\) singularity are equivalent by ordinary Schur complement.

## 16. Static diagnostics, sensitivities, and reserve

**T-C2A-029.** Inverse \(Q\)-\(V\) sensitivity is exact only for the local linearized model at a regular operating point.

**T-C2A-030.** It is not a nonlinear CPF-collapse certificate without a separately proved nonlinear relation.

Eigenvalues, singular values, modal/participation quantities, inverse sensitivities, and reactive reserve are distinct. For nonsymmetric/nonnormal Jacobians, eigenvalue distance from zero and minimum singular value need not coincide. Reactive reserve can be exhausted before a smooth fold.

**T-C2A-032.** SCR/gSCR-type thresholds are model-specific screening indices outside their derivation model. Thus

\[
\boxed{\text{system-strength threshold}\not\Rightarrow\text{nonlinear voltage-collapse security}}.
\]

# Part V — System-strength mathematics and certificates

## 17. Exact Schur hierarchy and network reductions

### 17.1 T-C2A-001 — exact elimination and ordinary PSD Schur equivalence

For symmetric

\[
M=\begin{bmatrix}A&B\\B^\top&C\end{bmatrix},
\]

if \(C\) is nonsingular, algebraic elimination yields \(A-BC^{-1}B^\top\). If \(C\succ0\),

\[
\boxed{M\succeq0\iff A-BC^{-1}B^\top\succeq0}.
\]

Algebraic elimination and PSD equivalence are distinct statements.

### 17.2 Generalized Schur complement

For \(C\succeq0\),

\[
\boxed{M\succeq0\iff (I-CC^\dagger)B^\top=0,\quad A-BC^\dagger B^\top\succeq0}.
\]

The first condition is \(\operatorname{range}(B^\top)\subseteq\operatorname{range}(C)\) and is indispensable.

### 17.3 T-C2A-002 — parallel sum

For \(B_n,B_d\succ0\),

\[
\boxed{B_d-B_d(B_n+B_d)^{-1}B_d=(B_n^{-1}+B_d^{-1})^{-1}}.
\]

No commutativity is required. **T-C2A-003** retains the historical sign-duality interpretation while leaving original source-symbol mapping unresolved where exact source definitions are unavailable.

### 17.4 T-C2A-004 — zero-exposure elimination

With

\[
\mathcal B-\alpha S=
\begin{bmatrix}\mathcal B_{aa}-\alpha S_a&\mathcal B_{az}\\\mathcal B_{za}&\mathcal B_{zz}\end{bmatrix},
\]

if \(\mathcal B_{zz}\succ0\),

\[
\boxed{\mathcal B-\alpha S\succeq0\iff
\mathcal B_{aa}-\mathcal B_{az}\mathcal B_{zz}^{-1}\mathcal B_{za}-\alpha S_a\succeq0}.
\]

If \(\mathcal B_{zz}\) is singular, the generalized range condition is mandatory. Zero-exposure buses cannot be deleted naively.

## 18. Exposure families and threshold semantics

Define separately

\[
S^{nom}=\operatorname{diag}(p^{nom}),\quad S^{on}=\operatorname{diag}(p^{on}),\quad
S^{op}=\operatorname{diag}(p^{op}),\quad S^I=\operatorname{diag}(i^{cap}).
\]

Installed/nameplate, online-nameplate, operating-power, and current-capability exposure answer different questions. Their units/base and voltage normalization must be compatible with the stiffness object and threshold.

## 19. G0 generalized-eigenvalue coordinate

For \(S\succ0\),

\[
\gamma^{GE}=\lambda_{min}(S^{-1/2}\mathcal BS^{-1/2}).
\]

**T-C2A-005.** For symmetric \(\mathcal B\),

\[
\boxed{\gamma^{GE}\ge\alpha\iff\mathcal B-\alpha S\succeq0}.
\]

**T-C2A-006.** For singular \(S\succeq0\), use the smallest finite generalized eigenvalue of \((\mathcal B,S)\), equivalently the exact zero-exposure reduction when its Schur assumptions hold. The neutral name \(\gamma^{GE}\) is used unless a literature equation-level match has been verified.

## 20. Local metric and M0

Let \(\mathcal B\succ0\), \(Z=\mathcal B^{-1}\), and \(p_i>0\). Define

\[
\rho_i^{diag}=\frac1{Z_{ii}p_i},\qquad \rho_i^{Zp}=\frac1{(Zp)_i}.
\]

**T-C2A-007.**

\[
\boxed{\rho_i^{diag}\ge\alpha\iff\mathcal B-\alpha p_ie_ie_i^\top\succeq0}.
\]

**T-C2A-008.** G0 implies every local diagonal condition for diagonal nonnegative exposure.

If \(Z\ge0\) and \(p\ge0\), exact M0 is

\[
\boxed{Zp\le\alpha^{-1}\mathbf1}.
\]

**T-C2A-009.** M0 implies every local diagonal threshold because \((Zp)_i\ge Z_{ii}p_i\).

**T-C2A-010 — G0 does not imply M0.** With

\[
\mathcal B=\begin{bmatrix}1&-1/2\\-1/2&1\end{bmatrix},\quad
p=\begin{bmatrix}1/4\\2/3\end{bmatrix},\quad\alpha=1,
\]

\(\mathcal B-\operatorname{diag}(p)\succeq0\), but

\[
Zp=\begin{bmatrix}7/9\\19/18\end{bmatrix},
\]

so

\[
\boxed{G0\not\Rightarrow M0}.
\]

With the same \(\mathcal B\) and \(p=(3/4,3/4)^\top\), all local diagonal tests hold while \(\mathcal B-\operatorname{diag}(p)\) has eigenvalue \(-1/4\), so local conditions do not imply G0.

## 21. G1 and fixed G2

Let \(M=\mathcal B-\alpha S\) be a symmetric Z-matrix.

**T-C2A-011 (G1).** If \(M\mathbf1\ge0\), then \(M\succeq0\). Constructively,

\[
x^\top Mx=\sum_{\{i,j\}}|m_{ij}|(x_i-x_j)^2+\sum_i d_i^{res}x_i^2\ge0,
\]

with \(d_i^{res}=m_{ii}-\sum_{j\ne i}|m_{ij}|\ge0\).

**T-C2A-012 — conditional G1 to M0.** If \(\mathcal B^{-1}=Z\ge0\) and \(p\ge0\),

\[
\mathcal B\mathbf1\ge\alpha p
\Rightarrow \mathbf1\ge\alpha Zp.
\]

This is componentwise inverse-positive reasoning, not Loewner inversion.

For fixed \(r\in\mathbb R_{++}^n\), G2 is \(Mr\ge0\).

**T-C2A-013.** Fixed G2 implies G0. **T-C2A-014.** \(G2(\mathbf1)=G1\).

**T-C2A-015 — arbitrary fixed G1/G2 are incomparable.** With

\[
M=\begin{bmatrix}1&-0.6\\-0.6&1\end{bmatrix},\quad r=(2,1)^\top,
\]

G1 holds but this G2 fails. Conversely,

\[
M=\begin{bmatrix}0.4&-0.6\\-0.6&1.2\end{bmatrix},\quad r=(2,1)^\top,
\]

this G2 holds but G1 fails. Decision-dependent scaling is generally bilinear.

## 22. Complete G3 / closed-SDD formulation

For every undirected nonzero edge \(\{i,j\}\), introduce \(q_{ij},q_{ji}\ge0\) and require

\[
\boxed{\begin{bmatrix}q_{ij}&m_{ij}\\m_{ij}&q_{ji}\end{bmatrix}\succeq0},
\qquad
\boxed{d_i^{res}=m_{ii}-\sum_{j\in\mathcal N_i}q_{ij}\ge0}.
\]

Each edge appears once with its signed off-diagonal. The \(2\times2\) PSD block is rotated-SOC representable.

**T-C2A-016.** A fixed-G2 witness lies in the closed-SDD/G3 cone.

**T-C2A-017.** G3 implies G0 because the embedded edge PSD blocks plus the nonnegative residual diagonal reconstruct \(M\) exactly.

**T-C2A-018 — singular/reducible theorem.** If \(M=M^\top\succeq0\) and \(m_{ij}\le0\) for \(i\ne j\), permute into connected irreducible blocks. For nonsingular blocks, \(r_k=M_k^{-1}\mathbf1>0\) and \(M_kr_k>0\). For singular irreducible symmetric M-matrix blocks, there exists \(r_k>0\) with \(M_kr_k=0\). Give isolated zero rows arbitrary positive components. Combining gives \(r>0\), \(Mr\ge0\). With \(D=\operatorname{diag}(r)\),

\[
(DMD)_{ii}-\sum_{j\ne i}|(DMD)_{ij}|=r_i(Mr)_i\ge0.
\]

Hence every symmetric PSD Z-matrix is in the closed SDD cone, including singular Laplacian boundary points.

**T-C2A-019.** Project G3 spans that cone only if every nonzero undirected edge is represented once, the signed entry is preserved, and a nonnegative diagonal residual is available.

**T-C2A-020.** Under T-C2A-018 and those project predicates, \(G3\iff G0\) for the frozen project matrix class. The predicates remain unverified Track-C questions.

## 23. M1 and M2

**T-C2A-021.** For ordered nonsingular M-matrices with the declared minimum strengthening explicitly enforced,

\[
\mathcal B\ge\mathcal B^{min}\Rightarrow
Z=\mathcal B^{-1}\le Z^{ub}=(\mathcal B^{min})^{-1}
\]

componentwise in the applicable construction.

**T-C2A-022.** If \(Z^{ub}p\le\alpha^{-1}\mathbf1\) and \(p\ge0\), then M0 follows.

For M2 let \(W\ge0\), \(W_{ii}=1\), \(p\ge0\), so \(Wp\ge p\).

**T-C2A-023.**

\[
\boxed{M2\Rightarrow G1}.
\]

**T-C2A-024.** Under the T-C2A-012 assumptions,

\[
\boxed{M2\Rightarrow G1\Rightarrow M0}.
\]

M2 is interaction-aware but is not exact M0.

## 24. Woodbury, Neumann, and bounded approximations

**T-C2A-025 — exact Woodbury.** For compatible dimensions and required inverses,

\[
\boxed{(A+UCV)^{-1}=A^{-1}-A^{-1}U(C^{-1}+VA^{-1}U)^{-1}VA^{-1}}.
\]

This exact identity does not convexify a decision-dependent inverse.

**T-C2A-026.** First-order Woodbury/Taylor approximations are not globally one-sided without certified error bounds over a declared domain.

**T-C2A-027.** For \(E=A^{-1}\Delta\),

\[
(I+E)^{-1}=\sum_{k=0}^{\infty}(-E)^k
\]

when \(\rho(E)<1\); \(\|E\|<1\) in an induced norm is sufficient.

**T-C2A-028 — finite remainder.** Truncating through order \(m\),

\[
\boxed{R_{m+1}=(-E)^{m+1}(I+E)^{-1}A^{-1}},
\]

and for \(\|E\|<1\),

\[
\boxed{\|R_{m+1}\|\le\frac{\|E\|^{m+1}}{1-\|E\|}\|A^{-1}\|}.
\]

A two-sided norm bound is not automatically a one-sided feasibility certificate.

## 25. Reactive variants and physical interpretation

Passive shunt susceptance, switched shunts, filters, synchronous-condensor/source impedance, converter reactive capability, actual reactive dispatch, current capability, fault-current contribution, and static source stiffness are distinct. A contribution already stamped in \(Y_{bus}\) is not added again. A diagonal GFM source-strength coefficient is exact only in its declared equivalent circuit and otherwise is an equivalent/planning proxy.

## 26. System-strength implication and literature map

The frozen implication graph is

\[
G1\Rightarrow G0,\qquad G2(r)\Rightarrow G0,\qquad G3\Rightarrow G0,\qquad G0\Rightarrow\rho_i^{diag}\ge\alpha.
\]

With inverse positivity and nonnegative exposure,

\[
M0\Rightarrow\rho_i^{diag}\ge\alpha,\qquad G1\Rightarrow M0,\qquad M2\Rightarrow G1\Rightarrow M0.
\]

With a valid fixed inverse bound, \(M1\Rightarrow M0\). In the verified symmetric PSD Z-matrix class with complete project G3, \(G3\iff G0\).

External relations are typed as `exact_equivalence`, `special_case`, `structural_match`, `alternative_formulation`, `analogy_only`, or `unresolved`; Appendix I records source locators only where independently verified.

# Part VI — Dynamic and control-system stability

## 27. Dynamic model classes

The parent architecture separates synchronous machines, GFM converters, GFL converters, dynamic loads, and network/control devices. GFL converters are not assigned swing dynamics without controller-specific derivation; GFM converters are not automatically identical to synchronous machines. Static GFL/GFM participation in a strength exposure is not a dynamic device model. New detailed converter-controller equations beyond the scientific freeze remain contextual/future material or `NEW_REVIEWER_PROPOSAL_REQUIRING_SEPARATE_ADJUDICATION`.

## 28. Heterogeneous DAE and joint equilibrium

Use

\[
\boxed{\dot x=f(x,z,u),\qquad0=g(x,z,u)},
\]

with \(x=\operatorname{col}(x^{SG},x^{GFM},x^{GFL},x^{load},x^{ctrl})\). A joint equilibrium satisfies

\[
f(x^\star,z^\star,u^\star)=0,\qquad g(x^\star,z^\star,u^\star)=0.
\]

The network subset of \(g\) contains the AC equilibrium equations under the same coordinates and active set; controller algebraic states, source-terminal variables, and limit equations can enlarge \(g\). Saturation, current limiting, anti-windup, protection, and bus/control switching make the local model active-set dependent.

## 29. Descriptor linearization and regular reduction

At equilibrium,

\[
\begin{bmatrix}\Delta\dot x\\0\end{bmatrix}
=
\begin{bmatrix}f_x&f_z\\g_x&g_z\end{bmatrix}_\star
\begin{bmatrix}\Delta x\\\Delta z\end{bmatrix},
\]

or \(E\dot\xi=A\xi\) with singular descriptor matrix \(E\). A complete descriptor statement includes regularity, finite/infinite modes, consistency/index assumptions, reference modes, and active-set domain.

If \(g_z\) is nonsingular,

\[
\boxed{A_{red}=f_x-f_zg_z^{-1}g_x}.
\]

If \(g_z\) is singular, no pseudoinverse is inserted by analogy. When \(g_z\) is exactly the AC-network algebraic Jacobian under the same variables/active set, corresponding blocks map to the PF Jacobian; with extra algebraic controls/limits the relationship is a partition, not equality with \(J_{PF}\) as a whole.

## 30. Declared third-order C2A specialization and derivative provenance

The retained third-order specialization represents a **one-axis synchronous/equivalent voltage-source class** under the frozen assumptions; it is not a universal GFL or GFM controller model. Before algebraic elimination write its nonlinear differential part as

\[
\dot\delta=\omega,
\]
\[
M\dot\omega=P_m-P_e(\delta,E,z;\mathcal P)-D\omega,
\]
\[
T\dot E=E_f-E-X_\Delta I_d(\delta,E,z;\mathcal P),
\]

coupled to algebraic equations

\[
0=g(\delta,E,z;\mathcal P).
\]

Here \(\mathcal P\) collects fixed parameters for the declared model. The equilibrium \((\delta^\star,E^\star,z^\star)\) satisfies the three steady-state equations and \(g=0\).

### 30.1 Physical coordinate convention

- \(\delta\in\mathbb R^{n_s}\) is the internal/rotor electrical angle of each represented source relative to the selected synchronous/network reference; it is not the terminal-bus voltage-angle vector unless a separate reduction establishes that identity.
- \(\omega\in\mathbb R^{n_s}\) is the corresponding electrical-speed deviation from synchronous reference.
- \(E\in\mathbb R^{n_s}\) is the retained internal-source voltage state of the declared one-axis/equivalent-source model.
- \(I_d\in\mathbb R^{n_s}\) is the declared direct-axis current in the source-aligned \(dq\) convention, with sign chosen so that \(+X_\Delta I_d\) is the demagnetizing/internal-voltage-drop term appearing in \(T\dot E=E_f-E-X_\Delta I_d\). Changing the current sign changes the derivative signs and must be propagated consistently.
- \(z\) contains the terminal/network algebraic variables eliminated or retained by the source DAE, such as terminal voltages/angles/currents under the selected formulation.

The chapter does not invent additional converter-controller physics. If a more detailed machine or converter model is used in a study, that model must define its own states, reference frame, current signs, limiters, and reduction path.

### 30.2 Raw and reduced derivative definitions

At \((\delta^\star,E^\star,z^\star)\), if algebraic variables are retained, the raw partial derivatives are

\[
P_{e,\delta}:=\left.\frac{\partial P_e}{\partial\delta}\right|_\star,
\quad
P_{e,E}:=\left.\frac{\partial P_e}{\partial E}\right|_\star,
\]
\[
I_{d,\delta}:=\left.\frac{\partial I_d}{\partial\delta}\right|_\star,
\quad
I_{d,E}:=\left.\frac{\partial I_d}{\partial E}\right|_\star.
\]

If \(z\) is eliminated through a nonsingular \(g_z\), then

\[
\frac{\partial z}{\partial\delta}=-g_z^{-1}g_\delta,
\qquad
\frac{\partial z}{\partial E}=-g_z^{-1}g_E,
\]

and the derivative blocks used in the reduced third-order Jacobian are the **total reduced derivatives**

\[
\boxed{K_\delta:=P_{e,\delta}-P_{e,z}g_z^{-1}g_\delta},
\]
\[
\boxed{K_E:=P_{e,E}-P_{e,z}g_z^{-1}g_E},
\]
\[
\boxed{G^{\mathrm{DAE}}:=I_{d,\delta}-I_{d,z}g_z^{-1}g_\delta},
\]
\[
\boxed{H^{\mathrm{DAE}}:=I_{d,E}-I_{d,z}g_z^{-1}g_E}.
\]

If the declared specialization already presents \(P_e(\delta,E)\) and \(I_d(\delta,E)\) after exact algebraic elimination, these reduce to the direct derivatives of those reduced functions. This distinction prevents raw partial derivatives from being silently substituted for Schur-reduced derivatives.

### 30.3 State/parameter dimensions

| Object | Dimension | Structural condition / interpretation |
|---|---:|---|
| \(\delta,\omega,E\) | \(n_s\times1\) | source dynamic coordinates |
| \(M,D,T,X_\Delta\) | \(n_s\times n_s\) | diagonal; \(M,T,X_\Delta\succ0\), \(D\succeq0\) or positive as declared |
| \(K_\delta,K_E,G^{\mathrm{DAE}},H^{\mathrm{DAE}}\) | \(n_s\times n_s\) | equilibrium reduced derivatives |
| \(z\) | \(n_z\times1\) | algebraic network/controller coordinates |
| \(g_z\) | \(n_z\times n_z\) | nonsingular only for the regular reduction used above |

### 30.4 Cosine/sine ancestry without historical identification

For reciprocal symmetric stiffness matrices, differentiating angle-difference terms produces representative structures

\[
C^{\cos}=\mathcal B\circ[\cos(\delta_i-\delta_j)],
\qquad
\Omega^{\mathrm{cross}}=\mathcal B\circ[\sin(\delta_i-\delta_j)].
\]

The first is symmetric and the second skew because cosine is even and sine is odd in the angle difference. Their **placement and signs inside \(K_\delta,K_E,G^{\mathrm{DAE}},H^{\mathrm{DAE}}\) must be obtained by differentiating the declared \(P_e,I_d,g\)**. Visual resemblance is not a mapping theorem.

## 31. Complete third-order Jacobian and common-DAE object provenance

Using the reduced derivatives defined in §30,

\[
\boxed{
J=\begin{bmatrix}
0&I&0\\
-M^{-1}K_\delta&-M^{-1}D&-M^{-1}K_E\\
-T^{-1}X_\Delta G^{\mathrm{DAE}}&0&T^{-1}(-I-X_\Delta H^{\mathrm{DAE}})
\end{bmatrix}.}
\]

This formula follows directly from the declared sign convention in
\(T\dot E=E_f-E-X_\Delta I_d\). In particular,

\[
\boxed{H^{\mathrm{DAE}}:=\left.\frac{d I_d^{red}}{dE}\right|_\star}
\]

is the common-DAE voltage-voltage derivative used in this Jacobian, and \(\Omega^{\mathrm{cross}}\) denotes only a common-model sine/skew **cross-channel derivative structure** unless a specific differentiated equation assigns it more narrowly.

**T-C2A-033** remains `plausible_but_unproved`: historical cosine and sine/skew matrices may be related blocks or reductions of a common model, but the complete historical source mapping is unresolved.

### 31.1 Dynamic object provenance and non-identification table

| Object | Definition/domain | Role | Relationship asserted by this chapter |
|---|---|---|---|
| \(H^{\mathrm{DAE}}\) | reduced \(dI_d^{red}/dE|_\star\) of common third-order DAE | voltage-voltage derivative in \(T^{-1}(-I-X_\Delta H^{\mathrm{DAE}})\) | defined by the DAE only |
| \(H^{(034)}\) | theorem-local symmetric matrix of frozen T-C2A-034 | isolated cosine-block theorem | **not identified** with \(H^{\mathrm{DAE}}\); no equality or sign map claimed |
| \(\Omega^{\mathrm{cross}}\) | sine/skew structure arising in common-DAE cross-channel derivatives | common-model derivative ancestry | **not identified** with the complete historical isolated block below |
| \(\Omega^{(035)}\) | theorem-local skew matrix of frozen T-C2A-035 | isolated sine/skew theorem | **not identified** with \(\Omega^{\mathrm{cross}}\) |

\[
\boxed{
H^{\mathrm{DAE}}\;\not\equiv\;H^{(034)},
\qquad
\Omega^{\mathrm{cross}}\;\not\equiv\;\Omega^{(035)}
\quad\text{by this chapter}.}
\]

The symbols above are deliberately distinct. This box does **not** assert mathematical inequality; it asserts that no identity, sign-duality, or reduction map has been established. A future statement such as \(H^{(034)}=-H^{\mathrm{DAE}}\), or any equality involving \(\Omega^{(035)}\), requires an equation-level derivation from the same nonlinear model and separate scientific adjudication. This preserves `CG-02-HIST` as unresolved.

## 32. Exact isolated C2A theorems — theorem-local historical objects

The following frozen theorems are retained exactly in logical content but use local superscripts to prevent an unproved cross-layer identification.

### T-C2A-034 — isolated cosine block

Let

\[
\boxed{A_v=T^{-1}(XH^{(034)}-I)},
\]

where \(T\succ0\) and \(X\succ0\) are diagonal and \(H^{(034)}=(H^{(034)})^\top\). Choose

\[
P=TX^{-1}\succ0.
\]

Then

\[
A_v^\top P+PA_v=2(H^{(034)}-X^{-1}).
\]

Moreover, with \(Q=T^{-1}X\succ0\), \(A_v\) is similar to

\[
Q^{1/2}(H^{(034)}-X^{-1})Q^{1/2}.
\]

Consequently

\[
\boxed{H^{(034)}-X^{-1}\prec0\iff A_v\text{ is Hurwitz}}.
\]

For a decay rate \(\sigma\ge0\),

\[
A_v^\top P+PA_v+2\sigma P\prec0
\iff
H^{(034)}-X^{-1}+\sigma TX^{-1}\prec0.
\]

This is necessary and sufficient only for the declared isolated block. No mapping to \(H^{\mathrm{DAE}}\) is used in the proof.

### T-C2A-035 — isolated sine/skew block

Let

\[
\boxed{K_{EE}=T^{-1}(-I-X\Omega^{(035)})},
\qquad (\Omega^{(035)})^\top=-\Omega^{(035)},
\]

with positive diagonal \(T,X\), and choose \(P=TX^{-1}\succ0\). Then

\[
PK_{EE}=-X^{-1}-\Omega^{(035)},
\qquad
K_{EE}^\top P=-X^{-1}+\Omega^{(035)},
\]

so

\[
\boxed{K_{EE}^\top P+PK_{EE}=-2X^{-1}\prec0}.
\]

The strict damping comes from \(-I\); the subsystem is not a pure skew generator. The result is isolated only and does not identify \(\Omega^{(035)}\) with \(\Omega^{\mathrm{cross}}\).

### 32.1 Re-check of the frozen dynamic interface

The correction preserves the theorem content while restoring the freeze boundary:

- **T-C2A-033:** still `plausible_but_unproved`; historical mapping unresolved.
- **T-C2A-034:** exact iff statement unchanged; only the theorem-local symbol is disambiguated.
- **T-C2A-035:** exact weighted-skew proof unchanged; only the theorem-local symbol is disambiguated.
- **CG-02-CM:** common DAE has cosine voltage-voltage and sine/skew cross-channel derivative structures under the declared model.
- **CG-02-HIST:** complete historical matrix mapping remains unresolved.

## 33. Full coupled-system stability

**T-C2A-036 — retained counterexample.**

\[
J=\begin{bmatrix}-1&2\\2&-1\end{bmatrix}
\]

has stable isolated diagonal blocks but eigenvalues \(1\) and \(-3\). Therefore

\[
\boxed{\text{stable isolated blocks}\not\Rightarrow\text{stable full coupled system}}.
\]

**T-C2A-037.** For a complete fixed real matrix \(J\),

\[
\boxed{J\text{ Hurwitz}\iff\exists P\succ0:\ J^\top P+PJ\prec0}.
\]

**T-C2A-038.** Structured \(P\) restrictions are sufficient unless exactness is separately proved. If \(J(x)\) and \(P\) are both variables, \(J(x)^\top P+PJ(x)\prec0\) is generally a BMI, not an LMI.

## 34. Small gain, passivity/KYP, and impedance methods

**T-C2A-039.** Small gain is sufficient only for declared stable subsystems, signal spaces, well-posed feedback, and specified induced norm.

**T-C2A-040.** KYP/passivity is model-specific and requires a compatible realization, ports, supply rate, feedthrough assumptions, and regularity.

Impedance/return-ratio analysis requires source/load partition, frame, ports, operating point, converter controls, frequency range, delays, and current-limit assumptions. None follows automatically from G0.

## 35. Nonlinear phasor and EMT validation boundaries

Linear eigenanalysis is local. Nonlinear phasor simulation retains nonlinear averaged dynamics/limits. Frequency-domain analysis resolves controller/network interaction over frequency. EMT resolves switching and fast/current-limited effects when material. A certificate in one layer does not replace validation in another.

## 36. Dynamic terminology and unresolved mappings

Use the narrowest correct term: rotor-angle stability, voltage-mode small-signal stability, converter-control interaction, PLL-related instability, oscillatory/aperiodic instability, short-term voltage stability, long-term voltage stability, or transient voltage recovery. CG-01 historical source symbols and CG-02 complete historical matrix mappings remain unresolved where original equation-level definitions are absent. In particular, the common-DAE \(H^{\mathrm{DAE}}\) and \(\Omega^{\mathrm{cross}}\) are not equated to the theorem-local \(H^{(034)}\) and \(\Omega^{(035)}\).

# Part VII — Capacity expansion, dispatch, and security embedding

## 37. Planning indices, chronology, and nonanticipativity

The planning hierarchy distinguishes \(y,d,h,\omega,c\) and optional \(m\). Strategic variables obey scenario-tree information structure. Two scenario nodes with identical information histories have equal nonanticipative decisions. Scenario-dependent investment without such constraints is not a genuine multistage formulation. As stated in §3, compact \(t\) notation is only shorthand for the relevant intra-period index when the other indices are fixed/suppressed.

## 38. Strategic investment decisions

Strategic variables may include installed/new/retired generator or converter blocks, technology/control choice, candidate lines/transformers, synchronous condensers or source-strength assets, passive/switched shunts, and separate storage MW/MWh capacities. Storage power and energy are not identified unless a technology-specific duration relation is imposed.

## 39. Availability, commitment, startup, and shutdown

Use the full hierarchy

\[
\boxed{0\le n_{k,y,d,h,\omega,c}^{on}
\le n_{k,y,d,h,\omega,c}^{avail}
\le n_{k,y}^{inst}
\le n_k^{max}}.
\]

Installed does not imply available; available does not imply online; online does not imply dispatched. For a chronological predecessor \(h^-\) inside a represented operating sequence,

\[
\boxed{n_{k,y,d,h,\omega,c}^{on}-n_{k,y,d,h^-,\omega,c}^{on}
=s_{k,y,d,h,\omega,c}^{up}-s_{k,y,d,h,\omega,c}^{down}}.
\]

The first-period or representative-period boundary condition is declared explicitly. Minimum up/down time and ramping use the same chronology rather than being inferred from the transition equation.

Two historical startup/shutdown conventions remain distinct:

**Convention A — per-block event cost**

\[
C_{k}^{up}=c_k^{up,blk}s_k^{up},\qquad
C_k^{down}=c_k^{down,blk}s_k^{down},
\]

where \(c^{up,blk},c^{down,blk}\) have units currency per block event.

**Convention B — per-MW event cost**

\[
C_k^{up}=c_k^{up/MW}P_k^u s_k^{up},\qquad
C_k^{down}=c_k^{down/MW}P_k^u s_k^{down},
\]

where \(c^{up/MW}\) has units currency/(MW·event) and \(P_k^u\) is MW per represented unit/block. The relation \(c_k^{up,blk}=c_k^{up/MW}P_k^u\) is used only when that conversion is the study's intended convention.

## 40. Dispatch, reserves, storage, and flexibility

For dispatchable generation,

\[
P_k^{min}n_k^{on}\le P_k\le P_k^{max}n_k^{on},
\]

with separate \(Q/S/I\) capability when represented. Reserve capacity and reserve deployment are distinct. Renewable availability and curtailment are distinct. Storage includes charge/discharge power, stored energy, power/energy capacity, efficiencies, self-discharge, and terminal/boundary policy. Flexible demand, involuntary shedding, voltage/reactive setpoints, and current allocation are separate decisions where used.

## 41. Decision-dependent exposure

\[
S^{nom}(x^{inv}),\qquad
S^{on}(x^{inv},x^{avail},x^{commit}),
\]
\[
S^{op}(x^{dispatch}),\qquad
S^I(x^{control},V,\text{limits}).
\]

Curtailment can reduce \(S^{op}\) without changing \(S^{on}\). Signed storage charging is not automatically a nonnegative exposure. Idle-online storage can remain in \(S^{on}\) with zero \(S^{op}\). Current-limited operation may require \(S^I\) or a dynamic/current model. GFM devices are not automatically included in a GFL denominator.

## 42. Decision-dependent network/source strength

Use the full operating index:

\[
\boxed{
\mathcal B_{y,d,h,\omega,c}
=\mathcal B^0_{y,d,h,\omega,c}
+\Delta\mathcal B_{y,d,h,\omega,c}^{network}
+\Delta\mathcal B_{y,d,h,\omega,c}^{source}}.
\]

Candidate lines/transformers can alter diagonal/off-diagonal entries, sparsity, islands, references, G3 edge sets, and invertibility. Decision-dependent Schur/Kron reduction is generally non-affine because the eliminated-block inverse depends on decisions. A diagonal source-strength addition is exact only for the declared source-behind-fixed-series-reactance circuit; otherwise it is an equivalent/planning proxy. GFM stiffness, synchronous-source impedance, passive shunt compensation, fault current, reactive capability, and actual \(Q\) remain distinct.

## 43. Planning realization of G0--G3

Let \(M(x)=\mathcal B(x)-\alpha S(x)\). G0 is an LMI only on a fixed retained space, fixed \(\alpha\), and affine \(M(x)\). Under those assumptions it is SDP or MISDP with integer-affine decisions. G1 can be LP/MILP with affine entries and fixed/validly represented signs. Fixed G2 can be linear; variable scaling is bilinear. Complete G3 is SOCP/MISOCP with affine entries and a fixed edge catalogue; candidate topology requires valid on/off conic modelling.

## 44. Planning realization of local/M0--M2 and inverse approximations

Exact M0 may be written

\[
\mathcal B(x)y=p(x),\qquad y\le\alpha^{-1}\mathbf1.
\]

If \(\mathcal B(x)\) and \(y\) are both variables, it is bilinear/nonlinear. M1 is a fixed inverse-upper-bound certificate if its lower-bound matrix is enforced. M2 is LP/MILP for fixed \(W\). Woodbury remains an identity, not a convexification. Neumann truncations require convergence, remainder bounds, and a separate one-sided safety argument.

## 45. Temporal, stochastic, contingency, and security architecture

Distinguish scenario probability \(\pi_\omega\), representative-period multiplicity \(w_d\), snapshot duration \(\Delta t_h\), implementation-facing operation weights, and discount/annualization factors. Storage SOC, commitment transitions, minimum up/down times, ramping, reserves, maintenance, and seasonal constraints require explicit linkage. Representative-period boundary policies include cyclic, fixed-initial, relaxed-cyclic, chronological linking, or none.

Each security formulation states whether enforced at every state, screened states, all \(N-1\) contingencies, selected scenarios, cut generation, chance constraint with a probability statement, or robustly over a quantified uncertainty set.

## 46. Objective function — explicit dimensional weighting

The objective is separated into terms with different units and replication rules. A generic multi-stage form is

\[
\boxed{
\min\sum_{y\in\mathcal Y}\delta_y
\left[
C_y^{inv}+C_y^{fix}-C_y^{salvage}
+C_y^{energy}+C_y^{event}+C_y^{reserve}
\right]}.
\]

For variable energy-like operating costs measured in currency/MWh,

\[
\boxed{
C_y^{energy}=
\sum_{\omega,d,h}\pi_\omega w_d\Delta t_h
\left[
\sum_k c_k^{var}P_{k,y,d,h,\omega}
+\sum_r c_r^{curt}P_{r,y,d,h,\omega}^{curt}
+\sum_i c_i^{VOLL}P_{i,y,d,h,\omega}^{shed}
+\cdots
\right]},
\]

where \(P\) is MW, \(\Delta t_h\) is h, and the bracket has currency/h so the product is currency.

For startup/shutdown event costs,

\[
\boxed{
C_y^{event}=
\sum_{\omega,d,h}\pi_\omega w_d
\sum_k\left[
 c_k^{up}s_{k,y,d,h,\omega}^{up}
+c_k^{down}s_{k,y,d,h,\omega}^{down}
\right]},
\]

where \(c^{up},c^{down}\) are currency/event under Convention A or the per-MW convention has already been multiplied by \(P_k^u\). **No \(\Delta t_h\) factor is applied to event costs by default.**

Representative-period multiplicity \(w_d\) multiplies startup/shutdown event counts only when the representative-period construction means that the entire intra-period commitment transition sequence is replicated \(w_d\) times. If representative periods are statistically weighted snapshots without replicated transition sequences, startup/shutdown occurrence modelling requires a separate event-frequency/chronology construction rather than blindly applying \(w_d\).

For reserve-capacity payments under a price \(c_k^{R}\) in currency/(MW·h),

\[
C_y^{reserve}=
\sum_{\omega,d,h}\pi_\omega w_d\Delta t_h\sum_k c_k^R R_{k,y,d,h,\omega}.
\]

If the study uses currency/MW per settlement interval instead, \(\Delta t_h\) is replaced by the declared settlement weighting; the unit convention controls the multiplier.

### 46.1 Objective-weighting ledger

| Cost class | Typical units before quantity multiplication | \(\delta_y\) | \(\pi_\omega\) | \(w_d\) | \(\Delta t_h\) | Governing interpretation |
|---|---|---:|---:|---:|---:|---|
| investment CAPEX | currency/year-stage or currency | yes | no for nonanticipative stage decision | no | no | annualization/discount declared |
| fixed O&M | currency/year | yes | normally no | no | no | annual fixed capacity cost |
| variable generation / fuel | currency/MWh | yes | yes | yes | yes | energy-duration term |
| curtailment / unserved energy | currency/MWh | yes | yes | yes | yes | energy-duration term |
| startup/shutdown | currency/event or currency/(MW·event) | yes | yes | only if episode replicated | **no** | event-counted |
| reserve capacity | currency/(MW·h) or market-specific | yes | yes | yes | if price is per MW·h | settlement convention declared |
| capacity adequacy / power-capacity | currency/MW-period | yes | as modelled | no hourly replication unless defined | no | capacity-period term |
| salvage/terminal | currency | yes | scenario dependence only if formulation declares it | no | no | end-of-horizon convention |

Investment cost is never operation-weighted merely because the operating snapshots have \(w_d\) or \(\Delta t_h\).

## 47. Reactive planning scope

Each study declares passive shunts, switched shunts/filters, synchronous condensers/source impedance, GFM/GFL reactive capability, actual reactive dispatch, voltage setpoints, apparent-power limits, and current limits. The no-double-counting ledger remains governing.

## 48. Security placement and decomposition

| Layer/object | Typical role |
|---|---|
| G1/fixed G2/M1/M2 | scalable LP/MILP screens/master constraints under affine realization |
| G3 | stronger SOCP/MISOCP certificate |
| G0 | SDP/MISDP benchmark, selected-state constraint, or cut target |
| nonlinear AC PF | physical operating feasibility validation/subproblem |
| local/M0 | exact impedance post-processing/nonlinear subproblem |
| CPF | selected static-voltage branch/loadability validation |
| full eigenanalysis | selected small-signal validation |
| impedance/return ratio | converter-control frequency-domain validation |
| nonlinear phasor/EMT | critical nonlinear/current-limited validation |

This is an architecture, not evidence that a decomposition or validation workflow is implemented.

# Part VIII — Validation, applicability, and handoff

## 49. State-of-the-art typed synthesis

External literature is integrated equation-first. Classical SCR uses source-qualified short-circuit strength divided by a declared rated-power denominator. Multi-infeed families introduce interaction factors under their own network/fault/denominator conventions. Generalized-eigenvalue grid-strength coordinates depend on specific converter/network normalizations. CPF and saddle-node theory concern nonlinear equilibria. Impedance/generalized-Nyquist methods retain frequency-dependent controller/network interaction. Lyapunov, small-gain, and KYP/passivity are dynamic-system theorems with their own realizations and ports.

Acronym similarity is not relation proof. Appendix I records exact locators only where the source was independently verified in this correction pass; inaccessible or restricted sources retain `equation_locator_not_verified` rather than guessed equation numbers.

## 50. Post-solve reconstruction and validation

For every selected critical solution state:

1. reconstruct topology, islands, references, and in-service devices;
2. rebuild \(Y_{bus}\) from physical stamps;
3. rebuild the declared \(\mathcal B\) and verify predicates;
4. reconstruct exposure and base normalization;
5. verify symmetry/Z/PD/inverse-positivity assumptions where used;
6. recompute G0 independently;
7. recompute G1/G2/G3 and slacks;
8. recompute exact \(Z\), local ratios, and M0 where valid;
9. solve nonlinear AC PF and verify limits;
10. run CPF on selected cases;
11. form the complete dynamic/descriptor Jacobian at the validated equilibrium using the explicit derivative provenance of §§30–31;
12. run eigenvalue, frequency-domain/impedance, nonlinear phasor, and EMT validation as warranted.

These are requirements, not claims that validation has already been executed.

## 51. Applicability and prohibited implications

The following are invalid in general:

\[
\boxed{G0\not\Rightarrow M0},
\qquad
\boxed{\{\rho_i^{diag}\ge\alpha\ \forall i\}\not\Rightarrow G0},
\]
\[
\boxed{\text{system-strength threshold}\not\Rightarrow\text{nonlinear voltage-collapse security}},
\]
\[
\boxed{\text{stable isolated dynamic blocks}\not\Rightarrow\text{stable full coupled system}}.
\]

Additional validity boundaries include conductance/asymmetry outside the stiffness specialization, topology/island changes, active-set switching, converter saturation/current limiting, unverified threshold transfer, decision-dependent reduction, invalid inverse assumptions, and unverified project predicates.

## 52. Track C object register and implementation boundary

| Scientific object | Dimension / unit | Decision dependence | Track-C evidence required | Current status |
|---|---|---|---|---|
| bus/device incidence | topology | investment/status | exact maps, islands, references | unverified |
| \(Y_{bus}\) | \(N_b\times N_b\), p.u. admittance | topology/status | stamps and bases | unverified |
| \(\mathcal B\) | retained real matrix | topology/source | sign/reference construction and predicates | unverified |
| \(S^{nom},S^{on},S^{op},S^I\) | diagonal exposure | investment/commitment/dispatch/control | eligibility, units, normalization | unverified |
| source/GFM strengthening | stiffness | investment/online | exact-circuit versus proxy implementation | unverified |
| G0/G1/G2/G3 | matrix/conic | formulation dependent | equation-to-code and edge coverage | unverified |
| local/M0/M1/M2 | impedance/burden | formulation dependent | inverse assumptions/bounds/weights | unverified |
| time/scenario/contingency | index sets | data/model | chronology, probabilities, weights, nonanticipativity | unverified |
| operating point | algebraic state | dispatch/control | converged active-set AC state | unverified |
| dynamic state/Jacobian | model dependent | operating point/control | state order, derivative provenance, descriptor reduction | unverified |
| output metrics | scalar/vector | post-processing | independent recomputation | unverified |

The frozen project predicates remain:

- P-C2A-001 symmetry of project \(\mathcal B_t\) — `not_reviewed`;
- P-C2A-002 nonpositive off-diagonals — `not_reviewed`;
- P-C2A-003 PD after reference/island treatment — `not_reviewed`;
- P-C2A-004 \(\mathcal B_t^{-1}\ge0\) — `not_reviewed`;
- P-C2A-005 implemented G1 exact row equation — `not_reviewed`;
- P-C2A-006 GFM strengthening purely diagonal/affine — `not_reviewed`;
- P-C2A-007 exposure nonnegative/consistently based — `not_reviewed`;
- P-C2A-008 complete G3 edge/residual model — `not_reviewed`;
- P-C2A-009 exact zero-exposure handling — `not_reviewed`;
- P-C2A-010 binding classifications use exact post-processing — `not_reviewed`.

## 53. Conclusions and research outlook

The C2A result is a typed hierarchy, not a universal metric. Physical AC equilibrium provides ancestry; static voltage stability follows through equilibrium families, full/reduced Jacobians, CPF, and active limits. System-strength mathematics introduces a separate lossless/reference/exposure specialization: G0 is exact for its pencil; G1/fixed G2/G3 are tractable certificates; G3 is exact only on the restricted verified matrix class; local/M0 are distinct impedance quantities; M1/M2 give conditional sufficient routes; Woodbury/Neumann are exact inverse tools before controlled approximation. Dynamic stability begins from a DAE/descriptor model. The common-DAE derivative objects are explicitly quarantined from the historically retained isolated theorem objects, so the unresolved CG-02 mapping remains unresolved rather than being silently resolved by notation. Planning then parameterizes these already-defined objects and applies dimensionally explicit weighting.

Track C remains responsible for equation-to-code verification, numerical conservatism measurement, threshold calibration, and staged nonlinear AC, CPF, eigenvalue, impedance, nonlinear phasor, and EMT validation. None of these open tasks changes the frozen theorem verdicts.

# Appendix A — Notation, dimensions, units, and bases

| Symbol | Meaning | Domain / unit |
|---|---|---|
| \(Y_{bus}=G+jB^{phys}\) | physical nodal admittance | complex p.u. admittance |
| \(B^{phys}\) | imaginary part of physical \(Y_{bus}\) | p.u. susceptance |
| \(\mathcal B=-\Im Y_{bus}\) | positive stiffness specialization | real p.u. admittance |
| \(S\) | qualified exposure matrix | declared consistent power/current normalization |
| \(Z=\mathcal B^{-1}\) | impedance where inverse exists | p.u. impedance |
| \(J_{PF}\) | full PF Jacobian | operating-point derivative |
| \(J_{QV}^{red}\) | reduced \(Q\)-\(V\) Jacobian | operating-point derivative |
| \(E\dot\xi=A\xi\) | descriptor linearization | model-dependent |
| \(H^{\mathrm{DAE}}\) | common-DAE reduced \(dI_d/dE\) | derivative; model/base dependent |
| \(H^{(034)}\) | T-C2A-034 theorem-local symmetric matrix | historical isolated-theorem object |
| \(\Omega^{\mathrm{cross}}\) | common-DAE sine/skew cross-channel structure | derivative structure |
| \(\Omega^{(035)}\) | T-C2A-035 theorem-local skew matrix | historical isolated-theorem object |
| \(n^{inst},n^{avail},n^{on}\) | capacity/status counts | nonnegative/integer as declared |
| \(P,Q,S,I\) | electrical quantities | MW/Mvar/MVA/A or declared p.u. |

# Appendix B — Assumption-to-theorem dependency map

| Theorem family | Essential assumptions |
|---|---|
| T001/T002/T004 | invertibility/PD for ordinary Schur; pseudoinverse plus range for singular case; fixed partition |
| T005/T006 | symmetric pencil; consistent exposure; finite-spectrum/support treatment |
| T007--T010 | \(\mathcal B\succ0\); inverse positivity/nonnegative exposure where used |
| T011--T015 | symmetric Z-matrix; fixed positive G2 scaling; inverse positivity for T012 |
| T016--T020 | complete closed-SDD definition; singular/reducible/zero-row coverage; project edge predicates for exactness |
| T021--T024 | ordered nonsingular M-matrices, enforced lower bound, nonnegative exposure, nonnegative unit-diagonal M2 weights |
| T025--T028 | stated inverses; spectral-radius/induced-norm convergence domain |
| T029--T032 | regular fixed operating point/active set; model-specific threshold domain |
| T033 | historical mapping remains unresolved |
| T034 | theorem-local \(T,X\succ0\) diagonal and symmetric \(H^{(034)}\); isolated block only |
| T035 | theorem-local \(T,X\succ0\) diagonal and skew \(\Omega^{(035)}\); isolated block only |
| T036 | coupled counterexample; no blockwise composition |
| T037/T038 | complete fixed \(J\); structured \(P\) only sufficient unless exactness proved |
| T039/T040 | declared subsystems/interconnection/norm or realization/ports/supply rate/regularity |

# Appendix C — Theorem and proof preservation register

| ID | Destination | Preservation status | Frozen verdict / direction |
|---|---|---|---|
| T-C2A-001 | §17 | preserved | exact algebraic elimination |
| T-C2A-002 | §17 | preserved | equivalent parallel-sum identity |
| T-C2A-003 | §17/§36 | preserved | ambiguous historical notation / unresolved mapping |
| T-C2A-004 | §17 | preserved with singular range condition | exact under additional assumptions |
| T-C2A-005 | §19 | preserved | G0 equivalence |
| T-C2A-006 | §19 | preserved | singular-exposure exact treatment under assumptions |
| T-C2A-007 | §20 | preserved | local rank-one equivalence |
| T-C2A-008 | §20 | preserved | G0 sufficient for local metric |
| T-C2A-009 | §20 | preserved | M0 sufficient for local metric under assumptions |
| T-C2A-010 | §20 | counterexample retained | \(G0\not\Rightarrow M0\) |
| T-C2A-011 | §21 | constructive proof preserved | \(G1\Rightarrow G0\) |
| T-C2A-012 | §21 | preserved explicitly | conditional \(G1\Rightarrow M0\) |
| T-C2A-013 | §21 | preserved | fixed \(G2(r)\Rightarrow G0\) |
| T-C2A-014 | §21 | preserved | \(G2(\mathbf1)=G1\) |
| T-C2A-015 | §21 | both counterexamples retained | arbitrary fixed G1/G2 incomparable |
| T-C2A-016 | §22 | preserved | fixed-G2 witness in closed SDD |
| T-C2A-017 | §22 | preserved | \(G3\Rightarrow G0\) |
| T-C2A-018 | §22 | singular/reducible proof preserved | symmetric PSD Z-matrix = closed SDD class |
| T-C2A-019 | §22 | project predicates explicit | implementation-conditional completeness |
| T-C2A-020 | §22 | project predicates explicit | conditional \(G3\iff G0\) |
| T-C2A-021 | §23 | preserved | M1 inverse upper bound |
| T-C2A-022 | §23 | preserved | \(M1\Rightarrow M0\) |
| T-C2A-023 | §23 | preserved explicitly | \(M2\Rightarrow G1\) |
| T-C2A-024 | §23 | preserved explicitly | conditional \(M2\Rightarrow G1\Rightarrow M0\) |
| T-C2A-025 | §24 | preserved | exact Woodbury identity |
| T-C2A-026 | §24 | preserved | no global one-sided first-order safety without bound |
| T-C2A-027 | §24 | preserved | Neumann convergence under spectral-radius condition |
| T-C2A-028 | §24 | exact remainder/bound preserved | bounded finite approximation |
| T-C2A-029 | §16 | preserved | inverse sensitivity exact only for linearized model |
| T-C2A-030 | §16 | preserved | not a nonlinear CPF-collapse certificate |
| T-C2A-031 | §15 | assumptions preserved | regular saddle-node special case |
| T-C2A-032 | §16/§51 | preserved | model-specific screening scope |
| T-C2A-033 | §§31--32/§36 | symbol quarantine strengthened | plausible but unproved historical mapping |
| T-C2A-034 | §32 | exact theorem/proof preserved with theorem-local symbol | iff isolated cosine block Hurwitz |
| T-C2A-035 | §32 | exact weighted-skew proof preserved with theorem-local symbol | isolated sine/skew block strictly stable |
| T-C2A-036 | §33 | counterexample retained | isolated stability does not imply full stability |
| T-C2A-037 | §33 | preserved | fixed-\(J\) Hurwitz iff full Lyapunov inequality |
| T-C2A-038 | §33 | preserved | structured Lyapunov is sufficient |
| T-C2A-039 | §34 | domain preserved | conditional small-gain sufficiency |
| T-C2A-040 | §34 | domain preserved | conditional KYP/passivity sufficiency |

Regression target: theorem IDs 40/40; verdict changes 0; implication-direction changes 0; counterexamples removed 0; generalized-Schur range conditions removed 0; project predicates promoted 0.

# Appendix D — Counterexamples and invalid converses

1. Local metrics without G0: §20 with \(p=(3/4,3/4)^\top\).
2. G0 without M0: §20 with \(p=(1/4,2/3)^\top\).
3. G1/G2 incomparability in both directions: §21.
4. Stable isolated blocks with unstable coupling: §33.
5. Uncontrolled inverse approximation: for \(\mathcal B=\begin{bmatrix}1&-1/2\\-1/2&1\end{bmatrix}\), \(p=(0.6,0.6)^\top\), \(\alpha=1\), \(\widehat Z=I\) gives \(\widehat Zp=(0.6,0.6)^\top\le\mathbf1\), while exact \(Zp=(1.2,1.2)^\top\), so M0 fails.

# Appendix E — Singular, reducible, and boundary cases

Ordinary Schur elimination requires an inverse; PSD Schur equivalence requires a PD eliminated block; singular blocks require pseudoinverse **and** range condition. Singular exposure uses finite generalized eigenvalues or exact support reduction. Closed-SDD includes singular Laplacians, reducible blocks, and zero rows. Reference-free islands are treated independently. Singular algebraic Jacobians are descriptor problems rather than invitations to use an unqualified pseudoinverse. Zero exposure is not zero electrical influence.

# Appendix F — Inverse identities, convergence domains, and remainder bounds

Woodbury is exact under its invertibility assumptions. Neumann is an exact infinite expansion under \(\rho(E)<1\). T-C2A-028 gives the exact finite remainder and induced-norm bound. A magnitude bound becomes a safety margin only after a valid one-sided implication is proved over the trust region.

# Appendix G — Planning indices, chronology, weights, and objective conventions

The full operating index is \((y,d,h,\omega,c)\); \(t\) is only a locally declared shorthand for the intra-period coordinate when other indices are fixed/suppressed. Investment, availability, commitment, dispatch, representative-period multiplicity, duration, scenario probability, contingencies, operation weights, and discount/annualization factors are separate. Energy-like terms are duration-weighted; event costs are not. Representative-period weights replicate events only under an explicit repeated-episode interpretation. Per-block and per-MW startup/shutdown conventions remain distinct.

# Appendix H — Scientific-to-implementation object register

The register in §52 is the Track-C handoff. Track C must record scientific definition, dimensions, units/base, assumptions, decision dependence, code object/location, data provenance, and independent numerical validation. Documentation does not establish implementation correctness.

# Appendix I — Literature equation-location and relation-class register

Exact locators are included only where independently verified from accessible primary material. A bibliographic item without verified equation-level access is explicitly marked `equation_locator_not_verified`; no locator is reconstructed from acronym familiarity.

| Topic | Source / bibliography key | Exact locator | Source equation/object | C2A object | Relation class | Assumptions matched? | Notes |
|---|---|---|---|---|---|---|---|
| single-infeed SCR definition | `XinEtAl2017ArxivGSCR` | Sec. II.B, Eq. (6) | source-strength / rated-capacity SCR normalization | local/source-strength family | structural match / source-specific special case | only under same Thevenin/fault/denominator convention | accessible primary manuscript; not a universal C2A identity |
| MPEIS generalized-eigenvalue gSCR | `XinEtAl2017ArxivGSCR` | Sec. III.C, Eq. (15); Definition 2, Eq. (21) | \(J_{eq}=S_B^{-1}B\); gSCR as minimum eigenvalue of \(J_{eq}\) | G0 / \(\gamma^{GE}\) | special case / structural match | only when network reduction, exposure/rating matrix, homogeneous-device assumptions and normalization coincide | threshold transfer remains model-specific |
| homogeneous MIDC gSCR | `ZhangEtAl2017ArxivGSCR` | Sec. III.C, Eq. (29); Eqs. (34)--(35) | extended Jacobian, voltage-stability condition, gSCR minimum eigenvalue | G0 / \(\gamma^{GE}\) | special case / structural match | only under the paper's homogeneous CP-CEA MIDC model and normalization | not a converter-independent threshold |
| CIGRE multi-infeed / MIIF family | `CIGRE2008MultipleDC` | `equation_locator_not_verified` | source-specific interaction-factor / multi-infeed quantities | M0-type row-burden family | structural match only | exact normalization not independently verified here | technical brochure retained with restricted locator claim |
| continuation power flow | `AjjarapuChristy1992` | IEEE Trans. Power Systems 7(1), pp. 416--423; `equation_locator_not_verified` | continuation branch-tracing method | §§13--16 | background / alternative nonlinear formulation | same equilibrium/loading/active-set conventions required for direct comparison | bibliographic record verified; exact equation number not asserted |
| impedance stability criterion | `Sun2011` | IEEE Trans. Power Electronics 26(11), pp. 3075--3078; `equation_locator_not_verified` | source/grid impedance ratio and Nyquist-based stability test | §34 | alternative frequency-domain formulation | declared ports/frame/frequency model required | no equivalence to G0 claimed |
| generalized Nyquist | `MacFarlanePostlethwaite1977` | Int. J. Control 25(1), pp. 81--127; `equation_locator_not_verified` | multivariable generalized Nyquist criterion | §34 | exact background theorem on its domain | return-ratio assumptions/encirclement conditions required | locator limited to verified article-level metadata |
| inverse positivity / M-matrix theory | `BermanPlemmons1994` | Ch. 5 §1, Eqs. (1.1)--(1.2) for inverse-positive concept; Ch. 6, pp. 132--164 for M-matrices | inverse-positive and M-matrix properties | §§21--23 | exact mathematical background | only after project matrix is in the required M-matrix class | project predicates remain Track-C unverified |
| Schur complement | `Zhang2005Schur` | `equation_locator_not_verified` | ordinary/generalized Schur theory | §17 | exact mathematical background | theorem-local hypotheses stated in §17 | no fabricated equation number |
| LMI/Lyapunov theory | `BoydEtAl1994` | `equation_locator_not_verified` | LMI and Lyapunov formulations | §§33--34 | exact/conditional background | fixed affine realization required for LMI classification | decision-dependent \(J,P\) remains BMI |

## I.1 Literature traceability rule

A stronger literature-equivalence claim requires all of the following to match: network space/reduction, sign convention, exposure/denominator, device/control model, operating point, and threshold normalization. If an accessible source does not provide a verified exact locator in the current evidence set, the status remains `equation_locator_not_verified` rather than being upgraded by inference.

# Appendix J — Markdown/LaTeX parity statement

The Markdown file is the full dissertation-oriented scientific narrative. The LaTeX counterpart is a **condensed publication rendering, not line-for-line textual parity**. Parity is required at the level of mathematical definitions, theorem statements and directions, assumptions, counterexamples, dynamic object provenance, objective weighting, literature relation classes, and Track-C boundaries. Any future divergence in those mathematical objects is a scientific regression even if both files compile.
