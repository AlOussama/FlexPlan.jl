---
report_id: S-C2A-20260730-track-a-adjudicated-proofs-counterexamples
title: C2A Track A Adjudicated Proofs and Counterexamples
date: 2026-07-30
cluster_id: C2A
document_type: adjudicated_mathematical_supplement
canonical: false
normative: false
track_a_review_complete: true
implementation_verified: false
review_basis:
  branch: review/c2a-mathematical-consolidation-v1
  reviewed_commit: 40593a2ba69180a9a5e916e6d9e52fb8d6458286
  evidence_commit: 15d66ecdbcb1a64ca475e9410ec3d6a1c52327df
adjudication: ../external_review/adjudication/2026-07-29__track-a-consolidated-adjudication.md
---

# 1. Purpose

This supplement records the proofs and exact counterexamples accepted by the consolidated Track A adjudication. It separates theorem validity from project applicability. No statement below verifies the implementation predicates P-C2A-001 through P-C2A-010.

# 2. Generalized Schur complement and singular zero-exposure blocks

For a symmetric block matrix

\[
M=
\begin{bmatrix}
A&B\\
B^T&C
\end{bmatrix},
\qquad C\succeq0,
\]

the generalized Schur-complement criterion is

\[
M\succeq0
\iff
C\succeq0,\quad
(I-CC^\dagger)B^T=0,\quad
A-BC^\dagger B^T\succeq0.
\]

The middle condition is equivalent to

\[
\operatorname{range}(B^T)\subseteq\operatorname{range}(C).
\]

Applied to zero-exposure elimination,

\[
\mathcal B-\alpha S=
\begin{bmatrix}
\mathcal B_{aa}-\alpha S_a&\mathcal B_{az}\\
\mathcal B_{za}&\mathcal B_{zz}
\end{bmatrix},
\]

the ordinary Kron equivalence follows when \(\mathcal B_{zz}\succ0\). If \(\mathcal B_{zz}\) is singular, replacing its inverse by a pseudoinverse is exact only when the range condition is also imposed. Ungrounded islands and reference modes must therefore be removed, separated, or handled by this generalized criterion.

# 3. G1 implies M0

Assume

\[
\mathcal B\mathbf1\ge\alpha p,
\qquad
\mathcal B^{-1}=Z\ge0,
\qquad
p\ge0.
\]

Premultiplication by the entrywise nonnegative inverse preserves componentwise order:

\[
Z\mathcal B\mathbf1\ge\alpha Zp.
\]

Since \(Z\mathcal B=I\),

\[
\mathbf1\ge\alpha Zp,
\]

hence

\[
Zp\le\alpha^{-1}\mathbf1.
\]

Therefore

\[
\boxed{G1\Longrightarrow M0}
\]

for every nonsingular inverse-positive strength matrix. Irreducibility is not required. Project applicability remains conditional on the implemented matrix being nonsingular and inverse-positive and on G1 being exactly the declared row inequality.

# 4. Closed SDD exactness for symmetric PSD Z-matrices

Let

\[
M=M^T\succeq0,
\qquad
M_{ij}\le0\quad(i\ne j).
\]

Permute \(M\) into graph-connected irreducible blocks.

For a nonsingular block \(M_k\), inverse positivity gives

\[
r_k=M_k^{-1}\mathbf1>0,
\qquad
M_kr_k=\mathbf1>0.
\]

For a singular irreducible symmetric M-matrix block, Perron-Frobenius/M-matrix theory gives a strictly positive null vector

\[
r_k>0,
\qquad
M_kr_k=0.
\]

For an isolated zero row, choose any positive component of \(r\). Combining the block vectors gives \(r>0\) such that

\[
Mr\ge0.
\]

With \(D=\operatorname{diag}(r)\),

\[
(DMD)_{ii}-\sum_{j\ne i}|(DMD)_{ij}|
=
r_i(Mr)_i
\ge0.
\]

Thus \(DMD\) is non-strictly diagonally dominant with nonnegative diagonal, so \(M\) lies in the closed scaled-diagonally-dominant cone.

Therefore:

\[
\boxed{
M=M^T\succeq0,\ M_{ij}\le0
\iff
M\in\mathrm{SDD}_{\mathrm{closed}}.
}
\]

The reverse implication is the standard SDD-to-PSD implication. Singular graph Laplacians are boundary points of this closed cone, not counterexamples.

Consequently,

\[
\boxed{G3\iff G0}
\]

when the project matrix is a symmetric Z-matrix and the G3 edge model spans the complete closed SDD cone: every nonzero off-diagonal pair is included once, its signed value is preserved, and a nonnegative diagonal residual is available.

# 5. Exact isolated cosine-block theorem

Let

\[
A_v=T^{-1}(XH-I),
\]

where \(T\succ0\) and \(X\succ0\) are diagonal and \(H=H^T\). Choose

\[
P=TX^{-1}\succ0.
\]

Then

\[
A_v^TP+PA_v
=
2(H-X^{-1}).
\]

Hence

\[
\boxed{
A_v\text{ Hurwitz}
\iff
H-X^{-1}\prec0.
}
\]

This is necessary and sufficient for the declared isolated block because \(A_v\) is similar to the symmetric matrix

\[
Q^{1/2}(H-X^{-1})Q^{1/2},
\qquad
Q=T^{-1}X\succ0.
\]

For a decay rate \(\sigma\ge0\),

\[
A_v^TP+PA_v+2\sigma P\prec0
\]

is equivalent to

\[
H-X^{-1}+\sigma TX^{-1}\prec0.
\]

No conclusion about the full coupled Jacobian follows without an additional coupling theorem.

# 6. Exact isolated sine/skew theorem

Let

\[
K_{EE}=T^{-1}(-I-X\Omega),
\qquad
\Omega^T=-\Omega,
\]

where \(T\succ0\) and \(X\succ0\) are diagonal. Choose

\[
P=TX^{-1}\succ0.
\]

Then

\[
PK_{EE}=-X^{-1}-\Omega,
\]

and

\[
K_{EE}^TP=-X^{-1}+\Omega.
\]

Therefore

\[
\boxed{
K_{EE}^TP+PK_{EE}=-2X^{-1}\prec0.
}
\]

The strict negative term is produced by the \(-I\) component; this is not a pure skew generator. The result certifies only the declared isolated subsystem.

# 7. Exact counterexamples

## 7.1 All local impedance conditions hold while G0 fails

Let

\[
\mathcal B=
\begin{bmatrix}
1&-\tfrac12\\
-\tfrac12&1
\end{bmatrix},
\qquad
p=
\begin{bmatrix}
\tfrac34\\
\tfrac34
\end{bmatrix},
\qquad
\alpha=1.
\]

Then

\[
Z=\mathcal B^{-1}
=
\begin{bmatrix}
\tfrac43&\tfrac23\\
\tfrac23&\tfrac43
\end{bmatrix}.
\]

For each bus,

\[
\alpha p_iZ_{ii}
=
\frac34\frac43
=
1,
\]

so all local diagonal-impedance conditions hold. However,

\[
\mathcal B-\operatorname{diag}(p)
=
\begin{bmatrix}
\tfrac14&-\tfrac12\\
-\tfrac12&\tfrac14
\end{bmatrix}
\]

has eigenvalues \(3/4\) and \(-1/4\). Therefore G0 fails.

## 7.2 G0 holds while M0 fails

Use

\[
\mathcal B=
\begin{bmatrix}
1&-\tfrac12\\
-\tfrac12&1
\end{bmatrix},
\qquad
p=
\begin{bmatrix}
\tfrac14\\
\tfrac23
\end{bmatrix},
\qquad
\alpha=1.
\]

Then

\[
\mathcal B-\operatorname{diag}(p)
=
\begin{bmatrix}
\tfrac34&-\tfrac12\\
-\tfrac12&\tfrac13
\end{bmatrix}
\succeq0
\]

because its determinant is zero and its diagonal entries are nonnegative. Thus G0 holds. But

\[
Zp=
\begin{bmatrix}
\tfrac79\\
\tfrac{19}{18}
\end{bmatrix},
\]

so M0 fails because \(19/18>1\).

## 7.3 G1 and a selected fixed G2 are incomparable

Let \(M=\mathcal B-\alpha S\).

G1 holds while the selected G2 fails:

\[
M=
\begin{bmatrix}
1&-0.6\\
-0.6&1
\end{bmatrix},
\qquad
r=
\begin{bmatrix}2\\1\end{bmatrix}.
\]

Then

\[
M\mathbf1=
\begin{bmatrix}0.4\\0.4\end{bmatrix}\ge0,
\qquad
Mr=
\begin{bmatrix}1.4\\-0.2\end{bmatrix}\ngeq0.
\]

The selected G2 holds while G1 fails:

\[
M=
\begin{bmatrix}
0.4&-0.6\\
-0.6&1.2
\end{bmatrix},
\qquad
r=
\begin{bmatrix}2\\1\end{bmatrix}.
\]

Then

\[
Mr=
\begin{bmatrix}0.2\\0\end{bmatrix}\ge0,
\qquad
M\mathbf1=
\begin{bmatrix}-0.2\\0.6\end{bmatrix}\ngeq0.
\]

## 7.4 Stable isolated blocks can form an unstable coupled system

Let

\[
J=
\begin{bmatrix}
-1&2\\
2&-1
\end{bmatrix}.
\]

Each isolated diagonal block is stable, but the eigenvalues of \(J\) are \(1\) and \(-3\). The coupled system is unstable.

## 7.5 Uncontrolled inverse approximation can accept an unsafe point

Let

\[
\mathcal B=
\begin{bmatrix}
1&-\tfrac12\\
-\tfrac12&1
\end{bmatrix},
\qquad
p=
\begin{bmatrix}0.6\\0.6\end{bmatrix},
\qquad
\alpha=1.
\]

The diagonal approximation \(\widehat Z=I\) gives

\[
\widehat Zp=
\begin{bmatrix}0.6\\0.6\end{bmatrix}
\le\mathbf1,
\]

and therefore accepts the point. The exact inverse gives

\[
Zp=
\begin{bmatrix}1.2\\1.2\end{bmatrix},
\]

so exact M0 fails.

# 8. Correct implication graph

Under the symmetric Z-matrix assumptions,

\[
G1\Longrightarrow G0,
\qquad
G2(r)\Longrightarrow G0,
\qquad
G3\Longrightarrow G0,
\qquad
G0\Longrightarrow L_i\quad\forall i.
\]

Under inverse positivity and nonnegative exposure,

\[
G1\Longrightarrow M0,
\qquad
M2\Longrightarrow G1\Longrightarrow M0,
\qquad
M0\Longrightarrow L_i\quad\forall i.
\]

Under a valid fixed inverse upper bound,

\[
M1\Longrightarrow M0.
\]

For the verified symmetric PSD Z-matrix class and a complete G3 formulation,

\[
G3\iff G0.
\]

Invalid general converses include

\[
G0\nRightarrow M0,
\qquad
\{L_i\ \forall i\}\nRightarrow G0.
\]

G1 and an arbitrary selected fixed G2 are generally incomparable when \(r\ne\mathbf1\).

# 9. Remaining project verification

The following are not settled by these proofs:

1. symmetry of every implemented \(\mathcal B_t\);
2. nonpositive off-diagonal entries;
3. reference, grounding, and island treatment;
4. positive definiteness and inverse existence;
5. entrywise inverse positivity;
6. exact implemented G1 row equation;
7. nonnegative and consistently based exposure;
8. complete G3 edge coverage and diagonal residual construction;
9. exact zero-exposure handling;
10. exact post-processing used for reported binding classifications;
11. source-level mapping of historical susceptance symbols;
12. common-DAE derivation relating the cosine and sine/skew historical models.
