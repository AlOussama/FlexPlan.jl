# Paper A — Multi-repository execution plan freeze (2026-10-15)

Status: execution_plan_frozen; NOT a new scientific freeze; NOT implementation-verified; A4_ready=false.

Science: research-map paper/c2a-system-strength-expansion-planning-v1 @ 672a61c95525bf1d7a03cf745a754a15a23ce78b
A3 audit: research-map audit/paper-a-a3-implementation-v1 @ a2193ee2312c75d4e123f446156e50df5dabdbc7 (implementation_corrections_still_required; A4_ready=false)
Implementation baseline: FlexPlan.jl master @ 189eec9941dde8ab8720d570a2a6442e2ff1aa6f
Data baseline: PyPSA2MatpowerX gsc-data-format @ cc436ddd56bbc6a5b3655059360e4ed0f284732a

## Governance
The existing 2026-08-09 Paper-A development plan remains governing. This freezes the detailed operationalization of A3-R through A7 and the three-repository workflow. A2F mathematics and theorem assumptions cannot be changed to accommodate existing code. Paper A combines system-strength mathematical formulation and capacity expansion; dynamic small-signal and nonlinear voltage-collapse analysis belong to separate Papers B/C.

## Repository ownership
Research-map owns mathematics, literature, scientific decisions, audits, experimental hypotheses, provenance and manuscript. PyPSA2MatpowerX owns physical input ingestion, PyPSA CSV conversion, technology mappings, costs, capacity blockization, snapshot and duration extraction, case schema exports, and case provenance/validation. FlexPlan.jl owns schema consumption, Julia/JuMP/PowerModels planning, device templates, regional matrices, spectral/linear/conic constraints, independent numerical diagnostics and optimization tests. Avoid duplicate source-specific coefficients and model-policy fields in data.

## Frozen phase sequence
A3.0-MR cross-repository inventory and producer-consumer acceptance; A3.0 reproducible Julia/solver lock; A3.1 regional network and common-base source/exposure mapping; A3.2 availability, dispatch, storage and objective semantics; A3.3 independent generalized eigenvalue/PSD and inverse-burden postprocessing; A3.4 G0/G1/G3 optimization; A3.5 independent equation-to-code closure, approved A4 SHAs; A4 controlled experiments; A5 evidence synthesis; A6 complete manuscript; A7 three independent reviews, submission freeze and journal submission. Never use A4 results as scientific evidence before A3 closes.

## Existing implementation must be reused
FlexPlan already has schema-v2 templates, installed/online blocks, block-dispatch and storage bounds, G1 Gershgorin, objective code, test/pypsa_dataset_optimizer_acceptance.jl. Data producer already has src/block_gscr_converter.jl, src/generate_flexplan_datasets.jl, carrier mapping, schema-v2 case JSON and validation reports under data/flexplan_block_gscr/base_s_5_{3,6,24}snap. Inspect old/open feature branches before merging. Classify each component REUSE_VERIFIED, REUSE_WITH_EXTENSION, REFACTOR_WITH_PROOF, REPLACE_INVALID, or DEFER_OPTIONAL. Do not reimplement working parts from scratch.

## Eleven mandatory multi-repository findings / review gates
MR01: Run actual schema-v2 converter-to-FlexPlan acceptance for all 3/6/24 snapshot fixtures; output file existence alone is insufficient.
MR02: Existing 24-snapshot dataset comprises 24 steps of 3 hours, covering 72 hours; storage and cost chronology must reflect this.
MR03: Current producer exports operation_weight=1; FlexPlan schema documents annual OPEX scaling through scale_data! = 8760*year_scale_factor/number_of_hours. Prove equivalence to scientific sum_t w_t C_op,t without double scaling; distinguish energy duration, representative frequency, scenario probability and startup/shutdown event frequency.
MR04: Producer declares capex_basis=annualized_per_mw_year; avoid duplicate annualization, validate investment scaling exactly once.
MR05: Existing blockization retains about 93.73% of installed capacity (less than converter 95% target); analyze technology/asset-by-asset and correct or justify capacity loss before investment interpretation.
MR06: Unmerged battery-cost-assumption-audit reports serious battery/BESS-GFM full-system cost discrepancy. Mock processed-cost comparison is diagnostic, not accepted paper inputs. Validate actual study-year full battery power-plus-energy CAPEX.
MR07: Synchronous carrier labeling as grid_control_mode=gfm must not conflate physical synchronous sources, synchronous condensers, and GFM converters. Explicitly represent source class and reactance/base provenance.
MR08: Existing five-bus exports do not establish a full candidate set for GFM batteries, synchronous condensers, synchronous/H2 technologies. Prepare and verify selectable, correctly priced candidates.
MR09: Large-case input paths such as data/elec_s_37_csv may depend on externally held datasets. Verify availability, reproducibility and licenses before promising large-scale experiments.
MR10: Feature/adapt-uc-data diverged and contains substantial data deletions; selectively adjudicate, never blind merge. Review feature/battery-cost-assumption-audit and historical cost-basis work independently.
MR11: Original A3 gaps (Schur regionalization, mu_fl/mu_str, a_conn, G0/G3/M0, theorem-domain audit) affect both producer and consumer and must close as cross-repository requirements.

## Twelve producer-consumer acceptance contracts
X01 exact schema-v2 fields for 3/6/24 snapshots, no silent v1 fallback.
X02 exactly one conversion to common p.u. bases for power and susceptance, with analytic checks.
X03 physical AC positive-sequence Y=jBphys and L=-Im(Y), passive retained-node Schur B0=Lrr-Lre Lee^{-1} Ler then decision-dependent source diagonal augmentation; island/reference and shunt accounting explicit.
X04 independent carrier, grid-control mode and GFL/GFM/SYN/SC/H2 source technology class.
X05 0<=n_on<=a_conn*n_inst, dispatch constrained separately by renewable a_res; zero resource availability must not imply disconnection.
X06 chronological duration, representative weights, annualization, scenario probabilities and event economics consistent between producer and FlexPlan.
X07 correct annualized CAPEX incl. storage P+E, status/no-load and startup/shutdown OPEX, no duplicate cost.
X08 n0/nmax, capacity-loss and block rounding independently audited per asset and region.
X09 storage efficiency, cyclic/terminal treatment, power and energy envelopes checked at 3-hour steps.
X10 same B,S,M used by G0/G1/G3; independent exact M0 and generalized eigenvalue diagnostics.
X11 solver/result run manifest with science SHA, converter SHA, FlexPlan SHA, inputs, solver versions, gaps, residuals and costs.
X12 clean-environment regeneration and replay. Track schema_valid, economic_data_valid, theorem_domain_valid separately.

## A3 mathematical closure requirements
G0: exact PSD matrix M_t=B_t-alpha_G S_t, generalized finite-eigenvalue and singular-exposure Schur/range handling. G1: valid unscaled row-sum/Gershgorin sufficient condition. G3: complete undirected-edge 2-by-2 PSD/rotated-SOC plus correct diagonal residuals. For frozen symmetric Z-matrix domain verify G0 iff G3 numerically through feasible-set cross-checks and certified optimal objectives, accounting for multiple optima. Verify symmetry, off-diagonal sign, PSD/inertia, islands, zero rows and edge/reconstruction residuals. Exact M0 Z_t p_fl,t requires invertible strength matrix and must be post-solve validated, not confused with a G0 implication. Run all relevant existing tests and add focused regressions. Only a successful independently verified A3.5 yields A4_ready=true and an approved version triad.

## A4 registered scientific studies
H1 complete edge-SOC equals PSD on declared domain, with objective agreement and cross-feasibility.
H2 linear sufficient bounds may be conservative; compare valid bounds and investment consequences versus exact G3.
H3 row-sum/Laplacian cancellation may bias local strength investment and siting; do not presuppose outcome.
H4 installed/online/operating exposure and integer/continuous block capacity may yield different portfolios.
Family I tests exactness, singular and boundary cases. Family II compares BASE, G1, G3 and small G0 study portfolios using identical data and PF assumptions. Family III compares runtime, model size, memory, solver MIP/conic gap and scalability. Family IV varies physical exposure, costs, strength threshold, network topology and optional convex PF. The existing five-bus fixture is an initial integration/small case, not a sufficient full-paper dataset. Cost-, time- and candidate-validity must pass before economic conclusions. Store independent B,S,M/Zp checks and full run provenance.

## A5–A7
A5 synthesizes RQ1 fidelity, RQ2 economics, RQ3 technology/siting, RQ4 complexity; separate theorems from case-study findings and record negative/null hypotheses.
A6 updates the existing A2F LaTeX/BibTeX manuscript into a self-contained journal narrative; include only evidence-supported conclusions, proof qualifications, limitations and reproducible figures. Governance labels stay internal.
A7 performs independent power-system/strength review, matrix-optimization review and planning/reproducibility review, adjudicates all critical comments, freezes verified code/data/results/manuscript SHAs, then submits to journal. Acceptance is not a guaranteed deliverable.

## Non-scope and initial action
Do not expand the core to endogenous transmission planning, full N-1, full UC chronology, controller design, Paper B dynamics or Paper C voltage collapse. G2, M1/M2 optimization and LPAC are optional unless registered for scientific necessity. Immediate next task is A3.0-MR inventory, cross-repo integration and input-economics reconciliation, followed by minimal corrective branches in the two implementation repos. Preserve prior freeze and audits.

## Archive note
This GitHub document records a self-contained canonical operational freeze. A longer local source artifact named Paper_A_Masterplan_MultiRepo_2026-10-15_v2.md also exists; its exact byte-for-byte text has not been uploaded to GitHub by this action. Do not claim the two artifacts are identical.
