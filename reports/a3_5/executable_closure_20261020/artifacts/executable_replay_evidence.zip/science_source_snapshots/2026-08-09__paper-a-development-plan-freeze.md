---
document_type: c2a_paper_a_development_plan_freeze
status: frozen_for_execution
date: 2026-08-09
repository: AlOussama/research-map
branch: write/c2a-integrated-dissertation-rewrite-v1
parent_planning_freeze: docs/reports/C2_constraints/C2A_voltage_stability/publication_planning/2026-08-09__c2a-journal-paper-cluster-and-reuse-freeze.md
parent_planning_freeze_blob: 99bc5f9336577e8f283cf0a09e0df5fd30b470bd
parent_planning_head: cbe19a0775b893c10b7a055618d90494923f3789
scientific_source_writer_sha: 5c64991a180d54e3f2d76090f79e285f4a34669b
scientific_artifact_sha: 39bc91c55b0d601d9d2f32eb80be8772d6e9c4e9
scientific_closure: true
frozen_theorem_package: T-C2A-001_through_T-C2A-040
paper_a_theorem_scope: T-C2A-001_through_T-C2A-028
plan_granularity: phase_level_no_microsteps
modifies_scientific_freeze: false
---

# Paper A — detailed development plan freeze

## 1. Purpose and governing status

This document freezes the development plan for **Paper A — System-Strength Formulations for Expansion Planning**.

Paper A is the combined publication unit previously identified as the union of the former system-strength theory concept and the system-strength-constrained planning concept. The governing publication decision is therefore

\[
\boxed{
\text{system-strength mathematical hierarchy}
+
\text{planning realization}
=
\text{one Paper A}.
}
\]

This plan is intentionally defined at **phase level**. It specifies research objectives, scientific content, deliverables, dependencies, and review gates, but it does not prescribe file-level, code-line-level, equation-by-equation implementation tasks, paragraph-writing tasks, or other micro steps.

The scientifically closed dissertation remains the source of truth for the frozen mathematical content. This development plan does not reopen T-C2A-001 through T-C2A-040 and does not promote any unverified Track-C predicate to a scientific fact.

---

# 2. Paper A central research question

The frozen central question is:

> **How can multi-infeed/system-strength requirements be represented by mathematically classified, optimization-compatible constraints for generation and transmission expansion planning, while making explicit which formulations are exact, sufficient, conservative, incomparable, or nonlinear?**

The paper is **not** to be framed merely as adding a gSCR constraint to a capacity-expansion problem. Its intended contribution is the combination of rigorous formulation relationships and their actual planning consequences.

The paper therefore has four coupled contribution pillars:

1. **Exact/reference system-strength formulation** based on the generalized-eigenvalue coordinate G0, including singular- and zero-exposure treatment.
2. **Mathematical hierarchy of alternative formulations** G1/G2/G3, local/M0, M1/M2, including implication, non-implication, incomparability, exactness and conservatism results.
3. **Integrated expansion-planning realization** with decision-dependent network/source stiffness, investment/availability/commitment/dispatch variables, and explicit exposure semantics.
4. **Quantified computational and planning consequences** showing what is gained or lost when a tractable formulation replaces an exact/reference formulation.

---

# 3. Overall development structure

Paper A will be developed through seven substantive phases:

\[
\boxed{
\begin{array}{c}
\text{A0 Scope and contribution freeze}\\
\downarrow\\
\text{A1 Paper mathematics}
+\text{A2 Integrated planning formulation}\\
\downarrow\\
\text{A3 Equation-to-code and formulation verification}\\
\downarrow\\
\text{A4 Numerical experiment programme}\\
\downarrow\\
\text{A5 Scientific synthesis of results}\\
\downarrow\\
\text{A6 Journal manuscript construction}\\
\downarrow\\
\text{A7 Independent review and submission freeze}
\end{array}}
}
\]

A1 and A2 are intentionally coupled. The novelty of Paper A lies in combining the mathematical hierarchy with the planning formulation; they should therefore not be developed as independent publication tracks.

A3 is a hard gate before numerical results can be interpreted scientifically.

A4 and A5 must precede final manuscript conclusions: the paper narrative should be driven by verified findings rather than by retrospective selection of experiments to support a pre-written conclusion.

---

# 4. Phase A0 — Paper scope and contribution freeze

## Objective

Convert the dissertation-level cluster into a precise journal-paper scope that is narrow enough for a coherent paper but broad enough to support the combined theory-and-planning contribution.

## Scientific decisions to freeze

The scope must define:

- the retained system-strength matrix class;
- the exposure definitions that will actually be compared;
- the exact/reference formulation used for benchmarking;
- the tractable formulations included in the numerical comparison;
- the investment and operating decisions represented in the planning model;
- whether network expansion, source-strength expansion, or both are decision variables;
- the security states, scenarios, and contingencies included in the study;
- the interpretation of the strength threshold \(\alpha\);
- the numerical questions used to substantiate the contribution;
- the explicit boundaries outside Paper A, especially nonlinear voltage-collapse and small-signal-dynamic claims.

## Required paper-level contribution statement

The preferred contribution architecture is:

### Contribution A — exact/reference benchmark

For positive exposure,

\[
\gamma^{GE}
=
\lambda_{\min}\!\left(S^{-1/2}\mathcal B S^{-1/2}\right),
\]

with

\[
\boxed{
\gamma^{GE}\ge\alpha
\iff
\mathcal B-\alpha S\succeq0.
}
\]

The paper must retain the scientifically correct singular-exposure and zero-exposure treatment rather than assuming that every exposure coordinate is strictly positive.

### Contribution B — formulation hierarchy

The main formulation family is

\[
\boxed{
G0,\;G1,\;G2,\;G3,\;M0,\;M1,\;M2
}
\]

with local metrics used where they support interpretation.

The retained logical relations include

\[
G1\Rightarrow G0,
\qquad
G2(r)\Rightarrow G0,
\qquad
G3\Rightarrow G0,
\]

with conditional relations such as

\[
M2\Rightarrow G1\Rightarrow M0
\]

under the frozen assumptions, and the important rejected implication

\[
\boxed{G0\not\Rightarrow M0.}
\]

The G3/closed-SDD theorem is to be treated as a central theoretical contribution rather than as an incidental relaxation.

### Contribution C — planning realization

The mathematical formulations are embedded into a planning model through decision-dependent exposure and stiffness:

\[
S=S(x^{inv},x^{avail},x^{commit},x^{dispatch},\ldots),
\]

and

\[
\mathcal B
=
\mathcal B(x^{network},x^{source},x^{status},\ldots).
\]

The paper must make explicit which optimization classes arise under the actual decision dependence.

### Contribution D — quantified consequences

The numerical study must answer how alternative formulations differ in:

- feasible-set fidelity;
- conservatism;
- investment decisions;
- spatial allocation of strengthening;
- system cost;
- operating consequences;
- computational burden;
- sensitivity to exposure definition and topology/security assumptions.

## A0 completion gate

A0 is complete when each planned paper claim is tied either to:

1. a closed scientific theorem/result already available in the dissertation; or
2. a clearly defined implementation/numerical result to be produced in later phases.

No contribution should depend on an undefined future claim.

---

# 5. Phase A1 — Paper-specific mathematical formulation

## Objective

Distill the closed dissertation mathematics into a compact, self-contained mathematical backbone tailored to Paper A.

The dissertation is the provenance source; the paper must not reproduce the dissertation structure mechanically.

## Common mathematical object

The paper should organize the alternative formulations around

\[
\boxed{M(x)=\mathcal B(x)-\alpha S(x).}
\]

This common object provides a clean bridge between the strength theory and the planning decisions.

## Core content

### 5.1 Network-strength object

Only the physical/network material necessary to define the retained stiffness matrix should be included. The paper should establish the relationship to the physical admittance model while preserving the distinction

\[
B^{phys}\neq\mathcal B\neq J_{QV}\neq J_{QV}^{red}.
\]

The full dissertation derivation of AC power-flow equations is not required in the main paper unless directly needed for the study.

### 5.2 Exposure semantics

The paper should preserve the distinction among

\[
S^{nom},
\qquad
S^{on},
\qquad
S^{op},
\qquad
S^I,
\]

but should include only the variants actually used or needed to interpret the numerical study.

Different exposure choices are physically different definitions, not merely alternative notation.

### 5.3 Exact benchmark G0

G0 is the principal reference condition. Both positive and singular exposure cases must be treated correctly.

The generalized Schur treatment remains relevant for exact elimination and zero-exposure coordinates. For

\[
\begin{bmatrix}
A&B\\
B^\top&C
\end{bmatrix}\succeq0,
\]

with singular \(C\succeq0\), the condition retains both

\[
(I-CC^\dagger)B^\top=0
\]

and

\[
A-BC^\dagger B^\top\succeq0.
\]

The range condition is not optional.

### 5.4 Local and M0 formulations

With

\[
Z=\mathcal B^{-1},
\]

retain

\[
\rho_i^{diag}
=
\frac{1}{Z_{ii}p_i},
\qquad
\rho_i^{Zp}
=
\frac{1}{(Zp)_i},
\]

and M0

\[
Zp\le\alpha^{-1}\mathbf1.
\]

The accepted counterexamples should be retained in paper-oriented form because they establish that intuitive scalar/local hierarchies are not valid in general.

In particular,

\[
\boxed{G0\not\Rightarrow M0}
\]

must remain visible.

### 5.5 G1 and fixed G2

For symmetric Z-matrix \(M\), retain

\[
M\mathbf1\ge0
\Rightarrow
M\succeq0
\]

and fixed

\[
Mr\ge0,
\qquad r\in\mathbb R_{++}^n.
\]

The relations

\[
G1\Rightarrow G0,
\qquad
G2(r)\Rightarrow G0,
\qquad
G2(\mathbf1)=G1
\]

remain central.

The explicit two-way G1/G2 incomparability counterexamples should be retained because they prevent an unsupported ranking between arbitrary fixed scalings.

### 5.6 Complete G3 / closed-SDD formulation

The G3 edge construction

\[
\begin{bmatrix}
q_{ij}&m_{ij}\\
m_{ij}&q_{ji}
\end{bmatrix}\succeq0,
\qquad
m_{ii}-\sum_jq_{ij}\ge0
\]

is rotated-SOC representable.

The central theorem is that every symmetric PSD Z-matrix belongs to the closed scaled-diagonally-dominant cone, including singular, reducible, and zero-row cases.

Consequently, under complete and correct project edge/residual representation, the project-level G3 formulation can satisfy

\[
\boxed{G3\iff G0}
\]

for the frozen matrix class.

The publication must distinguish the mathematical theorem from the separate implementation predicates required for project exactness.

### 5.7 M1 and M2

M1 and M2 remain scalable sufficient formulations. Under their declared assumptions,

\[
M1\Rightarrow M0,
\]

and

\[
M2\Rightarrow G1\Rightarrow M0.
\]

They must not be presented as exact M0 reformulations unless a new theorem proves such exactness.

### 5.8 Woodbury and Neumann

The exact Woodbury identity and bounded Neumann approximation are available scientifically, but they are secondary to the main Paper-A narrative.

They should appear in the main paper only if the implemented method uses them materially. Otherwise they should be compressed or moved to supplementary/appendix material.

## A1 completion gate

A1 is complete when the paper-specific mathematical formulation:

- is self-contained;
- preserves every retained assumption and implication direction;
- uses paper-specific theorem numbering rather than repository theorem IDs in publication prose;
- contains no dissertation audit/closure language;
- contains only mathematics relevant to the Paper-A research question.

---

# 6. Phase A2 — Integrated expansion-planning formulation

## Objective

Build one common capacity-expansion/dispatch model into which the alternative strength formulations can be inserted as interchangeable security modules.

This common modelling backbone is essential for a fair scientific comparison.

## Planning hierarchy

The model retains the distinction

\[
\boxed{
0\le n^{on}\le n^{avail}\le n^{inst}\le n^{max}
}
\]

so installed, available, online, and dispatched capacity are not conflated.

The planning formulation should include only the operational detail needed to support the actual research questions, while preserving dimensional correctness of objective and chronology.

## Decision-dependent exposure

The planning layer may use

\[
S^{nom}(x^{inv}),
\]

\[
S^{on}(x^{inv},x^{avail},x^{commit}),
\]

\[
S^{op}(x^{dispatch}),
\]

and, only when physically supported,

\[
S^I(x^{control},V,\text{limits}).
\]

The selected definitions must be tied to explicit physical questions.

Storage charging must not automatically become nonnegative strength exposure, and GFM devices must not automatically be counted in a GFL denominator.

## Decision-dependent network/source stiffness

Use the general planning form

\[
\boxed{
\mathcal B_{y,d,h,\omega,c}
=
\mathcal B^0_{y,d,h,\omega,c}
+
\Delta\mathcal B^{network}_{y,d,h,\omega,c}
+
\Delta\mathcal B^{source}_{y,d,h,\omega,c}.
}
\]

Candidate lines, transformers, synchronous/source-strength assets, and topology/status decisions can change:

- diagonal and off-diagonal entries;
- sparsity;
- islands and reference treatment;
- invertibility;
- the G3 edge catalogue;
- the validity of inverse-based formulations.

Decision-dependent Schur/Kron reduction is generally non-affine when the eliminated-block inverse depends on decisions.

## Optimization-class interpretation

The paper should preserve the conditional computational classification:

\[
\begin{array}{ccl}
\text{G0} &\rightarrow& \text{SDP/MISDP on a fixed retained space with affine }M(x),\\
\text{G1} &\rightarrow& \text{LP/MILP under affine realization},\\
\text{fixed G2} &\rightarrow& \text{LP/MILP under affine realization},\\
\text{G3} &\rightarrow& \text{SOCP/MISOCP under complete affine edge realization},\\
\text{exact M0} &\rightarrow& \text{generally nonlinear/bilinear when }\mathcal B(x)\text{ and burden variables are both decision dependent.}
\end{array}
\]

M1/M2 remain scalable sufficient routes under their own assumptions.

Woodbury remains an identity, not a convexification.

Neumann truncation remains an approximation requiring convergence, remainder, and one-sided safety treatment.

## Fair-comparison principle

Wherever possible, numerical comparisons should satisfy

\[
\boxed{
\text{same planning model}
+
\text{same data}
+
\text{same operating states}
+
\text{different strength formulation}.
}
\]

This prevents differences in planning assumptions from being misinterpreted as differences caused by the strength formulation.

## A2 completion gate

A2 is complete when every compared strength formulation has:

- an explicit exposure definition;
- an explicit network/stiffness definition;
- a clear optimization realization;
- a clear physical interpretation;
- a common planning baseline for fair comparison.

---

# 7. Phase A3 — Equation-to-code and formulation verification

## Objective

Establish that the implemented models represent the paper equations and assumptions before numerical results are interpreted scientifically.

This phase is the Paper-A implementation subset of Track C.

It is not merely software QA: it verifies whether the computational experiments actually test the scientific formulations described in the paper.

## Verification scope

The verification must establish, at a system level:

- construction, dimensions, base and units of \(\mathcal B\);
- symmetry/Z-sign/PD/inverse-positivity assumptions where invoked;
- exposure eligibility, nonnegativity and normalization;
- exact implementation of G0;
- exact row equation for G1;
- fixed scaling and sign assumptions for G2;
- complete G3 edge/residual representation;
- M0 inverse/burden construction;
- M1 lower-bound/inverse-upper-bound assumptions;
- M2 weight construction;
- zero-exposure handling;
- topology/island/reference treatment;
- coupling of investment, availability, commitment and dispatch to exposure;
- coupling of network/source investments to \(\mathcal B\);
- independent post-solve reconstruction of the high-risk matrices and metrics.

## Critical G3 exactness gate

The theorem-level statement that symmetric PSD Z-matrices lie in the closed-SDD cone does not automatically prove that a particular code implementation of G3 is complete.

A numerical claim of project-level

\[
G3\iff G0
\]

requires verification of the corresponding project predicates: edge coverage, signed off-diagonal preservation, residual representation, and matrix-class assumptions.

## A3 completion gate

A3 is complete only when the implemented model is reproducibly mapped to the paper equations and all assumptions required for the planned numerical comparisons have been checked or explicitly marked unavailable.

No numerical result should be used as paper evidence before this gate is satisfied.

---

# 8. Phase A4 — Numerical experiment programme

## Objective

Produce the evidence required to transform the mathematical hierarchy into a power-systems planning contribution.

The experiment programme should be organized around research questions rather than around an arbitrary collection of test cases.

Four experiment families are required.

| Experiment family | Main question | Primary comparison |
|---|---|---|
| **I. Formulation geometry and fidelity** | How do the feasible sets and margins differ? | G0 versus G1/G2/G3/M0/M1/M2 |
| **II. Planning consequences** | How do formulations change optimal investment and operation? | cost, capacity mix, strengthening type/location, dispatch/commitment effects |
| **III. Computational performance** | What tractability benefit is obtained? | runtime, memory, solver effort, scaling with problem size |
| **IV. Robustness and modelling semantics** | Are conclusions stable under alternative physically valid modelling choices? | exposure definitions, contingencies, topology/source assumptions |

## 8.1 Experiment family I — formulation geometry and fidelity

The study should compare exact/reference strength against tractable formulations at common system states.

For G0, the reference margin can be expressed through

\[
\gamma^{GE}
=
\lambda_{\min}(S^{-1/2}\mathcal B S^{-1/2}).
\]

For M0, where valid, compare against

\[
\max_i (Zp)_i.
\]

The analysis should distinguish:

- exact agreement;
- conservative rejection;
- formulation incomparability;
- discrepancies caused by violated assumptions;
- numerical effects near singular/boundary cases.

Targeted cases should include mechanisms represented by the accepted analytical counterexamples rather than relying only on random operating points.

## 8.2 Experiment family II — planning consequences

The paper must quantify not only objective-value differences but also structural investment consequences.

Relevant outputs include

\[
\Delta C^{total},
\quad
\Delta x^{generation},
\quad
\Delta x^{network},
\quad
\Delta x^{source},
\]

and changes in the spatial distribution of system-strength resources.

A key scientific question is:

> Does a conservative formulation merely increase total investment, or does it change where and what the planning model invests in?

The answer can be more important than aggregate cost differences.

## 8.3 Experiment family III — computational performance

The computational comparison should cover increasing network/problem size or increasing planning/security complexity.

The core trade-off is

\[
\boxed{
\text{tractability}
\leftrightarrow
\text{conservatism}
\leftrightarrow
\text{planning quality}.
}
\]

The final paper should quantify this trade-off rather than report solver time in isolation.

## 8.4 Experiment family IV — robustness and modelling semantics

Where physically meaningful, compare at least two exposure concepts, for example

\[
S^{nom}
\quad\text{and}\quad
S^{on},
\]

with operating-power exposure

\[
S^{op}
\]

included if the study's physical interpretation supports it.

The study should also test selected contingency/topology/source-strength variants sufficient to determine whether the main conclusions are robust or model-specific.

## Required numerical evidence categories

| Question | Evidence expected |
|---|---|
| exactness / tightness | G1/G2/G3/M1/M2 relative to G0 and, where valid, exact M0 |
| conservatism | margin distributions, rejected G0-feasible states, certificate slack |
| incomparability | empirical states where selected G1/G2 classifications differ |
| scalability | runtime, memory and relevant solver metrics versus problem size |
| planning consequences | CAPEX/OPEX, technology mix and strengthening investments |
| locational consequences | binding buses, edges and assets |
| exposure semantics | comparison of physically meaningful \(S\)-definitions |
| topology/security | candidate networks/source assets and selected contingencies |
| post-solve validity | independent reconstruction of \(\mathcal B,S,Z,G0,M0\) and assumptions |

## A4 completion gate

A4 is complete when the experiment suite covers both sides of the paper's contribution:

1. mathematical fidelity/conservatism; and
2. actual planning/computational consequences.

A numerical study that covers only one side is insufficient for the combined Paper-A concept.

---

# 9. Phase A5 — Scientific synthesis of numerical results

## Objective

Convert the verified experiment results into defensible scientific findings.

The synthesis should be organized around four high-level research questions.

## RQ1 — Mathematical fidelity

How closely do the alternative formulations reproduce G0 or M0 on their declared valid domains?

The synthesis should identify exact, nearly exact, conservative, and incomparable behavior rather than forcing a single total ordering of formulations.

## RQ2 — Economic consequence

How much does formulation conservatism change optimal investment and operating cost?

The answer should distinguish the cost effect from structural changes in the investment portfolio.

## RQ3 — Structural/locational consequence

Which assets, buses, interfaces, or technology categories change because of the strength formulation?

The analysis should distinguish additional generation capacity from genuine network/source-strength investment.

## RQ4 — Computational consequence

Which formulation provides the most useful compromise among:

- scientific guarantee;
- feasible-set fidelity;
- computational burden;
- planning solution quality?

## Desired synthesis structure

The strongest final paper message should have the form

\[
\boxed{
\text{formulation class}
\rightarrow
\text{guarantee}
\rightarrow
\text{conservatism}
\rightarrow
\text{computational burden}
\rightarrow
\text{planning consequence}.
}
\]

This is preferable to isolated statements such as “G3 is faster than G0” or “G1 produces more investment.”

## A5 completion gate

A5 is complete when each major conclusion:

- is supported by reproducible numerical evidence;
- is consistent with the theorem-level relation of the formulation;
- clearly separates general mathematical results from case-study observations;
- states the domain in which the conclusion applies.

---

# 10. Phase A6 — Journal manuscript construction

## Objective

Construct the manuscript around the combined mathematical/computational narrative.

The final paper should not reproduce dissertation governance language such as scientific freeze, Track-C status, theorem repository IDs, closure adjudication, or implementation-audit terminology.

These remain internal provenance information only.

## Recommended manuscript architecture

| Section | Role |
|---|---|
| **1. Introduction** | system-strength planning problem, literature gap, contributions |
| **2. System-strength model** | retained network space, \(\mathcal B\), exposure and assumptions |
| **3. Exact/reference formulations** | G0, generalized eigenvalue, singular/zero-exposure treatment |
| **4. Alternative strength formulations** | local/M0, G1/G2/G3, M1/M2 |
| **5. Mathematical relation and tractability hierarchy** | theorem/implication map, non-implications, exactness/conservatism, optimization classes |
| **6. Expansion-planning formulation** | investment, operation, network/source strengthening, exposure coupling |
| **7. Computational implementation and experiment design** | realization of formulations and common comparison setup |
| **8. Numerical results** | fidelity, planning consequences, scalability, robustness |
| **9. Discussion and applicability** | interpretation, threshold/model limits, when each formulation is appropriate |
| **10. Conclusions** | principal findings and limitations |

## Reuse policy

The paper may reuse the closed mathematics, proofs, counterexamples, definitions, and assumptions after journal-oriented rewriting.

The following should not be copied into publication prose:

- repository theorem IDs such as T-C2A-xxx;
- scientific-freeze language;
- review/closure status;
- project-predicate governance wording;
- dissertation appendix registers as audit artifacts.

Internally, a provenance crosswalk may map dissertation theorem IDs to paper theorem/proposition numbering.

## A6 completion gate

A6 is complete when the manuscript:

- tells one coherent theory-to-planning story;
- contains only the mathematics required to support that story;
- reports verified numerical findings rather than planned validation tasks;
- clearly separates theorem-level claims from empirical observations;
- is internally traceable to the closed dissertation and verified implementation evidence.

---

# 11. Phase A7 — Independent paper review and submission freeze

## Objective

Subject the complete manuscript and evidence package to independent review before submission.

The review should cover three complementary perspectives.

## Review perspective 1 — Power-system/system-strength

Focus on:

- physical meaning of \(\mathcal B\);
- SCR/gSCR/system-strength literature alignment;
- exposure/denominator interpretation;
- source-strength assumptions;
- network reduction and topology;
- threshold transfer limits;
- physical interpretation of numerical results.

## Review perspective 2 — Mathematical/optimization

Focus on:

- Schur/generalized-Schur conditions;
- generalized-eigenvalue equivalence;
- M-matrix and inverse-positive assumptions;
- G1/G2/G3 implication hierarchy;
- closed-SDD/G3 theorem;
- counterexamples and invalid converses;
- convexity/optimization-class claims;
- nonlinear/bilinear classifications.

## Review perspective 3 — Planning/reproducibility

Focus on:

- capacity-expansion semantics;
- installed/available/online/dispatch distinctions;
- chronology and objective weighting;
- implementation fidelity;
- numerical experiment design;
- reproducibility;
- adequacy of the evidence supporting planning conclusions.

## A7 completion gate

Paper A is ready for submission freeze only when there are no unresolved blocking issues in:

- scientific formulation;
- implementation fidelity;
- numerical evidence;
- manuscript claim scope.

New evidence that contradicts the frozen scientific package should trigger a separate scientific reconsideration process rather than being silently accommodated in the manuscript.

---

# 12. Phase dependencies and non-microstep execution rule

The frozen dependency structure is:

1. A0 fixes the paper's claims and scope.
2. A1 and A2 define the coupled mathematical/planning model.
3. A3 verifies that the implementation represents that model.
4. A4 produces the numerical evidence.
5. A5 determines the defensible scientific conclusions.
6. A6 writes the final journal narrative around those conclusions.
7. A7 independently reviews and freezes the submission package.

The plan intentionally does **not** prescribe micro tasks such as individual function edits, file naming, line-by-line proof rewriting, solver commands, plotting commands, paragraph drafting order, or daily work schedules. Such details should be generated only when a specific phase is actively executed.

---

# 13. Frozen Paper-A success criteria

Paper A is successful only if all of the following are demonstrated together:

### Mathematical clarity

The reader can determine which formulation is exact, sufficient, conservative, incomparable, or nonlinear and under which assumptions.

### Planning relevance

The reader can see how those mathematical differences affect actual expansion and operating decisions.

### Computational relevance

The paper quantifies the tractability benefit obtained by replacing an exact/reference formulation with a scalable certificate.

### Physical traceability

The network-strength matrix, exposure denominator, source contributions, topology and operating status are physically and dimensionally declared.

### Reproducibility

The main numerical conclusions can be independently reconstructed from the implemented model and reported data.

The central Paper-A message should therefore converge to

\[
\boxed{
\text{formulation guarantee}
+
\text{planning realization}
+
\text{quantified conservatism}
+
\text{computational impact}
+
\text{investment consequence}.
}
\]

---

# 14. Frozen handoff summary

```yaml
paper: A
title_working: System-Strength Formulations for Expansion Planning
status: development_plan_frozen
scope:
  combines_system_strength_theory_and_planning: true
  theorem_source: T-C2A-001_through_T-C2A-028
  static_voltage_stability_as_primary_topic: false
  small_signal_dynamics_as_primary_topic: false

phases:
  A0: scope_and_contribution_freeze
  A1: paper_specific_mathematical_formulation
  A2: integrated_expansion_planning_formulation
  A3: equation_to_code_and_formulation_verification
  A4: numerical_experiment_programme
  A5: scientific_synthesis_of_results
  A6: journal_manuscript_construction
  A7: independent_review_and_submission_freeze

execution_rule:
  granularity: phase_level
  microsteps_in_frozen_plan: prohibited
  A1_and_A2_developed_jointly: true
  A3_required_before_scientific_interpretation_of_numerics: true
  A4_and_A5_drive_final_manuscript_conclusions: true

numerical_evidence_required:
  formulation_fidelity: true
  conservatism: true
  planning_consequences: true
  locational_consequences: true
  computational_scalability: true
  exposure_semantics: true
  topology_and_security_robustness: true
  independent_postsolve_reconstruction: true

scientific_governance:
  scientific_closure_reopened: false
  frozen_theorem_package_modified: false
  new_contradictory_evidence_requires_separate_reconsideration: true
```
