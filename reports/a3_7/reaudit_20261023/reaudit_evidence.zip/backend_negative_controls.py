import ast,pathlib,json,collections,itertools,copy
from fractions import Fraction as Q
import numpy as np
r=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
src=repo/'scripts/paper_a/verify_native_g3.py'
defs=[n for n in ast.parse(src.read_text()).body if isinstance(n,ast.FunctionDef)]
ns=dict(Q=Q,np=np,collections=collections,itertools=itertools,json=json)
exec(compile(ast.Module(body=defs,type_ignores=[]),str(src),'exec'),ns)
dr=r/'matrix/bess_premium_3snap_G3_production_costscale'
load=lambda name:json.loads((dr/name).read_text())
cached=load('solver_input.mof.json');native=load('actual_backend.mof.json');mapping=load('backend_variable_map.json')
verify=ns['backend_identity'];assert verify(cached,native,mapping)
results=[]
for mode in ['wrong_quadratic_sign','missing_square_term','inconsistent_link_rhs','changed_interval_endpoint']:
    bad=copy.deepcopy(native)
    quad=next(c for c in bad['constraints'] if c['function']['type']=='ScalarQuadraticFunction')
    if mode=='wrong_quadratic_sign':
        next(t for t in quad['function']['quadratic_terms'] if t['variable_1']!=t['variable_2'])['coefficient']=2.
    elif mode=='missing_square_term':
        quad['function']['quadratic_terms']=[t for t in quad['function']['quadratic_terms'] if t['variable_1']!=t['variable_2']]
    elif mode=='inconsistent_link_rhs':
        var=quad['function']['quadratic_terms'][0]['variable_1']
        c=next(c for c in bad['constraints'] if c['function']['type']=='ScalarAffineFunction' and c['set']['type']=='EqualTo' and any(t['variable']==var for t in c['function']['terms']))
        c['set']['value']+=1.
    else:
        c=next(c for c in bad['constraints'] if c['function']['type']=='Variable' and c['set']['type']=='Interval')
        c['set']['upper']+=1.
    rejected=False
    try:verify(cached,bad,mapping)
    except AssertionError:rejected=True
    assert rejected,mode
    results.append(dict(mode=mode,rejected=True))
(r/'backend_negative_controls.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print('4/4 backend sign/term/RHS/interval corruptions rejected')
