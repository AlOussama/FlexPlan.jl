using JuMP,Test,JSON,SHA
import HiGHS
include("D:/Projekte/Code/FlexPlan_UC_GSCR/scripts/paper_a/AP3Pipeline.jl")
const P=AP3Pipeline;const MOI=JuMP.MOI
const R=joinpath(@__DIR__,"filter_regressions");mkpath(R)
results=Any[]
@testset "A3.6 preserved filter cause and native fail-closed boundary" begin
    a=[4.5830185178677806e-11,4.5830185178677806e-11,1.3046247794859574e-10]
    rhs=3.025002202302713e-8
    for (mode,threshold,k,status) in [("default",1e-9,0,MOI.INFEASIBLE),
        ("accepted_fix",1e-12,0,MOI.OPTIMAL),("exact_row_scaling",1e-9,33,MOI.OPTIMAL)]
        m=Model(HiGHS.Optimizer);@variable(m,x[1:3]>=0);@variable(m,0<=z<=1,Int)
        aa=a.*2.0^k;rr=rhs*2.0^k
        @constraint(m,sum(aa[i]*x[i] for i in 1:3)>=rr);@objective(m,Min,0.)
        for (key,value) in (("threads",1),("small_matrix_value",threshold),("mip_feasibility_tolerance",1e-8));set_optimizer_attribute(m,key,value);end
        optimize!(m);@test termination_status(m)==status
        @test all(Rational{BigInt}(aa[i])==Rational{BigInt}(a[i])*Rational{BigInt}(2)^k for i in 1:3)
        @test Rational{BigInt}(rr)==Rational{BigInt}(rhs)*Rational{BigInt}(2)^k
        MOI.write_to_file(unsafe_backend(m),joinpath(R,mode*"_actual_highs.lp"))
        push!(results,Dict("mode"=>mode,"termination"=>string(termination_status(m)),"threshold"=>threshold,"power_two"=>k))
    end
    a2=1.2740476362167553e-13
    exact=Rational{BigInt}(rhs)/Rational{BigInt}(a2)
    @test Rational{BigInt}(a2)*exact==Rational{BigInt}(rhs)
    tiny=Model(HiGHS.Optimizer);@variable(tiny,x>=0);@variable(tiny,0<=z<=1,Int)
    @constraint(tiny,a2*x>=rhs);@objective(tiny,Min,0.)
    for (key,value) in (("threads",1),("small_matrix_value",1e-12),("mip_feasibility_tolerance",1e-8));set_optimizer_attribute(tiny,key,value);end
    optimize!(tiny);@test termination_status(tiny)==MOI.INFEASIBLE
    guarded=P.solve!((model=tiny,),P.native_g3_optimizer())
    @test guarded["termination"]=="OPTIMIZE_NOT_CALLED" && guarded["numerical_validation"]=="rejected_input"
    push!(results,Dict("mode"=>"adversarial_below_filter","raw_highs_termination"=>string(termination_status(tiny)),
        "native_guard"=>guarded,"exact_feasible_x"=>string(exact)))
    for (mode,threshold,expected) in [("frozen_oa_original",1e-9,MOI.INFEASIBLE),("frozen_oa_fix",1e-12,MOI.OPTIMAL)]
        m=read_from_file(joinpath(@__DIR__,"../validation/prior/experiments/stages/oa_frozen.mof.json"))
        set_optimizer(m,HiGHS.Optimizer)
        for (key,value) in (("threads",1),("small_matrix_value",threshold),("mip_feasibility_tolerance",1e-8),("mip_rel_gap",1e-8),("time_limit",120.));set_optimizer_attribute(m,key,value);end
        optimize!(m);@test termination_status(m)==expected
        MOI.write_to_file(unsafe_backend(m),joinpath(R,mode*"_actual_highs.lp"))
        push!(results,Dict("mode"=>mode,"termination"=>string(termination_status(m)),"threshold"=>threshold))
    end
end
open(io->JSON.print(io,results,2),joinpath(R,"results.json"),"w")
