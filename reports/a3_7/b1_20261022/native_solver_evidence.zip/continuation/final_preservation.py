import pathlib,hashlib,json,subprocess,zipfile
r=pathlib.Path(__file__).resolve().parent;repo=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
pre=pathlib.Path(r'D:\Downloads\A3_7_B1_preflight_20261022_203803')
base=json.loads((r/'authority_preflight.json').read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo).decode()
foreign={n:sha(repo/n) for n in base['foreign_sha256']}
assert foreign==base['foreign_sha256'] and len(foreign)==28
assert not any(n.startswith('audit/') for n in git('ls-files','audit').splitlines())
manifest=json.loads((pre/'sha256_manifest.json').read_text())
assert all((pre/n).stat().st_size==v['size'] and sha(pre/n)==v['sha256'] for n,v in manifest.items())
branch=base['new_branch'];ignored={'refs/heads/'+branch,'refs/remotes/origin/'+branch}
def refs(text):return {line.split()[1]:line.split()[0] for line in text.splitlines() if line.split()[1] not in ignored}
assert refs(base['refs_before'])==refs(git('show-ref')),'foreign refs changed'
def worktrees(text):
    result={}
    for block in text.strip().split('\n\n'):
        lines=block.splitlines();p=lines[0].removeprefix('worktree ')
        result[p]=lines[1:]
    return result
before=worktrees(base['worktrees_before']);after=worktrees(git('worktree','list','--porcelain'))
assert set(before)==set(after) and len(after)==7
assert all(before[p]==after[p] for p in before if pathlib.Path(p).resolve()!=repo.resolve())
assert not git('diff','15ba10c193a562a48cb0e1dcc6fa12d922ac0613','HEAD','--','src','data','reports/a3_5','reports/a3_6','reports/ap3_runs')
m=json.loads((repo/'reports/a3_6/reaudit_20261021/reproduction_manifest.json').read_text())
zpath=repo/'reports/a3_6/reaudit_20261021'/m['archive']['path']
assert sha(zpath)==m['archive']['sha256'] and zpath.stat().st_size==m['archive']['bytes']
with zipfile.ZipFile(zpath) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(m['entries'])==130
    for e in m['entries']:
        b=z.read(e['path']);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
out=dict(foreign_28_sha256=foreign,foreign_28_byte_identical=True,foreign_audit_not_tracked=True,
    preflight_files_preserved=len(manifest),preflight_manifest_sha256=sha(pre/'sha256_manifest.json'),
    foreign_refs_identical=True,existing_worktrees=7,new_worktrees_created=0,
    other_worktrees_identical=True,protected_source_data_and_historical_report_git_diff_empty=True,
    reaudit_archive_entries_verified=130,reaudit_archive_sha256=sha(zpath),
    head=git('rev-parse','HEAD').strip(),branch=git('branch','--show-current').strip(),
    status=git('status','--porcelain=v1'))
(r/'final_preservation.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print('28 foreign files, 99 preflight files, 7 worktrees, foreign refs, frozen paths and 130 reaudit archive entries preserved/verified')
