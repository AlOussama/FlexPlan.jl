using JuMP,JSON
include("D:/Projekte/Code/FlexPlan_UC_GSCR/scripts/paper_a/AP3Pipeline.jl")
const P=AP3Pipeline
m=read_from_file("D:/Downloads/A3_7_B1_preflight_20261022_203803/original_G3.mof.json")
point=JSON.parsefile("D:/Downloads/A3_7_B1_continuation_20261022/selected_native_matrix/reference_24snap_G3_original_serialized_default/point.json")
for v in all_variables(m);set_start_value(v,point[name(v)]);end
set_optimize_hook(m,model->begin unset_silent(model);optimize!(model;ignore_optimize_hook=true) end)
stats=P.solve!((model=m,),P.native_g3_optimizer())
open(io->JSON.print(io,stats,2),joinpath(@__DIR__,"seeded_exact_probe.json"),"w")
