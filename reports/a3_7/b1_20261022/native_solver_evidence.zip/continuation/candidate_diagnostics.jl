using JuMP, JSON, SHA, Libdl
import Mosek, MosekTools, Gurobi, HiGHS
const MOI=JuMP.MOI
const ROOT=@__DIR__
const PRE="D:/Downloads/A3_7_B1_preflight_20261022_203803"
solver=ARGS[1]
out=joinpath(ROOT,"candidate_"*solver);mkpath(out)
safe(f)=try f() catch; nothing end
function configure(m,solver,mode)
    if solver=="MOSEK"
        set_optimizer(m,MosekTools.Optimizer)
        attrs=Dict("MSK_IPAR_NUM_THREADS"=>1,"MSK_DPAR_OPTIMIZER_MAX_TIME"=>120.,
          "MSK_DPAR_MIO_TOL_REL_GAP"=>1e-8,"MSK_DPAR_MIO_TOL_ABS_GAP"=>1e-10,
          "MSK_DPAR_MIO_TOL_FEAS"=>1e-8,"MSK_DPAR_MIO_TOL_ABS_RELAX_INT"=>1e-8,
          "MSK_DPAR_INTPNT_CO_TOL_PFEAS"=>1e-10,"MSK_DPAR_INTPNT_CO_TOL_DFEAS"=>1e-10,
          "MSK_DPAR_INTPNT_CO_TOL_REL_GAP"=>1e-10)
    else
        set_optimizer(m,Gurobi.Optimizer)
        attrs=Dict("Threads"=>1,"TimeLimit"=>120.,"FeasibilityTol"=>1e-8,
          "IntFeasTol"=>1e-8,"MIPGap"=>1e-8,"Seed"=>20261020)
        mode=="tight_dual" && (attrs["OptimalityTol"]=1e-9)
    end
    for (k,v) in attrs;set_optimizer_attribute(m,k,v);end
    return attrs
end
rows=Any[]
# This integer optimum is exactly 5, with an RSOC constant of 3.
try
    m=Model();attrs=configure(m,solver,"small")
    @variable(m,0<=x<=10,Int);@variable(m,y==1)
    @constraint(m,[x,y,3.] in RotatedSecondOrderCone());@objective(m,Min,x)
    t=@elapsed optimize!(m)
    row=Dict("mode"=>"small_integer_RSOC","termination"=>string(termination_status(m)),
      "primal_status"=>string(primal_status(m)),"dual_status"=>string(dual_status(m)),
      "primal"=>has_values(m) ? [value(x),value(y)] : nothing,"wall_s"=>t,
      "options"=>attrs,"solver_version"=>safe(()->MOI.get(backend(m),MOI.SolverVersion())))
    push!(rows,row)
catch e
    push!(rows,Dict("mode"=>"small_integer_RSOC","error"=>sprint(showerror,e,catch_backtrace())))
end
open(io->JSON.print(io,rows,2),joinpath(out,"results.json"),"w")
for mode in (solver=="MOSEK" ? ["original","amp20"] : ["original","tight_dual","amp20","amp30"])
    println("BEGIN ",solver," ",mode);flush(stdout)
    path=joinpath(PRE,"original_G3.mof.json")
    m=read_from_file(path);f=objective_function(m)
    factor=mode=="amp20" ? 2.0^20 : mode=="amp30" ? 2.0^30 : 1.
    set_objective_function(m,f*factor)
    row=Dict{String,Any}("mode"=>mode,"input_sha256"=>bytes2hex(sha256(read(path))),
       "objective_multiplier"=>factor,"physical_constraints_unchanged"=>true,
       "residual_tolerance"=>1e-7)
    try
        row["options"]=configure(m,solver,mode)
        row["wall_s"]=@elapsed optimize!(m)
        row["termination"]=string(termination_status(m));row["primal_status"]=string(primal_status(m))
        row["dual_status"]=string(dual_status(m))
        row["original_objective_numerical"]=has_values(m) ? value(f) : nothing
        row["bound_original_coordinate_numerical_only"]=safe(()->objective_bound(m)/factor)
        row["relative_gap"]=safe(()->relative_gap(m));row["nodes"]=safe(()->node_count(m))
        row["solver_version"]=safe(()->MOI.get(backend(m),MOI.SolverVersion()))
        if has_values(m)
            open(io->JSON.print(io,Dict(name(v)=>value(v) for v in all_variables(m))),joinpath(out,mode*"_point.json"),"w")
        end
        write_to_file(m,joinpath(out,mode*"_solver_input.mof.json"))
    catch e
        row["error"]=sprint(showerror,e,catch_backtrace())
    end
    push!(rows,row);open(io->JSON.print(io,rows,2),joinpath(out,"results.json"),"w")
    println("END ",mode," ",get(row,"termination","error"));flush(stdout)
end
open(io->JSON.print(io,Dict("Mosek"=>string(Base.pkgversion(Mosek)),"MosekTools"=>string(Base.pkgversion(MosekTools)),
 "loaded"=>[p for p in Libdl.dllist() if occursin(r"(?i)mosek|gurobi",p)]),2),joinpath(out,"runtime.json"),"w")
