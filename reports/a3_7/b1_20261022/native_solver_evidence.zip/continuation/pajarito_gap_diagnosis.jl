using JuMP,JSON
import Pajarito,HiGHS,Clarabel
include("D:/Projekte/Code/FlexPlan_UC_GSCR/scripts/paper_a/AP3Pipeline.jl")
const P=AP3Pipeline;const MOI=JuMP.MOI
const R=joinpath(@__DIR__,"pajarito_gap_diagnosis");mkpath(R)
h=HiGHS.Optimizer()
defaults=Dict(k=>MOI.get(h,MOI.RawOptimizerAttribute(k)) for k in
    ("mip_abs_gap","mip_rel_gap","dual_feasibility_tolerance","mip_feasibility_tolerance","small_matrix_value"))
open(io->JSON.print(io,defaults,2),joinpath(R,"highs_defaults.json"),"w")
rows=Any[]
for mode in ("tight_absolute_gap","tight_absolute_and_dual_gap")
    oa=optimizer_with_attributes(HiGHS.Optimizer,"output_flag"=>false,"threads"=>1,
        "small_matrix_value"=>1e-12,"mip_feasibility_tolerance"=>1e-8,"mip_rel_gap"=>1e-8,
        "mip_abs_gap"=>1e-10)
    if mode=="tight_absolute_and_dual_gap"
        push!(oa.params,MOI.RawOptimizerAttribute("dual_feasibility_tolerance")=>1e-9)
    end
    base=P.pajarito_optimizer()
    opt=optimizer_with_attributes(Pajarito.Optimizer,
        (attr.name=>(attr.name=="oa_solver" ? oa : value) for (attr,value) in base.params)...)
    m=read_from_file("D:/Downloads/A3_7_B1_preflight_20261022_203803/original_G3.mof.json")
    set_optimizer(m,opt)
    row=Dict{String,Any}("mode"=>mode)
    try
        row["wall_s"]=@elapsed optimize!(m)
        row["termination"]=string(termination_status(m));row["primal_status"]=string(primal_status(m))
        row["objective_numerical"]=P.safe(()->objective_value(m));row["bound_numerical"]=P.safe(()->objective_bound(m))
        row["relative_gap"]=P.safe(()->relative_gap(m))
        if has_values(m)
            open(io->JSON.print(io,Dict(name(v)=>value(v) for v in all_variables(m))),joinpath(R,mode*"_point.json"),"w")
        end
    catch e
        row["error"]=sprint(showerror,e,catch_backtrace())
    end
    push!(rows,row);open(io->JSON.print(io,rows,2),joinpath(R,"results.json"),"w")
    println(row);flush(stdout)
end
