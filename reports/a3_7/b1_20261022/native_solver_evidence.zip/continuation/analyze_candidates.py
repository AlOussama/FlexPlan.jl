import pathlib,json,hashlib,collections
from fractions import Fraction as F
r=pathlib.Path(__file__).resolve().parent
pre=pathlib.Path(r'D:\Downloads\A3_7_B1_preflight_20261022_203803')
# Reuse the already inspected separate oracle without executing its output-writing driver.
src=(pre/'verify_original_points.py').read_text()
ns={'__file__':str(pre/'verify_original_points.py')}
exec(src[:src.index('results={}')],ns)
check=ns['check'];model=ns['d']
historical=json.loads((pre/'historical_native_point.json').read_text())
hc=check(historical);assert hc['exact_feasible']
H=F(hc['exact_serialized_objective'])
def affine(f):
    return ({t['variable']:F(t['coefficient']) for t in f['terms']},F(f['constant']))
def ckey(c):
    f=c['function'];s=c['set']
    if f['type']=='ScalarAffineFunction':
        a,b=affine(f);f=('scalar',tuple(sorted((n,str(v)) for n,v in a.items() if v)),str(b))
    elif f['type']=='VectorAffineFunction':
        f=('vector',tuple(sorted((t['output_index'],t['scalar_term']['variable'],str(F(t['scalar_term']['coefficient']))) for t in f['terms'])),tuple(str(F(v)) for v in f['constants']))
    else:f=('variable',f['name'])
    return (f,json.dumps(s,sort_keys=True))
original_rows=collections.Counter(ckey(c) for c in model['constraints'])
orig_a,orig_c=affine(model['objective']['function'])
results=[]
for solver in ['MOSEK','Gurobi']:
    dr=r/('candidate_'+solver)
    for row in json.loads((dr/'results.json').read_text()):
        mode=row['mode']
        if mode=='small_integer_RSOC': continue
        out=dict(solver=solver,mode=mode)
        p=dr/(mode+'_point.json')
        if p.exists():out['original_residuals']=check(json.loads(p.read_text()))
        inp=dr/(mode+'_solver_input.mof.json')
        if inp.exists():
            new=json.loads(inp.read_text());a,c=affine(new['objective']['function']);factor=F(row['objective_multiplier'])
            out['constraint_multiset_identical']=original_rows==collections.Counter(ckey(cc) for cc in new['constraints'])
            out['variable_names_identical']={v['name'] for v in model['variables']}=={v['name'] for v in new['variables']}
            out['objective_scaling_exact_binary_rational']=c==orig_c*factor and a=={n:v*factor for n,v in orig_a.items()}
            assert all(out[k] for k in ['constraint_multiset_identical','variable_names_identical','objective_scaling_exact_binary_rational'])
        b=row.get('bound_original_coordinate_numerical_only')
        if b is not None:
            delta=F(b)-H
            out['bound_minus_exact_original_witness']=str(delta)
            out['bound_minus_exact_original_witness_display']=float(delta)
            out['bound_contradiction']=delta>0
        out['historical_original_witness_objective_display']=float(H)
        results.append(out)
coeffs=[abs(F(t['coefficient'])) for t in model['objective']['function']['terms'] if t['coefficient']]
stats=dict(min_coefficient=float(min(coeffs)),max_coefficient=float(max(coeffs)),
    constant=model['objective']['function']['constant'],coefficient_count=len(coeffs))
final=dict(original_sha256=hashlib.sha256((pre/'original_G3.mof.json').read_bytes()).hexdigest(),
    objective_stats=stats,historical_exact_witness_feasible=True,results=results)
(r/'candidate_analysis.json').write_text(json.dumps(final,indent=2),encoding='utf-8')
print(json.dumps(dict(objective_stats=stats,results=[dict(solver=a['solver'],mode=a['mode'],
 bound_contradiction=a.get('bound_contradiction'),bound_excess=a.get('bound_minus_exact_original_witness_display'),
 numeric_primal_pass=a.get('original_residuals',{}).get('within_declared_tolerance')) for a in results]),indent=2))
