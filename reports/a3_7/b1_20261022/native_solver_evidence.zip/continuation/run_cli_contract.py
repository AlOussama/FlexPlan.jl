import pathlib,json,subprocess,sys,csv
r=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
cli=r/'cli_contract';cli.mkdir(exist_ok=False)
source=repo/'reports/ap3_runs/20261020_macro/accepted_suite/reference_3snap'
config=dict(AP1_SHA='3b8fdb01d931225edc5f8fe1e2c200d0da288a09',
 cases=[dict(id='reference_3snap',case=str(source/'case.json'),registry=str(source/'parameter_registry.csv'),scenarios=str(source/'study_scenarios.toml'))],
 relaxations=[True,False],formulations=['BASE','G0','G1','G2_identity','G2_degree','G3','M1','M2_full','M2_neighbor'],
 condition_on_baseline_LP=True,sizes=[2,4,8,16])
cfg=cli/'config.json';cfg.write_text(json.dumps(config,indent=2),encoding='utf-8')
commands=[('run_formulation_suite',cfg,cli/'suite'),
 ('reconstruct_strength_matrices',cli/'suite',cli/'matrices'),
 ('evaluate_strength_metrics',cli/'matrices',cli/'metrics'),
 ('verify_certificates',cli/'matrices',cli/'certificates'),
 ('compare_formulations',cli/'suite',cli/'comparisons'),
 ('assess_planning_results',cli/'suite',cli/'planning'),
 ('benchmark_conic_scaling',cfg,cli/'benchmark'),
 ('export_paper_a_evidence',cli,r/'cli_export')]
records=[]
for action,inp,out in commands:
    args=['julia','+1.10.11','--startup-file=no','--project=.',str(repo/'scripts/paper_a/ap3.jl'),action,str(inp),str(out)]
    p=subprocess.run([sys.executable,str(r/'execute.py'),'cli_'+action,*args])
    records.append(dict(action=action,exitcode=p.returncode));assert p.returncode==0,action
for name,action,inp,out in [('unknown_action','not_an_action',cfg,cli/'unused'),
 ('missing_input','run_formulation_suite',cli/'missing.json',cli/'unused'),
 ('existing_output','run_formulation_suite',cfg,cli/'suite')]:
    args=['julia','+1.10.11','--startup-file=no','--project=.',str(repo/'scripts/paper_a/ap3.jl'),action,str(inp),str(out)]
    p=subprocess.run([sys.executable,str(r/'execute.py'),'cli_negative_'+name,*args])
    records.append(dict(negative=name,exitcode=p.returncode));assert p.returncode!=0,name
for name,script,args in [('raw_oracle','independent_reference_oracle.py',[cli,repo]),
    ('metric_oracle','independent_metric_audit.py',[cli,repo])]:
    p=subprocess.run([sys.executable,str(r/'execute.py'),'cli_'+name,sys.executable,
        str(repo/'reports/a3_5/executable_closure_20261020'/script),*map(str,args)])
    assert p.returncode==0,name
metric=json.loads((cli/'independent_metric_results.json').read_text())
assert not metric['failures'],metric['failures'][:3]
assert metric['roundtrips'][0]['metric_ids']==124
assert metric['roundtrips'][0]['registry_coverage']
records.append(dict(independent_metric_value_failures=len(metric['failures']),
 metric_ids=124,roundtrips=metric['roundtrips']))
(cli/'contract_result.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
print('8 real CLI actions, 3 expected negative commands, 124 metric IDs verified')
