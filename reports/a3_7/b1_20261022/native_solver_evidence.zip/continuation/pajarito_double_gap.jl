using JuMP,JSON,SHA
import Pajarito,HiGHS
include("D:/Projekte/Code/FlexPlan_UC_GSCR/scripts/paper_a/AP3Pipeline.jl")
const P=AP3Pipeline;const MOI=JuMP.MOI
const R=joinpath(@__DIR__,"pajarito_double_gap");mkpath(R)
rows=Any[]
for mode in ("accepted_factory_default_gap","tight_absolute_gap")
    attrs=Dict{String,Any}("output_flag"=>false,"threads"=>1,"small_matrix_value"=>1e-12,
        "mip_feasibility_tolerance"=>1e-8,"mip_rel_gap"=>1e-8)
    mode=="tight_absolute_gap" && (attrs["mip_abs_gap"]=1e-10)
    oa=optimizer_with_attributes(HiGHS.Optimizer,attrs...);base=P.pajarito_optimizer()
    opt=optimizer_with_attributes(Pajarito.Optimizer,(a.name=>(a.name=="oa_solver" ? oa : v) for (a,v) in base.params)...)
    m=read_from_file(joinpath(@__DIR__,"integrity/prior/objective_snapshots/reference_24snap_cost_conditioned.mof.json"))
    set_objective_function(m,objective_function(m)/2)
    input=joinpath(R,mode*"_input.mof.json");write_to_file(m,input);set_optimizer(m,opt)
    row=Dict{String,Any}("mode"=>mode,"input_sha256"=>bytes2hex(sha256(read(input))),"oa_options"=>attrs)
    row["wall_s"]=@elapsed optimize!(m)
    row["termination"]=string(termination_status(m));row["primal_status"]=string(primal_status(m))
    row["objective_numerical"]=P.safe(()->objective_value(m));row["bound_numerical"]=P.safe(()->objective_bound(m))
    if has_values(m)
        open(io->JSON.print(io,Dict(name(v)=>value(v) for v in all_variables(m))),joinpath(R,mode*"_point.json"),"w")
    end
    push!(rows,row);open(io->JSON.print(io,rows,2),joinpath(R,"results.json"),"w")
    println(row);flush(stdout)
end
