# Technische Entscheidung vor Produktionskorrektur

SPECIFICATION_READY. Parent 15ba10c193a562a48cb0e1dcc6fa12d922ac0613.
Alle 28 fremden audit-Dateien sind SHA256-identisch; die zusätzliche ausdrückliche
Freigabe erlaubt ausschließlich ihre unveränderte Erhaltung. Nur eine neue Branch.

Baseline und Capability sind vor dem Produktionsdiff erhalten. Der akzeptierte
Pajarito/HiGHS-Filterfix bleibt unverändert. Er schließt den nativen Default- und
Doppeldivisorpfad nicht. Gurobi und MOSEK sind jetzt echte MISOCP-Kandidaten.

Auf identischem serialisiertem Originalmodell überschreiten Gurobis Standardbound
und MOSEKs Bound beim winzig normierten Ziel einen frisch exakt geprüften
zulässigen Originalzeugen. Engere Gurobi-Dualtoleranz verkleinert den Widerspruch,
beseitigt ihn jedoch nicht. Das ist kein Offset-/Koordinatenvergleich verschiedener
Modelle: Variablen- und Constraintmultimengen sowie die exakte affine Objective
wurden separat verglichen. Die kleinste Zielkoeffizient beträgt etwa 3.75249e-9.

Eine Multiplikation der vollständigen affinen Objective mit 2^20 erhält alle
Koeffizienten einschließlich Konstante exakt als binäre rationale Zahlen. Die
Variablen und sämtliche Constraints bleiben identisch. Damit beträgt der kleinste
Zielkoeffizient etwa 0.0039347; beide kommerziellen Backends liefern nun einen
numerisch zulässigen Originalpunkt und einen Bound unter dem exakten Zeugen.
Diese endlichen Vergleiche sind kein rigoroser globaler MIP-Boundbeweis.

Vorläufig gewählter zusammenhängender Weg: native MOSEK-G3-Integration mit einer
exakt geprüften Zweierpotenz-Zielnormierung. MOSEK hat eine direkte konische
Integerroute und vermeidet den externen Pajarito/HiGHS-OA-Übergang. Gurobi bleibt
ein aktiv geprüfter Vergleich, ohne automatische Produktionsauswahl aufgrund
eines bloßen kleinen Capability-PASS. G0 bleibt auf dem bisherigen Pfad.

Die Normierung hebt den kleinsten nichtnull Zielkoeffizienten auf mindestens
2^-8 an, ohne einen Koeffizienten zu löschen. Unsichere Über-/Unterläufe,
übermäßige Koeffizientenbereiche und zu kleine originale Constraintkoeffizienten
werden vor einer Qualifikation fail-closed zurückgewiesen. Die endliche
Inputdomäne und Grenzen sind explizit zu testen. Native Bounds werden weiterhin
als numerisch und nicht rigoros gekennzeichnet; keine Währungszertifikate aus
ihnen ableiten. Die bisherige Rebase-/Divisorkoordinate bleibt erhalten und wird
separat erfasst; die zusätzliche Zweierpotenz ist eine exakte Skalierung dieser
bereits emittierten Koordinate.

Für die endgültige Entscheidung müssen Default/Doppeldivisor, alle neun Fälle,
die 45er Matrix, unabhängige Originalresiduen, Objective-/Modellidentitäten,
adversariale Controls und die vollständige Regression bestehen. Andernfalls
bleibt nur eine entsprechend begrenzte Teilantwort. Keine Selbstabnahme.
