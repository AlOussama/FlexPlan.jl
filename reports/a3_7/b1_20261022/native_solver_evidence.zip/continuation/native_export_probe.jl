using JuMP,JSON
include("D:/Projekte/Code/FlexPlan_UC_GSCR/scripts/paper_a/AP3Pipeline.jl")
const P=AP3Pipeline;const MOI=JuMP.MOI
const R=joinpath(@__DIR__,"native_export_probe");mkpath(R)
m=read_from_file(joinpath(@__DIR__,"integrity/prior/model_inclusion/bess_premium_3snap_G3.mof.json"))
stats=P.solve!((model=m,),P.native_g3_optimizer())
open(io->JSON.print(io,stats,2),joinpath(R,"stats.json"),"w")
native=unsafe_backend(m)
fm=MOI.FileFormats.Model(;format=MOI.FileFormats.FORMAT_MOF)
mapping=MOI.copy_to(fm,native)
MOI.write_to_file(fm,joinpath(R,"backend.mof.json"))
doc=JSON.parsefile(joinpath(R,"backend.mof.json"))
names=Dict(v.value=>doc["variables"][mapping[v].value]["name"] for v in MOI.get(native,MOI.ListOfVariableIndices()))
open(io->JSON.print(io,Dict(names[v.value]=>MOI.get(native,MOI.VariablePrimal(),v) for v in MOI.get(native,MOI.ListOfVariableIndices())),2),joinpath(R,"backend_point.json"),"w")
open(io->print_active_bridges(io,m),joinpath(R,"bridges.txt"),"w")
for v in all_variables(m);@assert haskey(names,optimizer_index(v).value);end
println("ACTUAL NATIVE BACKEND EXPORTED ",stats["termination"])
