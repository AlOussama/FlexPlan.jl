import ast,collections,itertools,json,pathlib,hashlib,subprocess
from fractions import Fraction as Q
import numpy as np
R=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
PRE=pathlib.Path(r'D:\Downloads\A3_7_B1_preflight_20261022_203803')
load=lambda p:json.loads(p.read_text())
src=REPO/'scripts/paper_a/verify_native_g3.py'
ns=dict(Q=Q,np=np,collections=collections,itertools=itertools,json=json,TOL=Q(1,10_000_000))
defs=[n for n in ast.parse(src.read_text()).body if isinstance(n,ast.FunctionDef)]
exec(compile(ast.Module(body=defs,type_ignores=[]),str(src),'exec'),ns)
model=load(PRE/'original_G3.mof.json');w=load(PRE/'historical_native_point.json')
wc=ns['check_point'](model,w);assert wc['exact_pass'];H=Q(wc['objective_exact'])
diagnostics=[]
for name in ['pajarito_gap_diagnosis','pajarito_double_gap']:
    for row in load(R/name/'results.json'):
        inp=R/name/(row['mode']+'_input.mof.json')
        m=load(inp) if inp.exists() else model
        mapping=ns['projection'](model,m)
        witness={n:Q(v) for n,v in w.items()}
        for z,(x,offset) in mapping.items():witness[z]=witness[x]+offset
        check=ns['check_point'](m,witness);assert check['exact_pass']
        bound=Q(row['bound_numerical']);excess=bound-Q(check['objective_exact'])
        out=dict(group=name,**row,exact_witness_feasible=True,
                 exact_witness_objective=str(check['objective_exact']),
                 numerical_bound_minus_exact_feasible_witness=str(excess),
                 numerical_bound_excess_display=float(excess),bound_contradiction=excess>0)
        point=R/name/(row['mode']+'_point.json')
        if point.exists():out['independent_primal_check']=ns['check_point'](m,load(point))
        diagnostics.append(out)
(R/'pajarito_diagnosis_verified.json').write_text(json.dumps(diagnostics,indent=2))
matrix=load(R/'final_exact_route_matrix/results.json')
proof=load(R/'final_exact_route_matrix/independent_verification.json')
checks=proof['results'];assert len(matrix)==len(checks)==46
assert all(row['stats']['termination']=='OPTIMAL' for row in matrix)
assert all(row['original_primal']['numerical_pass'] for row in checks)
assert all(row.get('actual_backend_primal',{}).get('numerical_pass',True) for row in checks)
assert not any(row.get('native_bound_contradiction') for row in checks)
assert all(row.get('heuristic_seed_original_primal',{}).get('numerical_pass',True) for row in checks)
res=collections.defaultdict(float);backres=collections.defaultdict(float)
for row in checks:
    for key,item in row['original_primal']['residuals'].items():res[key]=max(res[key],item['display'])
    for key,item in row.get('actual_backend_primal',{}).get('residuals',{}).items():backres[key]=max(backres[key],item['display'])
summaries={}
for dr in ['native_matrix_repair','final_native_matrix','selected_native_matrix','final_exact_route_matrix']:
    rows=load(R/dr/'results.json')
    summaries[dr]=dict(count=len(rows),terminations=dict(collections.Counter(x.get('stats',{}).get('termination',x.get('error','ERROR')) for x in rows)),
        nonoptimal=[dict(case_id=x.get('case_id'),mode=x.get('mode'),termination=x.get('stats',{}).get('termination')) for x in rows if x.get('stats',{}).get('termination')!='OPTIMAL'])
original=next(row for row in matrix if row['mode']=='original_serialized_default')
double=next(row for row in matrix if row['case_id']=='reference_24snap' and row['formulation']=='G3' and row['mode']=='double_costscale')
def compact(row):
    stats=row['stats'];keep=['termination','primal_status','dual_status','objective','bound','bound_backend_numerical','objective_backend','solve_wall_s','relative_gap','nodes','barrier_iterations','simplex_iterations','objective_solver_scaling','objective_requested_divisor','objective_conditioning','native_input_range','native_options','bound_certification']
    out={k:stats[k] for k in keep if k in stats}
    out.update(case_id=row['case_id'],mode=row['mode'],original_model_sha256=row.get('original_model_sha256',hashlib.sha256((PRE/'original_G3.mof.json').read_bytes()).hexdigest()))
    out['seed_wall_s']=stats.get('primal_start_strategy',{}).get('heuristic_wall_s')
    return out
report=dict(matrix_summaries=summaries,original_residual_maxima=dict(res),actual_backend_residual_maxima=dict(backres),
            actual_backend_identity_count=sum('actual_backend_identity' in row for row in checks),
            exact_backend_cones=sum(row.get('actual_backend_identity',{}).get('exact_quadratic_cones',0) for row in checks),
            original_default=compact(original),reference24_double=compact(double),
            original_witness_objective_exact=str(H),original_witness_objective_display=float(H),
            operations=[load(p) for p in sorted((R/'operations').glob('*/command.json'))])
(R/'final_summary.json').write_text(json.dumps(report,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='operations'},indent=2))
print('OPERATIONS',len(report['operations']),'failed:',[(x['name'],x['exitcode']) for x in report['operations'] if x['exitcode']])
