# Paper A AP3 — Evidenzexport

Schema: paper_a_ap3/1.0. Indizierte Dateien: 39; Rohbytes: 20951849. Der Index prüft die gespeicherten Bytes; er ist keine unabhängige wissenschaftliche Abnahme.

Empirische Freigabe=false; A3_closed=false; AP4_ready=false. Native Solverstatus und separate Referenzintervalle bleiben getrennt.

| Artefakt | Relativer Pfad |
|---|---|

Große metrics.json/metrics.csv vor vollständiger Prüfung aus den benachbarten ZIPs extrahieren. Archivinhalt und Rohdatei sind separat SHA256-geprüft. Die neu erzeugten Exportdateien selbst werden nicht selbstreferenziell indiziert.
