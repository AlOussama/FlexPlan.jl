using JuMP,JSON
include("D:/Projekte/Code/FlexPlan_UC_GSCR/scripts/paper_a/AP3Pipeline.jl")
const P=AP3Pipeline;const MOI=JuMP.MOI
const R=joinpath(@__DIR__,"exact_bridge_probe");mkpath(R)
for mode in ("small","original24")
    if mode=="small"
        m=Model();@variable(m,x>=0,Int);@variable(m,y>=0)
        @constraint(m,[x,y,3.] in RotatedSecondOrderCone());@objective(m,Min,1e-9*x+1e-9*y)
    else
        m=read_from_file("D:/Downloads/A3_7_B1_preflight_20261022_203803/original_G3.mof.json")
    end
    set_optimize_hook(m,model->begin unset_silent(model);optimize!(model;ignore_optimize_hook=true) end)
    try
        stats=P.solve!((model=m,),P.native_g3_optimizer())
        open(io->JSON.print(io,stats,2),joinpath(R,mode*".json"),"w")
    catch e
        println(sprint(showerror,e,catch_backtrace()))
    end
    open(io->print_active_bridges(io,m),joinpath(R,mode*"_bridges.txt"),"w")
    MOI.write_to_file(unsafe_backend(m),joinpath(R,mode*".lp"))
end
