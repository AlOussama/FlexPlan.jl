import pathlib,subprocess,sys,json,datetime,os,hashlib
r=pathlib.Path(__file__).resolve().parent
name=sys.argv[1]; args=sys.argv[2:]
d=r/'operations'/name;d.mkdir(parents=True,exist_ok=False)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
repo=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo).decode().strip()
files=subprocess.check_output(['git','ls-files','src','scripts','test','Project.toml','Manifest-v1.10.toml'],cwd=repo).decode().splitlines()
source_hashes={n:hashlib.sha256((repo/n).read_bytes()).hexdigest() for n in files if (repo/n).is_file()}
(d/'source_sha256.json').write_text(json.dumps(source_hashes,indent=2),encoding='utf-8')
env=os.environ.copy();env['JULIA_NUM_THREADS']='1';env['JULIA_PKG_PRECOMPILE_AUTO']='0'
with (d/'stdout.log').open('wb') as out,(d/'stderr.log').open('wb') as err:
    p=subprocess.run(args,cwd=r'D:\Projekte\Code\FlexPlan_UC_GSCR',env=env,stdout=out,stderr=err)
rec=dict(name=name,args=args,cwd=r'D:\Projekte\Code\FlexPlan_UC_GSCR',head=head,start_utc=start,
    end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitcode=p.returncode)
(d/'command.json').write_text(json.dumps(rec,indent=2),encoding='utf-8')
print(name,'exit',p.returncode,flush=True)
if p.returncode: print((d/'stderr.log').read_text(errors='replace')[-3000:],flush=True)
sys.exit(p.returncode)
