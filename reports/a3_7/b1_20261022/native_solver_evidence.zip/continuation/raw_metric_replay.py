"""Reuse only the existing NumPy raw-input reconstruction functions.
The historical full SymPy boundary driver is a separate, unavailable dependency path.
"""
import ast,pathlib,json,hashlib,sys
import numpy as np
R=pathlib.Path(sys.argv[1]);BASE=pathlib.Path(sys.argv[2])
source=BASE/'reports/a3_5/executable_closure_20261020/independent_reference_oracle.py'
text=source.read_text();tree=ast.parse(text)
names={'dump','hashfile','rebuild','economics','audit_suite'}
functions=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
assert {node.name for node in functions}==names
ns=dict(R=R,BASE=BASE,json=json,hashlib=hashlib,np=np,economics_rows=[])
exec(compile(ast.Module(body=functions,type_ignores=[]),str(source),'exec'),ns)
rows=ns['audit_suite'](BASE/'reports/ap3_runs/20261020_macro/accepted_suite','historical')+ns['audit_suite'](R/'suite','fresh')
ns['dump']('independent_matrices_B_p_S_M_Zp_G3.json',rows)
ns['dump']('independent_objective_audit.json',ns['economics_rows'])
ns['dump']('raw_reconstruction_summary.json',dict(states=len(rows),solutions=len(ns['economics_rows']),
 source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),unchanged_functions=sorted(names),
 scope='existing NumPy raw reconstruction only; full SymPy boundary driver not executed'))
print('raw reconstruction states',len(rows),'solutions',len(ns['economics_rows']))
