import collections,csv,datetime,hashlib,io,json,pathlib,re,subprocess,tomllib,zipfile
R=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
PRE=pathlib.Path(r'D:\Downloads\A3_7_B1_preflight_20261022_203803')
OUT=REPO/'reports/a3_7/b1_20261022'
OUT.mkdir(parents=True,exist_ok=False)
BASE='15ba10c193a562a48cb0e1dcc6fa12d922ac0613'
PROD='f302b7b63e917678fb14b7cbc3cfdbc0d8c624a1'
ORACLE='6b6bcd8b0f00caa3a7ee7d7e89fe1085596bd7fc'
load=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()
def dump(name,obj):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def text(name,s):(OUT/name).write_text(s.strip()+'\n',encoding='utf-8')
S=load(R/'final_summary.json');V=load(R/'final_exact_route_matrix/independent_verification.json')
M=load(R/'final_exact_route_matrix/results.json');checks={x['directory']:x for x in V['results']}
assert git('rev-parse','HEAD')==ORACLE
assert git('branch','--show-current')=='fix/paper-a-a3-7-b1-native-solver-v1'
assert not git('diff',PROD,ORACLE,'--','scripts/paper_a/AP3Pipeline.jl','scripts/paper_a/NativeG3Solver.jl','scripts/paper_a/qualify_native_g3.jl','test','src','Project.toml','Manifest-v1.10.toml')
before=tomllib.loads(git('show',BASE+':Manifest-v1.10.toml'))['deps']
after=tomllib.loads((REPO/'Manifest-v1.10.toml').read_text())['deps']
assert all(after[k]==v for k,v in before.items())
dep=dict(existing_entries_unchanged=len(before),added={k:v for k,v in after.items() if k not in before})
assert set(dep['added'])=={'Mosek','MosekTools'}
dump('dependency_preservation.json',dep)
dump('solver_summary.json',{k:v for k,v in S.items() if k!='operations'})
dump('solver_comparison.json',dict(final_matrix=M,verification=V,
    candidates={n:load(R/('candidate_'+n)/'results.json') for n in ['Gurobi','MOSEK']},
    candidate_original_model_checks=load(R/'candidate_analysis.json'),
    pajarito_diagnosis=load(R/'pajarito_diagnosis_verified.json'),
    intermediate_matrices=S['matrix_summaries'],
    capability_classification={'Gurobi':'available_and_verified_in_declared_G3_domain',
        'MOSEK':'supported_only_in_restricted_scope; actual_integer_RSOC_and_original_G3_solved; stress_TIME_LIMIT',
        'HiGHS_Pajarito_Clarabel':'supported_only_in_restricted_scope; original_default_and_double_iteration_limit_reproduced'},
    native_MISDP_inferred=False,independent_acceptance=False))
with (OUT/'solver_matrix.csv').open('w',encoding='utf-8',newline='') as f:
    cols=['run_id','case_id','formulation','mode','solver','termination','primal_status','dual_status','objective_original','bound_nominal_numerical','objective_backend','bound_backend_numerical','raw_solver_relative_gap','final_solve_wall_s','heuristic_wall_s','preparation_wall_s','nodes','simplex_iterations','barrier_iterations','original_residual_max','integer_residual','RSOC_polynomial_residual','original_numeric_pass','backend_identity_exact','backend_numeric_pass','bound_contradiction','original_sha256','solver_input_sha256','actual_backend_sha256','point_sha256','bound_certification']
    writer=csv.DictWriter(f,fieldnames=cols);writer.writeheader()
    for row in M:
        a=row['stats'];v=checks[row['directory']];rr=v['original_primal']['residuals']
        original_hash=row.get('original_model_sha256',sha((PRE/'original_G3.mof.json').read_bytes()))
        writer.writerow(dict(run_id='final_exact_route_matrix/'+row['directory'],case_id=row['case_id'],formulation=row['formulation'],mode=row['mode'],solver=a['solver'],termination=a['termination'],primal_status=a['primal_status'],dual_status=a['dual_status'],objective_original=a.get('objective'),bound_nominal_numerical=a.get('bound'),objective_backend=a.get('objective_backend'),bound_backend_numerical=a.get('bound_backend_numerical'),raw_solver_relative_gap=a.get('raw_solver_relative_gap'),final_solve_wall_s=a['solve_wall_s'],heuristic_wall_s=a.get('primal_start_strategy',{}).get('heuristic_wall_s'),preparation_wall_s=a.get('native_preparation_wall_s'),nodes=a.get('nodes'),simplex_iterations=a.get('simplex_iterations'),barrier_iterations=a.get('barrier_iterations'),original_residual_max=max(x['display'] for x in rr.values()),integer_residual=rr.get('Integer',{}).get('display'),RSOC_polynomial_residual=rr.get('RotatedSecondOrderCone',{}).get('display'),original_numeric_pass=v['original_primal']['numerical_pass'],backend_identity_exact=v.get('actual_backend_identity',{}).get('exact_linear_integer_objective_and_RSOC_projection_verified'),backend_numeric_pass=v.get('actual_backend_primal',{}).get('numerical_pass'),bound_contradiction=v.get('native_bound_contradiction'),original_sha256=original_hash,solver_input_sha256=row.get('solver_input_sha256'),actual_backend_sha256=row.get('actual_backend_mof_sha256'),point_sha256=row.get('point_sha256'),bound_certification=a.get('bound_certification','historical_Pajarito_numerical_bound_not_newly_certified')))
dump('operations.json',S['operations'])
dump('preservation_before_publication.json',load(R/'final_preservation.json'))
dump('foreign_files_before_sha256.json',load(R/'authority_preflight.json')['foreign_sha256'])
dump('production_source_sha256.json',{n:sha((REPO/n).read_bytes()) for n in git('ls-files','src','scripts','test','Project.toml','Manifest-v1.10.toml').splitlines()})
(OUT/'production_diff.patch').write_text(git('diff',BASE,ORACLE,'--','Project.toml','Manifest-v1.10.toml','scripts','test')+'\n',encoding='utf-8')
dump('provenance.json',dict(created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),branch=git('branch','--show-current'),base=BASE,production=PROD,verification=ORACLE,original_AP3='485b637cc1998a327206c5929434bd26c6f0be16',accepted_A36_fix='910d44122a37d9ed2cca06940740b46706c73d40',A36_evidence='1147873bf553667aec5cd7eb0e9c6f7e471b370c',history=git('log','--format=%H %P %s',BASE+'..HEAD').splitlines(),authority_macro_sha256=sha((PRE/'M2_A3_7_B1_Autonomer_Codex_Makroauftrag_2026-10-22_v2_Gurobi_MOSEK.md').read_bytes()),publication_remote_verification='see additive publication_receipt.json and final remote HEAD; no self-referential SHA'))
text('release_gates.yaml','''
m2_implementation_verdict: correction_ready_for_independent_reaudit
specification_status: SPECIFICATION_READY
science_amendment_approved: false
owner_ratification: pending
production_correction_A3_6_scoped_accepted: true
m2_new_correction_independent_reaudit: pending
B1_repaired: false
native_G3_MISOCP: numerical_inconclusive
m2_technical_candidate_for_reaudit: true
integer_bounds_proved: true
integer_bounds_scope: nine_inherited_normalized_binary_rational_intervals_only
integer_optimality_proved: false
integer_globality: case_specific_partial
independent_A3_5_accepted: false
A3_closed: false
AP4_ready: false
empirical_study_ready: false
''')
text('implementierungsbericht.md',f'''
# A3.7-B1 — Implementierungsbericht und Übergabe

Stand: 23.10.2026 (Messungen 22.10.2026 UTC / 22.–23.10.2026 MESZ). Rolle: A3.7-B1-IMPLEMENTER.

**Gesamturteil: `correction_ready_for_independent_reaudit`.** Die endliche registrierte Matrix erreicht 45/45 `OPTIMAL`; zusätzlich erreicht das unveränderte serialisierte Originalmodell `reference_24snap` `OPTIMAL/FEASIBLE_POINT`. Alle 46 Originalpunkte bestehen die separate numerische Prüfung. Das ist eine Implementiererqualifikation, keine unabhängige Abnahme und kein globaler Integeroptimalitätsbeweis.

## Auftrag, Specification Gate und Provenienz

`SPECIFICATION_READY`: Der explizite M2-v2-Auftrag legt G3, Integerdomänen, Originalkosten, neun Fälle, Matrix, Residuen, Zertifikate und Abnahmegrenzen fest. Die Fortsetzungsfreigabe erlaubt ausschließlich das unveränderte Liegenlassen der 28 fremden Dateien; die spätere Ergänzung erlaubt zielführende Solveroptionen/Toleranzen. Es wurden keine Feasibility-Anforderungen gelockert. Die Auswahl und Konditionierung betreffen die technische Solverschnittstelle, keine neue wissenschaftliche Methode. Der frühere Schutzstopp `blocked_environment_or_inputs` bleibt historisch richtig und vollständig erhalten.

Vorhandener Checkout: `D:/Projekte/Code/FlexPlan_UC_GSCR`; einziger neuer Branch: `fix/paper-a-a3-7-b1-native-solver-v1`, Parent `{BASE}`. Kein neuer Worktree, Merge, PR, Rebase, Reset, Stash, Cherry-Pick oder Branchlöschen. Die sieben vorhandenen Worktrees bleiben registriert; die übrigen sechs sowie alle fremden Refs wurden unverändert verglichen.

Die Solverproduktion ist auf **`{PROD}`** eingefroren. **`{ORACLE}`** repariert ausschließlich den separaten Nachweis für die vorhandene MOI-Intervall-SlackBridge; Solver-, Modell-, Test- und Dependencydateien bleiben gegenüber der Produktionsrevision identisch. Frühere eigene Implementierungsschritte bleiben in der Commitkette erhalten; `provenance.json` nennt sämtliche Parents. Die abschließende Remote-Verifikation erfolgt additiv im Publikationsbeleg.

Original-AP3 `485b637cc1998a327206c5929434bd26c6f0be16`, akzeptierter A3.6-HiGHS-Fix `910d44122a37d9ed2cca06940740b46706c73d40`, A3.6-Evidenz `1147873bf553667aec5cd7eb0e9c6f7e471b370c`, unabhängiger Reaudit `{BASE}` bleiben unverändert. Die eingefrorenen wissenschaftlichen Commits/Blobs wurden read-only über den bestehenden Reauditpfad verifiziert; daraus folgt keine Ratifizierung des vorgeschlagenen Amendments.

## Gewählte Solverstrategie

Gewählt wurde **Gurobi 12.0.3**, Gurobi.jl 1.9.2, mit der vorhandenen exakten MOI-RSOC-QuadraticBridge, bewiesenen redundanten Nichtnegativitätsbounds, exakter Zweierpotenz-Konditionierung der gesamten emittierten affinen Zielfunktion und einem kontrollierten primalen Start.

Die temporäre Gurobi-Standardbridge erzeugt ausschließlich einen Startpunkt. Ihre gerundete Rotation wird ausdrücklich nicht als exakt modellgleich akzeptiert; ihre Bounds werden weder gelesen noch weitergereicht. Der Kandidat muss das Originalmodell numerisch bestehen. Anschließend löst ein eigenständiger finaler Optimierer das exakt abgebildete ursprüngliche RSOC-Modell; es werden keine Integerwerte fixiert und keine zusätzlichen fachlichen Restriktionen eingeführt.

Konfiguration: ein Thread, `Seed=20261020`, finale Zeitgrenze 120 s zuzüglich höchstens 30 s für die Kandidatenerzeugung und gesondert erfasster Vorbereitung, `NonConvex=0`, `MIPGap=1e-8`, `FeasibilityTol=1e-8` (engerer Matrixmodus `5e-9`), `IntFeasTol=1e-8`, `OptimalityTol=1e-9`. Die unabhängige Originalprüfung benutzt die zuvor festgelegte Schranke `1e-7`; die tatsächlichen Residuen werden ungerundet und als rationale Werte gespeichert. Das ändert keine Modellgleichung.

Die Julia-Anbindung von **MOSEK 11.0.29** wurde tatsächlich hergestellt: Mosek.jl 11.0.1 und MosekTools 0.15.10 sind die einzigen hinzugefügten Manifest-Einträge; alle {len(before)} bestehenden Dependency-Einträge bleiben identisch. Es gab kein `Pkg.update`, keine Lizenzänderung oder Lizenzumgehung. Beide kommerziellen Solver bestehen dasselbe echte Integer-RSOC-Modell (Optimum 5), beide lösen das identische ursprüngliche G3-Modell. Lizenznutzbarkeit ist durch die ausgeführten Solves belegt, nicht durch Dateiexistenz. Die tatsächlich geladene Gurobi-Bibliothek ist 12.0.3; eine im Manifest vorhandene JLL-Version ersetzt diesen Laufzeitnachweis nicht.

MOSEK erhielt vorrangig zwei vollständige normalisierte 46-Läufe-Versuche: 44 `OPTIMAL`/2 `TIME_LIMIT`, danach 43 `OPTIMAL`/3 `TIME_LIMIT`. Betroffen ist `reference_24snap`, insbesondere Doppeldivisor und engere Feasibility, im zweiten Versuch auch Halbdivisor. Die jeweilige Grenze beträgt 120 s; diese Befunde behaupten keine fundamentale Unlösbarkeit durch MOSEK. Sie begründen, warum MOSEK in der hier geprüften Konfiguration nicht die gewählte Route ist. Alle erfolglosen Zwischenversuche bleiben erhalten.

Ein Gurobi-Zwischenstand mit Standardrotation löste 46/46, genügte aber der exakten binär-rationalen Backendidentität nicht. Die direkte exakte Quadratik ohne geeigneten Start scheiterte am 120-s-Limit. Erst die gemeinsame kontrollierte Strategie erfüllt sowohl die Identitäts- als auch die Abschlussprüfung. `REUSE_REJECTED`: MOI-Standardrotation als finaler Modellnachweis — gerundetes `1/sqrt(2)` verändert die binär-rationale Kegelabbildung. Wiederverwendet wurden die vorhandene MOI-QuadraticBridge und sämtliche fachlichen Modellbauer.

## Kausalbefund des bisherigen Pajarito-Stillstands

Der unabhängig akzeptierte HiGHS-Koeffizientenfix `small_matrix_value=1e-12` bleibt unverändert. Er beseitigt die konkrete lokale Filterursache, aber nicht den folgenden Abbruchkonflikt: Die innere HiGHS-MIP-Standardschranke `mip_abs_gap=1e-6` ist größer als Pajaritos äußere absolute Schranke `1e-8`. Ein verbleibender innerer Gap von ungefähr `6.84e-7` darf daher bereits den inneren Solver beenden, während die äußere OA noch weiterlaufen muss. Die beobachtete Wiederholung führt zum 100-Iterationen-Limit.

Die Ein-Faktor-Kontrolle am identischen Doppeldivisor-Input (SHA256 `2f16ef548a55bf63e83f8400b9627875cf58f55e64c317357255a0d37f3549db`) bestätigt den Mechanismus: Standardschranke `ITERATION_LIMIT/NO_SOLUTION` nach 61.18 s, ausschließlich `mip_abs_gap=1e-10` geändert: `OPTIMAL/FEASIBLE_POINT` nach 1.82 s. Im Original-Defaultmodell führen die engere absolute Schranke und zusätzlich `dual_feasibility_tolerance=1e-9` ebenfalls zu `OPTIMAL`.

Diese bloße Optionskorrektur wird trotzdem nicht als robuste Gesamtlösung übernommen: Ihre Default-Originalbounds liegen um `2.4434980469e-10` beziehungsweise `2.1623738952e-10` oberhalb eines exakt zulässigen Zeugen in genau derselben Originalkoordinate. `pajarito_diagnosis_verified.json` enthält die vollständigen rationalen Vergleiche und Originalresiduen. Der negative historische Befund wird weder entfernt noch umgedeutet.

## Gurobi-Boundwiderspruch und Objective-Koordinaten

Das unveränderte serialisierte Original hat SHA256 **`fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07`**, 3.680 Variablen, 1.353 Integer und 144 RSOCs. Constraint-Multimengen, Variablennamen, Objective-Koeffizienten und Konstante wurden separat exakt verglichen. Der historische Zeuge ist erneut rational exakt zulässig; sein Originalziel beträgt `0.01869304116753802` (exakter Bruch im maschinenlesbaren Ergebnis).

Ohne Konditionierung meldet Gurobi `OPTIMAL` mit Bound `0.018702546414934892`: Überschuss `9.505247396874162e-6`. Engere Dualtoleranz reduziert, beseitigt den Konflikt aber nicht (ungefähr `9.4731e-9`). MOSEK meldet auf demselben unskalierten Original ebenfalls einen zu hohen numerischen Bound (ungefähr `1.0810e-8`). Eine fehlende Modellgleichung oder ein vergessener Offset ist somit durch die vollständigen Koeffizientenprüfungen ausgeschlossen; die Befunde sind mit numerischer Objective-Empfindlichkeit vereinbar und keine bewiesene Aussage über interne Herstellercuts.

Die originale kleinste Objective-Koeffizientengröße ist `3.7524903900502144e-9`, die größte 1; die Konstante ist `2.178606398164727e-15`. Multiplikation **aller** affinen Terme einschließlich der Konstante mit `2^20` ist im Original exakt binär-rational und beseitigt die beobachteten Widersprüche. Jeder endgültige Lauf prüft seine tatsächliche Float64-Multiplikation nochmals exakt. Die bestehenden Rebase-/Divisionsrundungen werden davon getrennt als affines `delta(x)` rekonstruiert. Es existiert kein vorgetäuschter globaler Rundungsbound.

Der finale Original-Defaultlauf liefert Originalziel `{S['original_default']['objective']}`, nominalen numerischen Bound `{S['original_default']['bound']}`, Backendziel `{S['original_default']['objective_backend']}` und Backendbound `{S['original_default']['bound_backend_numerical']}`; finaler Solve `{S['original_default']['solve_wall_s']}` s, Startgenerierung `{S['original_default']['seed_wall_s']}` s. Beim `reference_24snap/G3/double_costscale` beträgt der finale Solve `{S['reference24_double']['solve_wall_s']}` s plus `{S['reference24_double']['seed_wall_s']}` s Kandidatenerzeugung; Originalziel `{S['reference24_double']['objective']}`. Das literal serialisierte Defaultmodell hat eine andere ursprüngliche Kostenkoordinate als der normalisierte registrierte Studienfall; ihre Zahlen werden nicht vermischt.

In allen 37 finalen G3-Läufen liegt der numerische Backendbound unter dem exakt ausgerechneten Backendziel eines exakt zulässigen historischen Zeugen. Das beseitigt diese Gegenbeispiele, zertifiziert aber keinen global gültigen Solverbound. `compare_formulations` lässt deshalb `effective_global_lower_bound` und die globale Währungsgap-Abnahme für diese nativen Bounds offen und führt `numerical_inconclusive`. Rohtermination `OPTIMAL` und akzeptierte globale Aussage sind getrennte Felder.

## Modell- und Feasible-Set-Erhaltung

`transformationsnachweis.md` führt den algebraischen Nachweis und die adversarialen Prüfungen aus. Die 27 frisch gebauten BASE/G0/G3-Modelle und 18 tatsächlich emittierten früheren Objective-Snapshots sind bytegleich zu den gepinnten A3.6-Inputs. Originale B-, p-, S-, M-Objekte, Kanten, Kosten, Integerdomänen, Investment-/Dispatch-/Event-/Storagemodell bleiben erhalten. `src/`, `data/`, A3.5/A3.6-Reports und historische AP3-Ergebnisse haben keinen Git-Diff zum Parent.

Die vorhandenen Increment-Variablen und die MOI-Slackvariablen sind eindeutig rückabbildbare Graphenerweiterungen. Für die finale Route wurden 37 tatsächliche Backendmodelle einschließlich linearer Zeilen, Integerdomänen, Objective, Intervallslacks und **1.368** RSOC-Quadratiken separat mit `Fraction` verifiziert. Der Nachweis erfolgt am per nativer MOI-API exportierten Solverinhalt, zusätzlich zu den LP-Texten. Ein bloßes erneutes Schreiben des JuMP-Caches wäre dafür unzureichend.

Alle 46 Originalpunkte bestehen die unabhängige Prüfung mit `1e-7`: maximale Gleichungsabweichung `1.0913033449133636e-8`, maximale Integerabweichung `5.266898028821743e-13`, größte positive polynomiale Original-RSOC-Verletzung **0**. Die Maxima aller Klassen und alle rationalen Einzelwerte stehen in `solver_comparison.json`. Die 37 tatsächlichen Backendpunkte und ihre Startpunkte bestehen ebenfalls. Die neuen Solverpunkte werden ausdrücklich nicht als rational exakt zulässig deklariert. Die historischen exakten Zeugen bleiben dagegen exakt zulässig.

## Tatsächlich ausgeführte Validierung

| Prüfung auf finaler Solverproduktion | Frisches Ergebnis |
|---|---:|
| Registrierte Matrix (36 G3 + 9 G0) | 45/45 OPTIMAL |
| Literal ursprüngliches G3-Defaultmodell zusätzlich | 1/1 OPTIMAL |
| Separate Originalpunktprüfung | 46/46 numerisch zulässig |
| Tatsächliche Gurobi-Backendidentitäten / -punkte | 37/37 |
| Neue gezielte Solver-/Guardtests | 34/34 |
| Volle Repositorytests | 6087/6087 |
| Gespeicherte AP3-Evidenztests | 4108/4108 |
| MOI-/JuMP-Schutzsuite | 42/42 |
| Raw-Domänenmutationen | 16/16 |
| Bestehende exakte Zertifikatssuite | 171/171 |
| Separater A3.6-Reviewerpfad | neun Fälle; 18 Primale, 18 LP-Zertifikate, 18 Objective-Koordinaten |
| HiGHS-Filterregressionen | 14/14 |
| Tatsächliche Backend-Manipulationen | 4/4 verworfen |
| Frische Modell-/Objective-Exporte | 27 + 18 bytegleich |
| Originalquellen/Runtime-Dateien, Git-Blobs | 131 / 56 verifiziert |
| CLI-Vertrag | acht echte Aktionen erfolgreich, drei negative Aktionen erwartungsgemäß Exit 1 |
| Metrikvertrag / CSV-Roundtrip | 124 IDs, 4396 Zeilen, null Wertfehler |

Die 34 Zusatztests wurden vor dem Freeze ausgeführt; ihre getesteten Solver-/Testdateien sind im finalen Commit byteidentisch. Die vollen Regressionen, Zertifikate, Matrix und CLI wurden auf der finalen Produktion erneut ausgeführt; `operations.json` und die Source-SHA-Manifeste trennen jeden Lauf von historischen oder verworfenen Zwischenständen. Keine alten PASS-Zahlen werden als neue Tests gezählt.

Der monolithische historische Sympy-Oracle konnte wegen fehlendem `sympy` nicht vollständig ausgeführt werden. Der Fehler bleibt archiviert. Für die 124 Metriken wurden exakt die unveränderten NumPy-Rohdatenfunktionen des gepinnten Oracles separat ausgeführt; der unabhängige Werte- und CSV-Prüfer prüfte anschließend alle 124 IDs. Diese gezielte Ausführung ist kein behaupteter PASS des vollständigen Sympy-Boundary-Treibers. Die erforderlichen exakten Grenz-/Zeugenzertifikate wurden über die 171er-Suite und den separaten Reviewerpfad frisch geprüft.

## Erhaltung, Rohdaten und Veröffentlichung

Die 28 fremden unversionierten `audit/`-Dateien wurden vor Branchwechsel vollständig SHA256-inventarisiert, auf Nichtkollision mit sämtlichen vorgesehenen Schreib-/Gitpfaden geprüft und nach den Läufen erneut verglichen. Keine wurde verschoben, verändert, gelöscht oder gestagt. `foreign_files_before_sha256.json`, Vorher-/Nachherbeleg und Publikationsbeleg machen das prüfbar. Alle 99 früheren Preflight-Dateien bleiben bytegleich; deren Manifest-SHA lautet `6855a46e43a6d170d858f55a858ea1a0846d6a4ac6112916503f3e31707c51c3`.

A3.6-Witness-ZIP: SHA256 `ca15ee8a3cd73eefe9c75b00896ec4f4cdb71f12e23d6fc55a0916e35417482c`, 406/406 Einträge geprüft. A3.5-EXEC-ZIP: `0ec9969de7c8659bc50d82664556c09515080beb1bcd1e937bb9cc7b8d925993`, 381/381 Einträge. Reaudit-ZIP: `9a22d037f61c1dbc6f60a2e91a27bb04aa273d110b7567241c4527cc27efa41f`, 130/130 Einträge. Zusätzlich wurden 520 Originalinputdateien, acht Wissenschaftsblobs, 55 publizierte Dateihashes, 14 historische ZIP-CRCs und 1060 Indexeinträge geprüft. Die neuen Resultate ersetzen diese Archive nicht.

`native_solver_evidence.zip` enthält die frischen Original-/Solver-/Backendmodelle, Punkte, Optionen, Runtime- und Hashnachweise, Rohlogs, Operationsbelege, Diagnoseskripte und gescheiterte Versuche. `reproduction_manifest.json` beschreibt jeden publizierten Eintrag; das Archiv wurde vollständig zurückgelesen und mit SHA256 geprüft. Nur numerische Lizenzkennungen in publizierten Textkopien wurden maskiert; Originalhash, publizierter Hash und Grund stehen pro Eintrag im Manifest. Die externen Rohoriginale bleiben unverändert. Unveränderte historische Inputkopien und Paketbinärdateien werden nicht erneut verbreitet.

## Grenzen und getrennte Gates

Geltungsbereich sind ausschließlich die neun registrierten binär-rationalen Modellinputs und die dokumentierten Skalierungs-/Toleranzmodi auf dieser Laufzeit. Die Eingabeschutzschranke verwirft nichtnull Constraint-Koeffizienten unter `1e-9`, Größen über `2^40`, nicht exakt abbildbare Intervallweiten und nicht sicher konditionierbare Objectives. Solche Eingaben liefern `OPTIMIZE_NOT_CALLED/NO_SOLUTION` und eine Diagnose, kein mathematisches `INFEASIBLE`. Der `<1e-12`-Adversarialfall demonstriert eine Restgrenze des alten HiGHS-Filters; die neue Route verwirft ihn sicher vor Solve. Die geprüften registrierten Originalkoeffizienten liegen klar innerhalb der Schranken. Dies ist keine universelle numerische Robustheitsgarantie und keine Zertifizierung sämtlicher interner Herstellercuts, Presolveoperationen oder Branch-and-Bound-Knoten.

G3-MISOCP-Erfolg belegt keine native G0-MISDP-Fähigkeit. G0 behält den vorhandenen Pajarito-Vergleich; M3 bleibt separat. Die neun alten rationalen Kostenintervalle sind ausschließlich in ihrer ursprünglichen normalisierten binär-rationalen Domäne erhalten, keine neu bewiesenen optimalen Integerkosten. Lizenzabhängigkeit, endliche Ressourcen, unabhängige Abnahme, wissenschaftliche Ratifizierung und Datenqualifikation bleiben offen.

`B1_repaired=false`, `native_G3_MISOCP=numerical_inconclusive`, `integer_optimality_proved=false`, `integer_globality=case_specific_partial`, `science_amendment_approved=false`, `independent_A3_5_accepted=false`, `A3_closed=false`, `AP4_ready=false`, `empirical_study_ready=false`. Nur ein neuer unabhängiger A3.7-B1-Reviewer darf die materielle Korrektur im expliziten Geltungsbereich akzeptieren. Alle weiteren Bedingungen und Pflichtprüfungen stehen im eigenständigen `reaudit_handoff.md`.
''')
text('transformationsnachweis.md',r'''
# Mathematischer Nachweis und Prüfumfang

## Ursprüngliches Modell

Unverändert sind M_t = B_t - alpha S_t, S_t = diag(p_t), B_t = B0 + diag(b_fix + b_src), alle ungerichteten Kanten genau einmal und die diagonalen Slackzeilen. Für jede Kante lautet die unveränderte Bedingung (u,v,w) in Qr mit u=q_ij, v=q_ji und w dem bereits emittierten Float64-Ausdruck sqrt(2)*M_ij. Eine neue sqrt(2)-Approximation wird nicht eingeführt. Der Nachweis gilt für die tatsächlich eingefrorenen binär-rationalen Koeffizienten, nicht als Gleichsetzung von Float64-sqrt(2) mit der reellen irrationalen Zahl. Die G0/G3-Theoremdomäne bleibt die eingefrorene symmetrische Z-Matrixdomäne.

## Exakte finale Backendabbildung

Für affine u(x),v(x),w(x) fügt die vorhandene MOI-Bridge neue reelle Variablen U,V,W und exakte lineare Verknüpfungen U=u(x), V=v(x), W=w(x) hinzu. Sie emittiert U>=0, V>=0 und W²-2UV<=0. Damit gilt in beiden Richtungen durch Einsetzen unmittelbar (u,v,w) in Qr genau dann, wenn eine solche Erweiterung existiert. Die Nichtnegativitätsbounds U>=0,V>=0 am nativen Backend sind redundant: Für jeden existiert bereits die identische affine Zeile 1*U>=0 bzw. 1*V>=0. Diese Identität wird vor dem Hinzufügen geprüft und pro Kegel protokolliert. Der Gurobi-Parameter NonConvex=0 verwirft unerkannte nichtkonvexe Formulierungen; er verändert die mathematische Menge nicht.

MOI speichert den diagonalen quadratischen Term als 1/2*q*W²: deshalb wird q=2 als W² und der Kreuzterm -2 als -2UV geprüft. Der separate Python-Prüfer verwendet diese Konvention ausdrücklich. Keine gerundete 1/sqrt(2)-Rotation wird im finalen Input benutzt.

Eine Intervallbedingung l<=f(x)<=u wird durch f(x)=z, z in [l,u] dargestellt; alternativ durch eine äquivalente verschobene Slackkoordinate. Das Existenzquantorargument liefert exakt dieselbe Projektion. Die tatsächlich verwendeten Intervallweiten müssen in Float64 exakt u-l darstellen. Der Nachweis zählt Intervalle und Links mit Multimengen, erhält Integerdomänen und lehnt zusätzliche nicht bewiesene Zeilen ab.

Die bereits vorhandenen Objective-Inkremente z=x-l mit z>=0 werden nur verwendet, wenn die ursprüngliche Grenze x>=l vorhanden ist. Jeder ursprüngliche zulässige Punkt hat die eindeutige Erweiterung z=x-l, jeder erweiterte Punkt projiziert auf denselben ursprünglichen Punkt. Originalvariablen bleiben unverändert, insbesondere wird keine Ganzzahligkeitsdomäne relaxiert oder fixiert. Die algebraische Zielfunktion c*x = c*z+c*l ist über exakter Arithmetik identisch; tatsächlich erfolgte Float64-Addition/Division wird zusätzlich getrennt geprüft.

## Objective und tatsächliches delta(x)

Sei C_emitted(x) die ursprüngliche affine Kostenfunktion, F_s(x,z) die tatsächlich emittierte rebased/dividierte Float64-Funktion bei gewünschtem Divisor s>0. Die neue Funktion lautet F_backend = r*F_s mit r=2^k>0. Sämtliche Koeffizienten und die Konstante werden mit r multipliziert; für jeden tatsächlichen Float64-Term wird Fraction(new)==r*Fraction(old) geprüft. Nullterme gehen nicht verloren. Endlichkeit und Obergrenze 2^40 werden geprüft; der kleinste nichtnull Objective-Term muss mindestens 2^-8 sein. Dadurch bleibt die Optimierungsordnung von F_s exakt erhalten.

Nach Elimination aller Graphvariablen wird für jeden Lauf die tatsächliche Identität

    (s/r)*F_backend(x,z(x)) = C_emitted(x) + delta(x)

mit exakten binär-rationalen Koeffizienten rekonstruiert. `actual_objective_coordinate_delta` enthält jeden nichtnull Term, die Konstante und die Auswertung am exakt zulässigen Zeugen. Die alte Rebase-/Divisionsrundung wird nicht als Null gesetzt. Die neue Multiplikation erzeugt nach Prüfung keinen weiteren Rundungsfehler. Eine globale Schranke für delta(x) wird nicht behauptet; deshalb ist (s/r)*bound_backend lediglich eine nominale numerische Originalkoordinate, kein rigoroser Währungsbound.

Die erneute Auswertung der Originalkosten für jede ausgegebene Lösung benutzt C_emitted selbst. Beim Vergleich gegen exakte Zeugen werden Bounds und Zeugenziele unmittelbar in derselben Backendkoordinate verglichen, ohne gerundete Rückkonversion. Ein positiver exakter Überschuss verwirft die Bound-Aussage unabhängig von einer Gap-Toleranz. In den 37 finalen G3-Läufen tritt keiner auf.

## Startpunkt und Status

Die temporäre Standardrotation ist eine numerische Heuristik ohne Modellgleichheitsbehauptung. Es wird ausschließlich ein endlicher, am Originalmodell numerisch geprüfter primaler Start an den finalen Optimierer übergeben. Ein Start ist keine Constraint und schränkt daher die zulässige Menge nicht ein. Der finale Solver darf den Start verbessern oder verwerfen; der tatsächliche finale Modellinhalt wird vollständig exportiert. Keine Bound- oder Dualaussage aus dem heuristischen Lauf wird verwendet.

Der Abschluss `OPTIMAL` bleibt ein Rohstatus des endlichen numerischen Solves. Originalmodell, Linear-/Integer-/Kegelresiduen und Backend werden separat geprüft. Ungeprüfte oder verletzte Punkte sowie Guardablehnungen erhalten keine mathematische Infeasibility-/Globalitätsfreigabe. Der Herstellerbaum bleibt unzertifiziert.

## Kegelschnitte, endliche Filter und negative Kontrollen

Qr ist in der verwendeten Konvention selbstdual. Für einen exakt geprüften Dualvektor y mit y1,y2>=0 und 2*y1*y2>=sum(y_tail²) ist <y,z>>=0 für jedes z in Qr global gültig. Jede positive exakte Zeilenskalierung erhält Richtung und Menge; RHS und Konstante müssen vollständig mitskaliert werden. Der separate Test benutzt y=(1,1,-1), prüft Dualmitgliedschaft exakt und weist falsches Vorzeichen, fehlenden Term, einen dual unzulässigen Vektor und inkonsistente positive RHS am Kegelursprung zurück; eine vollständige Zweierpotenzskalierung wird exakt geprüft. Dies zertifiziert diesen Testschnitt, nicht beliebige interne Solvercuts.

14 echte HiGHS-Regressionen erhalten Default-Falsch-Infeasibilität, akzeptierten 1e-12-Fix, exakte 2^33-Skalierung und die adversariale Restgrenze unter 1e-12. Tatsächlich exportierte HiGHS-Zeilen sind archiviert. Der neue Gurobi-Pfad verwendet keine Pajarito-OA-Cuts; winzige ursprüngliche Constraint-Terme unter seiner deklarierten 1e-9-Schutzschranke werden vor der Optimierung abgelehnt. Die aktuelle Matrix durchläuft keine solche Ablehnung. Das ist eine endliche geprüfte Eingabedomäne, kein Beweis über sämtliche internen Presolve-/Cutoperationen.

Vier gezielte Manipulationen am tatsächlichen nativen Backend — falsches Vorzeichen des Kreuzterms, fehlender Quadratterm, verschobene Verknüpfungs-RHS und veränderte Intervallgrenze — werden sämtlich vom separaten Identitätsprüfer verworfen. Außerdem wird jeder der 46 Originalpunkte um 0.5 in einer Integerkoordinate verfälscht und verworfen. Diese Kontrollen verhindern einen bloßen Immer-PASS-Prüfpfad.

## Numerischer und exakter Befund

Die neuen Solverpunkte besitzen geringe nichtnull Gleichungsresiduen und gelten innerhalb 1e-7 als numerisch zulässig. Kein solcher Punkt wird zu einem exakten Zeugen erklärt. Historische Original-/normalisierte Zeugen werden dagegen mit Fraction und für G0 mit exakten Hauptminoren geprüft. Die erhaltenen neun A3.6-Intervalle sind separate exakte Aussagen über ihre ursprünglichen Modelle; native numerische Bounds stärken diese Aussagen nicht.
''')
text('reproduce.md',f'''
# Reproduktion — vorhandener Checkout, ausschließlich neue externe Ausgabeordner

Produktionsrevision `{PROD}`, separate Oracle-/Evidenzrevision `{ORACLE}`. Der publizierte Branch enthält beide unverändert; der endgültige Remote-SHA steht im additiven Publikationsbeleg. Keine automatische Ausführung eines Checkout-/Reset-/Mergebefehls. Vorher fremde Dateien inventarisieren und Schreibpfade prüfen. Das 28-Dateien-Inventar ist nur für den bestehenden Checkout eine autorisierte Ausnahme, keine allgemeine Dirty-Checkout-Freigabe.

## Laufzeit

Windows, Julia 1.10.11, JuMP 1.31.1, MathOptInterface 1.51.2, Pajarito 0.8.3, HiGHS.jl 1.24.1 / native 1.15.1, Clarabel 0.11.1, Gurobi.jl 1.9.2 / native 12.0.3, Mosek.jl 11.0.1, MosekTools 0.15.10 / native 11.0.29. Python 3 mit NumPy, Standardbibliothek einschließlich Fraction/tomllib. Verwendeter Pythonpfad: `C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe`.

Das bestehende Manifest installieren, nicht aktualisieren. Die zwei Mosek-Pakete sind exakt gepinnt. Für eine andere vorhandene Installation den tatsächlichen Librarypfad und Lizenznutzbarkeit erneut prüfen; keine Lizenzdatei modifizieren. Auf diesem Rechner wurde Mosek mit prozesslokalem `MOSEKBINDIR=C:/Program Files/Mosek/11.0/tools/platform/win64x86/bin` gebaut. Gurobi.jl benutzt die vorhandene lokale 12.0.3-DLL. Für einen frischen Depot kann gemäß dem gepinnten `deps/build.jl` `GUROBI_JL_USE_GUROBI_JLL=false` zusammen mit `GUROBI_HOME=C:/gurobi1203/win64` und `Pkg.build("Gurobi")` erforderlich sein. Tatsächlich geladene Bibliothek/version danach erneut prüfen; JLL-Metadaten allein genügen nicht. Das ist eine Reproduktionsanweisung, keine hier behauptete zusätzliche Neuinstallation.

## Archivprüfung und Inputs

`verify_publication.py` prüft jede Datei dieses Reportpakets sowie jeden ZIP-Eintrag mit SHA256. Archiv zunächst vollständig prüfen, dann ausschließlich in einen neuen externen Ordner extrahieren. `reproduction_manifest.json` verzeichnet Original-/Publikationshashes und eventuelle Lizenz-ID-Maskierungen.

Die vorhandenen SHA-geprüften Inputs werden über `reports/a3_6/reaudit_20261021/run_suite.py` in dessen frischem externem Ausgabeordner nach `prior/` extrahiert. Die 406 A3.6-Witness-ZIP-Einträge und 381 EXEC-Einträge sind vollständig geprüft; der Reaudit-ZIP hat 130 vollständig geprüfte Einträge. Die Archive bleiben an ihren gepinnten vorhandenen Reportpfaden. `continuation/integrity/integrity.json` im neuen ZIP und die alten unveränderten Reproduktionsmanifeste benennen Pfade/Hashes.

## Frischer integrierter Lauf (PowerShell, Variablen an eigene neue Pfade anpassen)

```powershell
$repoPath = 'D:/Projekte/Code/FlexPlan_UC_GSCR'
$pythonExe = 'C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$validationOut = 'D:/Downloads/A37_independent_NEW_validation'
$matrixOut = 'D:/Downloads/A37_independent_NEW_matrix'
Set-Location -LiteralPath $repoPath
$env:JULIA_NUM_THREADS = '1'
& $pythonExe reports/a3_6/reaudit_20261021/run_suite.py $repoPath $validationOut regression
& $pythonExe reports/a3_6/reaudit_20261021/run_suite.py $repoPath $validationOut exact
& julia +1.10.11 --startup-file=no --project=. test/paper_a_native_g3_solver.jl
& julia +1.10.11 --startup-file=no --project=. scripts/paper_a/qualify_native_g3.jl $repoPath $matrixOut "$validationOut/prior"
& $pythonExe scripts/paper_a/verify_native_g3.py $matrixOut "$validationOut/prior"
```

Jeden Exitcode unmittelbar prüfen. Der letzte Prüfer schreibt Residuen/Befunde; zusätzlich explizit prüfen, dass alle 46 Originalpunkte `numerical_pass=true`, alle 37 Backendidentitäten wahr, alle 37 Backendpunkte zulässig und alle `native_bound_contradiction=false` sind. Er ersetzt keine personell unabhängige Reviewentscheidung.

Für die 27/18 frischen Vergleichsexporte wurden die unveränderten A3.6-Skripte `model_inclusion.jl` und `objective_snapshots.jl` mit **absolutem** Repoargument aufgerufen; anschließend `compare_fresh.py`. Die tatsächlichen vollständigen Befehle, Argumentreihenfolgen, Exitcodes, UTC-Zeiten und Source-SHA-Manifeste sind in `operations.json` und `continuation/operations/*/command.json` im ZIP enthalten. Sie sind verbindlicher als abgekürzte Beispielbefehle.

## Diagnosen, CLI, Fehler und übrige Tests

Die archivierten technischen Treiber enthalten ihre absoluten Scratchpfade; für erneute Läufe diese auf neue Ausgabeordner ändern, keine alten Resultate überschreiben. `candidate_diagnostics.jl` prüft echte Integer-RSOC-Capabilities und Originalmodell-Solves mit Gurobi/MOSEK; `analyze_candidates.py` prüft Originalidentität und exakte Zeugen. `filter_regressions.jl`, `pajarito_gap_diagnosis.jl`, `pajarito_double_gap.jl`, `backend_negative_controls.py` und `summarize_final.py` enthalten die gezielten positiven/negativen Nachweise.

`run_final_cli_contract.py` ruft alle acht echten bestehenden CLI-Aktionen auf einem registrierten 3-Snapshot-Fall mit allen neun Formulierungen und beiden Relaxationen auf; die neun Fälle der Solvermatrix sind separat vollständig. Danach führt `raw_metric_replay.py` die unveränderten NumPy-Funktionen des alten Oracles und `independent_metric_audit.py` alle 124 Werte-/CSV-Prüfungen aus. Der vollständige alte Sympy-Treiber ist wegen fehlender Dependency gesondert als nicht ausgeführt dokumentiert; kein alter PASS wird dafür eingesetzt.

Für jede Mutation / jeden verworfenen Implementierungsversuch bleibt das Rohlog im ZIP. Drei absichtlich ungültige CLI-Aktionen erwarten Exit 1. Die früheren wirklichen Fehlversuche dürfen dagegen nicht als erfolgreiche negative Tests gezählt werden; `attempts.md` unterscheidet diese Gruppen. Keine Lizenzdateien oder nativen Binärpakete sind Bestandteil der Veröffentlichung.
''')
text('reaudit_handoff.md',f'''
# Eigenständiger Handoff — neuer A3.7-B1-REVIEWER

Du bist ein neuer personell unabhängiger Reviewer. Der Implementierer hat **keine** seiner materiellen Änderungen unabhängig abgenommen. Ausgangsurteil dieses Pakets: `correction_ready_for_independent_reaudit`; sämtliche Schlussgates bleiben gemäß `release_gates.yaml` offen.

Repository: https://github.com/AlOussama/FlexPlan.jl. Kandidatenbranch: `fix/paper-a-a3-7-b1-native-solver-v1`. Prüfe den Remote-SHA selbst und verwende ausschließlich den im Publikationsbeleg / abschließenden Handoff gepinnten Stand. Produktions-SHA **`{PROD}`**; Oracle-Nachweisrevision **`{ORACLE}`**; Parent **`{BASE}`**. Spätere Commits dürfen nur additive Evidenz enthalten. Bei einer Abweichung Solver-/Modell-/Dependencybytes erneut vergleichen und nicht den Branchname als Pin behandeln.

## Unabhängig nachzuprüfende Behauptungen

1. Vollständige Commit-/Ancestry-, Diff- und Datei-/ZIP-Hashprüfung; keine Veränderungen an Originalen, fremden Refs, 28 fremden `audit/`-Dateien oder anderen Worktrees. Verifiziere Inventar und Publikationsreceipt. Die damalige Dirty-Ausnahme ist explizit auf diese 28 unveränderten Dateien begrenzt.
2. Original-G3-SHA `fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07`, neun Modelle und 27/18 frische Vergleichsexporte unabhängig prüfen. Exakte Integerdomänen, B/p/S/M/Kanten/Slackgleichungen und ursprüngliche Kosten bewahren.
3. Tatsächliche finale Gurobi-Backendmodelle prüfen, nicht nur JuMP-Caches: Constraintmultimengen, vollständige Objektivkonstante, exakte Intervalle/Graphprojektionen, 1.368 Quadratiken `W²-2UV<=0`, redundante Bounds mit exakter bestehender Nichtnegativitätszeile. Insbesondere ausschließen, dass eine gerundete RSOC-Standardrotation noch final benutzt wird. Die Negativkontrollen an Vorzeichen, Term, RHS und Intervall müssen scheitern.
4. Temporären Startlauf isolieren: Standardrotation nur Heuristik; weder Bound noch Modellgleichheit daraus akzeptieren, keine Integerfixierung/Constraint. Startpunkt und finalen Punkt unabhängig am ursprünglichen Modell prüfen. Ohne Vertrauen in Implementierer-PASS alle Residuen nachrechnen; deklarierte Schranke 1e-7 und tatsächliche Maxima auswerten. Exakte und numerische Zulässigkeit strikt trennen.
5. Original-Default und Doppeldivisor frisch ausführen, anschließend gesamte 45-Läufe-Matrix plus literal Originaldefault. Produktionsbefund 46 `OPTIMAL/FEASIBLE_POINT`, 46 geprüfte Originalpunkte, 37 geprüfte tatsächliche G3-Backends. Startphase max.30 s, finaler Solve max.120 s, Vorbereitungszeit separat; End-to-End-Zeit nicht mit nur finaler Solvezeit verwechseln.
6. HiGHS/Clarabel/Pajarito sowie Gurobi/MOSEK durch echte Capabilities prüfen. MOSEK-Julia wurde tatsächlich angebunden; seine 120-s-Stressgrenzen bleiben sichtbar. Keine native G0-MISDP-Fähigkeit aus G3 ableiten. Native Laufzeitversion und Lizenzsolve prüfen, nicht JLL-Version/Paketimport.
7. Numerische Boundwidersprüche selbst reproduzieren: raw Gurobi und raw MOSEK auf identischem Original sowie Pajarito mit engerem innerem Gap. Historischen exakt zulässigen Zeugen in exakt derselben Backendkoordinate auswerten. In der finalen Route darf kein numerischer Bound über einem exakt zulässigen Zeugenziel liegen. Trotzdem keine rigorose Boundgültigkeit allein aus fehlendem Gegenbeispiel folgern.
8. Tatsächlich emittiertes Rebase-/Divisionsziel und Zusatzmultiplikation einschließlich Konstante exakt rekonstruieren; delta(x) nicht nullsetzen. Ungeprüfte native Bounds dürfen keine akzeptierte globale Währungsgap-Aussage liefern. `compare_formulations` muss diese Schlussaussage offenlassen. Die ursprünglichen neun rationalen Kostenintervalle bleiben auf ihre ursprüngliche normalisierte binär-rationale Domäne beschränkt.
9. Kausaldiagnose separat nachrechnen: inneres HiGHS `mip_abs_gap=1e-6` versus äußeres Pajarito `tol_abs_gap=1e-8`; einseitige Änderung auf1e-10 löst am identischen Doppeldivisorinput den Iterationsstopp. Ein erfolgreicher Optionenlauf ist wegen eigener numerischer Boundgegenbeispiele noch keine robuste Gesamtclosure.
10. Vollständige Regressionen und exakte Zertifikate frisch ausführen; Vorgabe 6087,4108,42,16,171 plus34 neue Tests und 14 Filtertests. Unabhängigen A3.6-Reviewerpfad verwenden, exakte Primale/LP-Duale/Objectivekoordinaten erneut prüfen. 124-Metrik-/8-CLI-Vertrag und dokumentierte Sympy-Einschränkung getrennt beurteilen.

## Entscheidung und offene Gates

Zulässig ist ein auf die tatsächlich geprüfte endliche Domäne begrenztes unabhängiges Urteil; kein universelles Float64-MISOCP-Versprechen. Nur du darfst bei positivem eigenem Nachweis `B1_repaired` bzw. einen begrenzten nativen G3-Qualifikationsstatus ändern. Weder dieses Implementiererpaket noch `OPTIMAL` ist ein exakter Hersteller-Cut-/Nodebaumbeweis. M3-Integerglobalität/-optimalität, wissenschaftliches Amendment/Ownerratifizierung, unabhängige A3.5-Gesamtabnahme, Daten-/Empiriequalifikation, `A3_closed` und `AP4_ready` sind gesonderte Entscheidungen und bleiben offen.

Beginne mit `implementierungsbericht.md`, `transformationsnachweis.md`, `solver_matrix.csv`, `solver_comparison.json`, `reproduction_manifest.json`, `operations.json`, `reproduce.md` und `publication_receipt.json`. Verwende eigene Oracles und neue externe Laufordner; historische Inputs nicht überschreiben. Der Auftrag an dich erteilt keine automatische Merge-/Reset-/Branchlöschfreigabe und verlangt keinen zusätzlichen Worktree.
''')
expected={'cli_negative_existing_output','cli_negative_missing_input','cli_negative_unknown_action','final_cli_negative_existing_output','final_cli_negative_missing_input','final_cli_negative_unknown_action'}
lines=['# Versuche, Fehler und bewusst getrennte Ergebnisse','',
       'Alle Rohlogs bleiben erhalten. Folgende Exitcodes sind echte Prozessbefunde, keine umetikettierten PASS-Meldungen. Vollständige erfolgreiche Operationsdaten stehen in `operations.json`.','',
       '| Operation | Exit | Einordnung |','|---|---:|---|']
reasons={'cli_raw_oracle':'Vollständiger alter Treiber: sympy fehlt; begrenzte NumPy-Wertprüfung anschließend separat bestanden.',
         'controlled_seed_unit':'Temporäre Kopie hatte die zu entfernende Bridge nicht registriert; Korrektur ausschließlich im Startworkflow, finaler Lauf bestanden.',
         'exact_bridge_unit':'Gurobi error10020: affine Nichtnegativitätszeilen reichen dem Convexitydetektor nicht; anschließend exakt bewiesene redundante Variablebounds ergänzt.',
         'final_backend_oracle_early':'Prüfer erkannte die vorhandene Intervall-SlackBridge noch nicht; Nachweis erweitert, Solver unverändert.',
         'fresh_18_objectives':'Relativer Repopfad wurde vom alten Include relativ zum Skript interpretiert; mit absolutem Pfad wiederholt.',
         'fresh_27_models':'Relativer Repopfad wurde vom alten Include relativ zum Skript interpretiert; mit absolutem Pfad wiederholt.',
         'native_matrix_first':'Julia-Docstring stand vor using; technischer Treiber repariert.',
         'native_unit_first':'Guard für nichtendliche skalierte Konstante und affine Behandlung variabler Objective ergänzt.'}
for row in S['operations']:
    if row['exitcode']:
        why='Erwartete negative CLI-Eingabe, korrekt Exit1.' if row['name'] in expected else reasons.get(row['name'],'Verworfener Zwischenversuch, Rohfehler siehe Archiv.')
        lines.append(f"| {row['name']} | {row['exitcode']} | {why} |")
lines+=['','MOSEK-Matrizen mit zwei bzw. drei TIME_LIMITs, direkte exakte Gurobi-Quadratik ohne Start mit TIME_LIMIT, raw Gurobi/MOSEK-Boundwidersprüche und Pajarito-ITERATION_LIMIT sind numerische Ergebnisse bei teilweise erfolgreichem Prozess-Exit0. Sie stehen ausdrücklich in den jeweiligen JSON-Ergebnissen und sind kein wissenschaftliches PASS.','',
        'Die erste Preflight-Probe enthielt einen Julia-Parsefehler; der unveränderte Preflight hält Fehlversuch und Korrektur fest. Ein ergänzender Summarytreiber hatte einen fehlenden optionalen Literalmodell-Hashschlüssel; er wurde vor Publikation korrigiert, ohne Solvercode oder Resultate anzupassen.']
text('attempts.md','\n'.join(lines))

# Preserve all new raw outputs/logs and diagnostic sources. Reused copies of
# immutable historical sources/inputs are referenced by their pinned manifests.
skiptrees={('integrity','prior'),('integrity','historical'),('integrity','validation'),('integrity','moi_guards'),
    ('selected_validation','prior'),('selected_validation','historical'),('selected_validation','validation'),('selected_validation','moi_guards'),
    ('final_validation','prior'),('final_validation','historical'),('final_validation','validation'),('final_validation','moi_guards')}
selected=[]
for p in sorted(R.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(R)
    if '__pycache__' in rel.parts or any(tuple(rel.parts[:2])==key for key in skiptrees):continue
    selected.append((p,'continuation/'+rel.as_posix()))
for p in sorted(PRE.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(PRE)
    if rel.parts[0] in ('pinned_environment','pinned_readonly_inputs') or rel.name=='input_witnesses.zip':continue
    selected.append((p,'preflight/'+rel.as_posix()))
entries=[];archive=OUT/'native_solver_evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p,name in selected:
        raw=p.read_bytes();published=raw;redacted=False
        if p.suffix.lower() in ('.log','.txt','.json','.md','.yaml'):
            new=re.sub(rb'(LicenseID to value )\d+',rb'\1[REDACTED_LICENSE_ID]',raw)
            if new!=raw:published=new;redacted=True
        z.writestr(name,published)
        entries.append(dict(path=name,bytes=len(published),sha256=sha(published),original_bytes=len(raw),original_sha256=sha(raw),redaction='numerical_license_identifier_only' if redacted else None))
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(entries)
    for e in entries:
        b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256']
dump('reproduction_manifest.json',dict(archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive.read_bytes()),all_entries_readback_verified=True),entries=entries,
    omitted_immutable_input_copies=[list(x) for x in sorted(skiptrees)],
    original_external_roots=[str(R),str(PRE)],note='All scientific log content retained; published LicenseID-only redactions explicitly hashed. Immutable old archives referenced instead of duplicated.'))
text('verify_publication.py',r'''
import hashlib,json,pathlib,zipfile
r=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
m=json.loads((r/'reproduction_manifest.json').read_text())
for n,v in json.loads((r/'package_sha256.json').read_text()).items():
    b=(r/n).read_bytes();assert len(b)==v['bytes'] and sha(b)==v['sha256'],n
a=r/m['archive']['path'];assert sha(a.read_bytes())==m['archive']['sha256']
with zipfile.ZipFile(a) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(m['entries'])
    for e in m['entries']:
        b=z.read(e['path']);assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path']
print('PASS: package hashes and',len(m['entries']),'complete ZIP entry hashes')
''')
dump('package_sha256.json',{p.name:dict(bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='package_sha256.json'})
print('PACKAGE',OUT,'archive_bytes',archive.stat().st_size,'entries',len(entries),'license_id_redactions',sum(bool(e['redaction']) for e in entries))
