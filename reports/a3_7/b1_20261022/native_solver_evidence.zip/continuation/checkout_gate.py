import pathlib, subprocess, hashlib, json, datetime
repo=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
run=pathlib.Path(__file__).resolve().parent
old=pathlib.Path(r'D:\Downloads\A3_7_B1_preflight_20261022_203803')
pin='15ba10c193a562a48cb0e1dcc6fa12d922ac0613'
branch='fix/paper-a-a3-7-b1-native-solver-v1'
def git(*a): return subprocess.check_output(['git',*a],cwd=repo)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((old/'state_before.json').read_text())
actual={n:sha(repo/n) for n in git('ls-files','--others','--exclude-standard','-z').decode().strip('\0').split('\0') if n}
assert len(actual)==28 and actual==baseline['untracked'],'foreign files changed or unexpected untracked files'
assert not git('diff','HEAD','--binary'),'unexpected tracked/index changes'
assert git('rev-parse','HEAD').decode().strip()==baseline['head']
assert git('branch','--show-current').decode().strip()==baseline['branch']
assert not git('branch','--list',branch).strip(),'local branch collision'
assert not git('ls-remote','origin','refs/heads/'+branch).strip(),'remote branch collision'
files=git('ls-tree','-r','--name-only',pin).decode().splitlines()
collisions=[(n,t) for n in actual for t in files if n==t or n.startswith(t+'/') or t.startswith(n+'/')]
assert not collisions,collisions
planned=['Project.toml','Manifest-v1.10.toml','scripts/paper_a/','test/','reports/a3_7/']
assert all(not p.startswith('audit') for p in planned)
state=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),old_head=baseline['head'],
    old_branch=baseline['branch'],target=pin,new_branch=branch,foreign_sha256=actual,
    branch_switch_path_collisions=collisions,planned_write_prefixes=planned,
    refs_before=git('show-ref').decode(),worktrees_before=git('worktree','list','--porcelain').decode(),
    authority='user continuation exception for exactly 28 unchanged audit files; no staging or modifying audit')
(run/'authority_preflight.json').write_text(json.dumps(state,indent=2),encoding='utf-8')
p=subprocess.run(['git','switch','-c',branch,pin],cwd=repo,capture_output=True)
(run/'branch_switch.stdout.log').write_bytes(p.stdout)
(run/'branch_switch.stderr.log').write_bytes(p.stderr)
assert p.returncode==0,p.stderr
assert {n:sha(repo/n) for n in actual}==actual
(run/'branch_gate_result.json').write_text(json.dumps(dict(exitcode=p.returncode,head=git('rev-parse','HEAD').decode().strip(),
 branch=git('branch','--show-current').decode().strip(),foreign_28_unchanged=True),indent=2),encoding='utf-8')
print('SPECIFICATION_READY; branch created; all 28 foreign files unchanged')
