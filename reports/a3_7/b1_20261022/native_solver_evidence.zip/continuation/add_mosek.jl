using Pkg
ENV["MOSEKBINDIR"]="C:/Program Files/Mosek/11.0/tools/platform/win64x86/bin"
Pkg.add([Pkg.PackageSpec(name="Mosek",version="11.0.1"),Pkg.PackageSpec(name="MosekTools",version="0.15.10")];preserve=Pkg.PRESERVE_ALL)
Pkg.instantiate(;allow_autoprecomp=false)
