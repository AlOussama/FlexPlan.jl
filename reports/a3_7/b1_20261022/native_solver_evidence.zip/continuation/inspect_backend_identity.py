import pathlib,ast,json,collections,itertools
from fractions import Fraction as Q
import numpy as np
repo=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
run=pathlib.Path(r'D:\Downloads\A3_7_B1_continuation_20261022/final_exact_route_matrix')
src=repo/'scripts/paper_a/verify_native_g3.py'
defs=[x for x in ast.parse(src.read_text()).body if isinstance(x,ast.FunctionDef)]
ns=dict(Q=Q,np=np,collections=collections,itertools=itertools,json=json)
exec(compile(ast.Module(body=defs,type_ignores=[]),str(src),'exec'),ns)
dr=run/'bess_premium_3snap_G3_production_costscale'
cached=json.loads((dr/'solver_input.mof.json').read_text());native=json.loads((dr/'actual_backend.mof.json').read_text());mp=json.loads((dr/'backend_variable_map.json').read_text())
before=ns['linear_rows'](cached,mp['cached_to_native']);after=ns['linear_rows'](native)
missing=before-after
print('missing',len(missing),'total missing',sum(missing.values()))
print(json.dumps(list(missing.items())[:12],indent=2))
print('native variable counts',len(cached['variables']),len(native['variables']))
print('native types',collections.Counter((c['function']['type'],c['set']['type']) for c in native['constraints']))
