NAME                : A3_7_B1_integer_RSOC_probe
PROBLEM STATUS      : PRIMAL_FEASIBLE
SOLUTION STATUS     : INTEGER_OPTIMAL
OBJECTIVE NAME      : obj
PRIMAL OBJECTIVE    : 5                       

AFFINE CONIC CONSTRAINTS
INDEX      NAME                                         I          ACTIVITY                 B                 
0          k1                                           0          5                        0                 
1          k1                                           1          1                        0                 
2          k1                                           2          3                        0                 

VARIABLES
INDEX      NAME                                         AT ACTIVITY                 LOWER LIMIT        UPPER LIMIT       
0          x                                            SB 5                        0                  10                
1          y                                            SB 1                        1                  1                 
2          z                                            SB 3                        3                  3                 
