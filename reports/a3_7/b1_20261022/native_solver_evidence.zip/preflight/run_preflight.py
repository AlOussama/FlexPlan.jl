import subprocess, pathlib, json, hashlib, datetime, shutil

ROOT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
PIN = '15ba10c193a562a48cb0e1dcc6fa12d922ac0613'
MANDA = pathlib.Path(r'D:\Downloads\M2_A3_7_B1_Autonomer_Codex_Makroauftrag_2026-10-22_v2_Gurobi_MOSEK.md')
commands = []
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def run(name,args,timeout=240):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        p=subprocess.run(args,cwd=REPO,capture_output=True,timeout=timeout)
        code=p.returncode; stdout=p.stdout; stderr=p.stderr
    except subprocess.TimeoutExpired as e:
        code='TIMEOUT'; stdout=e.stdout or b''; stderr=e.stderr or b''
    (ROOT/(name+'.stdout.log')).write_bytes(stdout)
    (ROOT/(name+'.stderr.log')).write_bytes(stderr)
    commands.append(dict(name=name,args=args,cwd=str(REPO),start_utc=start,
                         end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitcode=code))
    (ROOT/'commands.json').write_text(json.dumps(commands,indent=2),encoding='utf-8')
    print(name,code,flush=True)
    return stdout
def git(*args): return subprocess.check_output(['git',*args],cwd=REPO)
def snapshot():
    untracked=git('ls-files','--others','--exclude-standard','-z').decode().strip('\0').split('\0')
    return dict(head=git('rev-parse','HEAD').decode().strip(),
                branch=git('branch','--show-current').decode().strip(),
                status=git('status','--porcelain=v1').decode(),
                refs=git('show-ref').decode(),worktrees=git('worktree','list','--porcelain').decode(),
                tracked_diff_sha256=hashlib.sha256(git('diff','HEAD','--binary')).hexdigest(),
                index_sha256=sha(pathlib.Path(git('rev-parse','--git-path','index').decode().strip()) if pathlib.Path(git('rev-parse','--git-path','index').decode().strip()).is_absolute() else REPO/git('rev-parse','--git-path','index').decode().strip()),
                untracked={n:sha(REPO/n) for n in untracked if n},
                project_sha256=sha(REPO/'Project.toml'),manifest_sha256=sha(REPO/'Manifest-v1.10.toml'))
before=snapshot()
(ROOT/'state_before.json').write_text(json.dumps(before,indent=2),encoding='utf-8')
shutil.copyfile(MANDA,ROOT/MANDA.name)
env=ROOT/'pinned_environment'; env.mkdir(exist_ok=False)
for n in ['Project.toml','Manifest-v1.10.toml']:
    (env/n).write_bytes(git('show',PIN+':'+n))
readpaths={PIN:[
 'reports/a3_6/reaudit_20261021/'+n for n in [
 'independent_reaudit_report.md','release_gates.yaml','remaining_gates_handoff.md',
 'b1_stage_evidence.json','b1_solver_reliability_matrix.csv','reproduce.md',
 'reproduction_manifest.json','independent_certificate_results.json',
 'fresh_export_comparison.json','attempts.md']],
 '1147873bf553667aec5cd7eb0e9c6f7e471b370c':[
 'reports/a3_6/b1_opt_20261020/'+n for n in ['independent_b1_opt_closure_report.md',
 'pre_fix_original_verdict.md','b1_root_cause_or_limitation.md',
 'b1_original_vs_bridged_vs_oa_stage_evidence.json','objective_rebase_derivation.md','integer_9cases_bounds.json']]}
for pin,paths in readpaths.items():
    for p in paths:
        dest=ROOT/'pinned_readonly_inputs'/pin/p;dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(git('show',pin+':'+p))
run('remote',['git','ls-remote','origin','HEAD','refs/heads/master',
 'refs/heads/codex/a3-6-independent-reaudit-20261021','refs/heads/fix/paper-a-a3-6-b1-opt-v1',
 'refs/heads/fix/paper-a-a3-7-b1-native-solver-v1'])
run('code_identity',['git','diff','--exit-code','910d44122a37d9ed2cca06940740b46706c73d40',PIN,
 '--','src','scripts','test','Project.toml','Manifest-v1.10.toml'])
run('ancestry',['git','merge-base','--is-ancestor','910d44122a37d9ed2cca06940740b46706c73d40',PIN])
for solver in ['Pajarito','Gurobi','HiGHS','Clarabel','MosekTools']:
    run('probe_'+solver,['julia','+1.10.11','--startup-file=no','--threads=1',
        '--project='+str(env),str(ROOT/'probe.jl'),solver,str(ROOT/(solver+'.json'))])
run('mosek_cli_help',[r'C:\Program Files\Mosek\11.0\tools\platform\win64x86\bin\mosek.exe','-h'])
after=snapshot()
(ROOT/'state_after.json').write_text(json.dumps(after,indent=2),encoding='utf-8')
(ROOT/'preservation.json').write_text(json.dumps(dict(identical=before==after,
    created_worktrees=False,branch_changed=False,production_changed=False),indent=2),encoding='utf-8')
manifest={str(p.relative_to(ROOT)):dict(size=p.stat().st_size,sha256=sha(p))
          for p in ROOT.rglob('*') if p.is_file() and p.name!='sha256_manifest.json'}
(ROOT/'sha256_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print('PRESERVATION',before==after,flush=True)
