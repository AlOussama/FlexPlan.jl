"""Separate exact binary-rational arithmetic on archived MOF and emitted points."""
import pathlib,json,math,hashlib,collections
from fractions import Fraction as F
r=pathlib.Path(__file__).resolve().parent
model=r/'original_G3.mof.json'
d=json.loads(model.read_text())
assert hashlib.sha256(model.read_bytes()).hexdigest()=='fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07'
tol=F(1,10_000_000)
def q(v):
    if isinstance(v,float) and not math.isfinite(v): raise ValueError('nonfinite')
    return F(v)
def scalar(f,x):
    if f['type']=='Variable': return x[f['name']]
    assert f['type']=='ScalarAffineFunction',f['type']
    return q(f['constant'])+sum((q(t['coefficient'])*x[t['variable']] for t in f['terms']),F(0))
def check(point):
    x={k:q(v) for k,v in point.items()}
    assert set(x)=={v['name'] for v in d['variables']}
    maxima=collections.defaultdict(F); counts=collections.Counter(); worst={}
    for i,c in enumerate(d['constraints']):
        f,s=c['function'],c['set']; typ=s['type'];counts[typ]+=1
        if typ=='RotatedSecondOrderCone':
            assert f['type']=='VectorAffineFunction' and s['dimension']==3
            y=[q(v) for v in f['constants']]
            for t in f['terms']:
                a=t['scalar_term'];y[t['output_index']-1]+=q(a['coefficient'])*x[a['variable']]
            violation=max(F(0),-y[0],-y[1],y[2]**2-2*y[0]*y[1])
        else:
            v=scalar(f,x)
            if typ=='EqualTo': violation=abs(v-q(s['value']))
            elif typ=='GreaterThan': violation=max(F(0),q(s['lower'])-v)
            elif typ=='LessThan': violation=max(F(0),v-q(s['upper']))
            elif typ=='Interval': violation=max(F(0),q(s['lower'])-v,v-q(s['upper']))
            elif typ=='Integer': violation=abs(v-round(v))
            else: raise ValueError('unverified set '+typ)
        if violation>maxima[typ]: maxima[typ]=violation;worst[typ]=dict(index=i,name=c.get('name'))
    return dict(counts=dict(counts),maxima={k:dict(exact=str(v),display=float(v)) for k,v in maxima.items()},
                worst=worst,within_declared_tolerance=all(v<=tol for v in maxima.values()),
                exact_feasible=all(v==0 for v in maxima.values()),
                exact_serialized_objective=str(scalar(d['objective']['function'],x)))
results={}
for solver in ['Gurobi','Pajarito']:
    p=r/('original_'+solver+'_point.json')
    if p.exists():
        point=json.loads(p.read_text()); results[solver]=check(point)
        iv=next(c['function']['name'] for c in d['constraints'] if c['set']['type']=='Integer')
        mutated=dict(point);mutated[iv]+=0.5
        neg=check(mutated)
        assert not neg['within_declared_tolerance'] and neg['maxima']['Integer']['display']>0.49
        results[solver]['negative_control_integer_perturbation_rejected']=True
    else: results[solver]=dict(status='NOT_EXECUTED_NO_PRIMAL_POINT')
native=json.loads((r/'mosek_solution.json').read_text())
x,y,z=map(q,native['Task/solutions']['integer']['xx'])
assert x==5 and y==1 and z==3 and x.denominator==1 and 2*x*y>=z*z
results['MOSEK_native_small']=dict(exact_primal_check=True,exact_optimum_check=True,
    argument='2*x*1>=9 implies x>=9/2; integer x>=5; (5,1,3) feasible',
    original_G3_qualification=False,JuMP_MOI_probe_available=False)
results['tolerance_exact']=str(tol)
(r/'independent_original_residuals.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
print(json.dumps(results,indent=2))
