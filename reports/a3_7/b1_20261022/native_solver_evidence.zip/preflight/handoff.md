# Eigenständiger Fortsetzungs- und A3.7-B1-Reaudit-Handoff

Es liegt **kein neuer Produktionsfix** vor. Gesamturteil dieser Vorprüfung:
`blocked_environment_or_inputs`; Specification Gate: `SPECIFICATION_READY`.
Keine unabhängige Schlussabnahme oder neue Produktions-SHA behaupten.

1. Zuerst `bericht.md`, `release_gates.yaml`, `preservation_final.json` und
   `sha256_manifest.json` lesen. Der aktive Checkout war und ist die AP2-Branch
   bei `725de2e6c1cea21f63902474f72ec614b2358356`, mit 28 fremden unversionierten
   Dateien unter `audit/c2a_reproducible_environment/`. Abschnitt 5 des v2-Auftrags
   verbietet hier Branchwechsel/Implementierung. Keine neuen Worktrees erstellen.
   Vor Wiederaufnahme diesen konkreten Blocker sicher durch den Eigentümer
   auflösen oder die ausdrückliche Ausnahme dokumentieren; nichts fremdes löschen.
2. Danach alle Gates neu prüfen und genau eine kontrollierte neue M2-Branch aus
   `15ba10c193a562a48cb0e1dcc6fa12d922ac0613` anlegen. Produktionsfix
   `910d44122a37d9ed2cca06940740b46706c73d40` ist begrenzt unabhängig akzeptiert.
   Unveränderte Inputevidenz: `1147873bf553667aec5cd7eb0e9c6f7e471b370c`.
   Keine Übernahme aktueller master-SHAs als Ersatzautorität.
3. Solverfähigkeit aktuell neu bewerten: Gurobi.jl 1.9.2 lädt native 12.0.3
   mit in diesem Lauf gültiger akademischer Lizenz. MOSEK CLI 11.0.29 löst
   tatsächlich Integer-RSOC. `Mosek`/`MosekTools` fehlen im aktiven Julia-Depot;
   eine Paketinstallation war nicht autorisiert und wurde nicht ausgeführt.
   Reiner CLI-PASS ersetzt den verlangten JuMP/MOI-Nachweis nicht.
4. Höchste Priorität beim Solververgleich hat der neue Gurobi-Gegenbefund:
   `original_Gurobi.json` meldet OPTIMAL und Bound 0.018702546414934892.
   `historical_witness_comparison.json` prüft einen zulässigen Originalpunkt
   mit Zielwert ca. 0.01869304116753802 exakt. Die positive Boundüberschreitung
   ist als rationaler Bruch gespeichert. Den getrennten Python-Oracle erneut
   ausführen, Punkt/Modell anhand der Hashes binden und diesen Bound nicht
   als rigorose Untergrenze übernehmen. Gurobis neuer Punkt besteht die
   numerische Originalresiduenprüfung, ist aber nicht exakt zulässig.
5. Auf identischem Originalhash `fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07`
   reproduziert die unveränderte gepinnte Pajarito-Factory ITERATION_LIMIT /
   NO_SOLUTION. Repeated-integer-Warnungen und Restgap sind archiviert.
   Keine vollständige kausale Cutdiagnose oder Erklärung des Doppeldivisorfalls
   ist in dieser Vorprüfung abgeschlossen. Hier hat kein Original-MOSEK-Lauf
   und keine neue 45er Matrix stattgefunden.
6. Erst nach einer tatsächlichen materiellen Korrektur den gesamten v2-Contract
   B1-A bis B1-E absolvieren: Filterrestgrenze/negative Cutkontrollen,
   Original-/Bridge-/OA-/MIP-Identität, Default und Doppeldivisor,
   neun Fälle/45er Matrix, echte kommerzielle JuMP/MOI-Vergleiche,
   vollständige Regression und exakte Zertifikate sowie beide Kostenkoordinaten.
   Globale Cutgültigkeit und abgesicherte Boundinterpretation separat prüfen.
7. Auf der neuen eigenen Branch additiv veröffentlichen, Remote-SHA und
   Parent/Diff/Hashes verifizieren; keine PR, kein Merge, Rebase oder Reset.
   Ein dann neuer, personell unabhängiger A3.7-B1-REVIEWER muss die tatsächliche
   neue Produktionsrevision mit eigenen Oracles prüfen. Bis dahin bleiben
   B1_repaired=false, A3_closed=false und AP4_ready=false. Der Implementierer
   darf seine spätere Korrektur nicht selbst unabhängig abnehmen.

Reproduzierbare Eingänge sind das gepinnte Originalmodell, der vollständige
historische rationale Originalpunkt, der neue Gurobi-Punkt, die exportierte
unveränderte Factoryfunktion, die separaten Prüfer, tatsächliche Optionen und
sämtliche positiven/negativen Logs. Vollständige Archiventryverifikation und
sämtliche nicht ausgeführten Tests sind ausdrücklich nachzuholen. Die historischen
neun Intervalle gelten ausschließlich in ihrer bisherigen normalisierten
binär-rationalen Domain; M3/M4/Owner-Gates bleiben eigene Aufträge.
