import pathlib,subprocess,hashlib,zipfile,json
r=pathlib.Path(__file__).resolve().parent
repo=r'D:\Projekte\Code\FlexPlan_UC_GSCR'
pin='1147873bf553667aec5cd7eb0e9c6f7e471b370c'
name='reports/a3_6/b1_opt_20261020/verified_primal_dual_witnesses.zip'
raw=subprocess.check_output(['git','show',pin+':'+name],cwd=repo)
h=hashlib.sha256(raw).hexdigest()
assert h=='ca15ee8a3cd73eefe9c75b00896ec4f4cdb71f12e23d6fc55a0916e35417482c'
p=r/'input_witnesses.zip';p.write_bytes(raw)
with zipfile.ZipFile(p) as z:
    names=z.namelist()
    (r/'archive_listing.json').write_text(json.dumps(names,indent=2),encoding='utf-8')
    hits=[n for n in names if any(t in n for t in ['b1_exact_native.mof','reference_24snap','lp_bound_inputs','objective_snapshots'])]
    print('\n'.join(hits))
    originals=[n for n in names if n.endswith('b1_exact_native.mof.json')]
    for n in originals:
        b=z.read(n);mh=hashlib.sha256(b).hexdigest();print(n,mh)
        if mh=='fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07':
            (r/'original_G3.mof.json').write_bytes(b)
            (r/'original_model_provenance.json').write_text(json.dumps(dict(pin=pin,archive=name,
                archive_sha256=h,entry=n,model_sha256=mh,verification_scope='archive_SHA256_and_selected_model_only; not_all_entries'),indent=2),encoding='utf-8')
