import pathlib,subprocess,json,hashlib,datetime
r=pathlib.Path(__file__).resolve().parent
repo=pathlib.Path(r'D:\Projekte\Code\FlexPlan_UC_GSCR')
def git(*args): return subprocess.check_output(['git',*args],cwd=repo)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((r/'state_before.json').read_text())
index=pathlib.Path(git('rev-parse','--git-path','index').decode().strip())
if not index.is_absolute(): index=repo/index
untracked=git('ls-files','--others','--exclude-standard','-z').decode().strip('\0').split('\0')
after=dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),
    status=git('status','--porcelain=v1').decode(),refs=git('show-ref').decode(),
    worktrees=git('worktree','list','--porcelain').decode(),
    tracked_diff_sha256=hashlib.sha256(git('diff','HEAD','--binary')).hexdigest(),
    index_sha256=sha(index),untracked={n:sha(repo/n) for n in untracked if n},
    project_sha256=sha(repo/'Project.toml'),manifest_sha256=sha(repo/'Manifest-v1.10.toml'))
(r/'state_final.json').write_text(json.dumps(after,indent=2),encoding='utf-8')
pres=dict(identical=before==after,field_comparison={k:before[k]==after[k] for k in before},
    checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(r/'preservation_final.json').write_text(json.dumps(pres,indent=2),encoding='utf-8')
assert pres['identical'],pres
comparisons={s:json.loads((r/(s+'.json')).read_text()) for s in ['Pajarito','Gurobi','HiGHS','Clarabel','MosekTools']}
comparisons['MOSEK_native_CLI']={'classification':'supported_only_in_restricted_scope',
    'native_version':'11.0.29','scope':'small_integer_RSOC_native_CLI_only',
    'JuMP_MOI_backend':'unavailable_with_reason: MosekTools absent; no package installation performed',
    'solution':json.loads((r/'mosek_solution.json').read_text())['Task/solutions']}
comparisons['original_24snap']={s:json.loads((r/('original_'+s+'.json')).read_text()) for s in ['Gurobi','Pajarito'] if (r/('original_'+s+'.json')).exists()}
comparisons['independent_original_residuals']=json.loads((r/'independent_original_residuals.json').read_text())
comparisons['original_gurobi_bound_counterexample']=json.loads((r/'historical_witness_comparison.json').read_text())
(r/'solver_comparison.json').write_text(json.dumps(comparisons,indent=2),encoding='utf-8')
gates='''specification_status: SPECIFICATION_READY
execution_gate: BLOCKED_FOREIGN_UNTRACKED_CHECKOUT
m2_implementation_verdict: blocked_environment_or_inputs
production_correction_A3_6_scoped_accepted: true
production_correction_A3_6_source: pinned_independent_reaudit_not_repeated_here
new_production_correction_implemented: false
m2_new_correction_independent_reaudit: pending
m2_technical_candidate_for_reaudit: false
B1_repaired: false
native_G3_MISOCP: numerical_inconclusive
integer_bounds_proved: true
integer_bounds_scope: inherited_nine_normalized_binary_rational_intervals_not_reverified_here
integer_optimality_proved: false
integer_globality: case_specific_partial
science_amendment_approved: false
owner_ratification: pending
independent_A3_5_accepted: false
A3_closed: false
AP4_ready: false
empirical_study_ready: false
production_branch_created: false
new_worktree_created: false
committed_or_pushed: false
full_regression: NOT_EXECUTED
stress_45_runs: NOT_EXECUTED
exact_171_certificate_suite: NOT_EXECUTED
archive_all_entry_verification: not_verified
'''
(r/'release_gates.yaml').write_text(gates,encoding='utf-8')
manifest={str(p.relative_to(r)):dict(size=p.stat().st_size,sha256=sha(p))
          for p in r.rglob('*') if p.is_file() and p.name!='sha256_manifest.json'}
(r/'sha256_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps(pres,indent=2))
print('untracked_count',len(after['untracked']))
print('files_hashed',len(manifest))
