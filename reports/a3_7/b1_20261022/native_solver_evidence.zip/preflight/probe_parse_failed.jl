using JuMP, JSON
const MOI = JuMP.MOI
solver = ARGS[1]
out = ARGS[2]
r = Dict{String,Any}("solver"=>solver, "julia"=>string(VERSION),
    "active_project"=>Base.active_project(), "depot_path"=>DEPOT_PATH,
    "scope"=>"small_integer_RSOC_only; not_original_G3_qualification",
    "expected_exact_optimum"=>5, "tolerance"=>1e-7)
safe(f) = try f() catch; nothing end
t0 = time()
try
    opt = if solver == "Pajarito"
        @eval import Pajarito, HiGHS, Clarabel
        optimizer_with_attributes(Pajarito.Optimizer,
            "oa_solver"=>optimizer_with_attributes(HiGHS.Optimizer,
                "output_flag"=>false,"threads"=>1,"small_matrix_value"=>1e-12,
                "mip_feasibility_tolerance"=>1e-8,"mip_rel_gap"=>1e-8),
            "conic_solver"=>optimizer_with_attributes(Clarabel.Optimizer,
                "verbose"=>false,"tol_gap_abs"=>1e-10,"tol_gap_rel"=>1e-10,
                "tol_feas"=>1e-10,"max_iter"=>300),
            "verbose"=>false,"use_iterative_method"=>true,"tol_rel_gap"=>1e-7,
            "tol_abs_gap"=>1e-8,"tol_feas"=>1e-7,"time_limit"=>120.,"iteration_limit"=>100)
    elseif solver == "Gurobi"
        @eval import Gurobi
        Gurobi.Optimizer
    elseif solver == "MosekTools"
        @eval import MosekTools
        MosekTools.Optimizer
    elseif solver == "HiGHS"
        @eval import HiGHS
        HiGHS.Optimizer
    elseif solver == "Clarabel"
        @eval import Clarabel
        Clarabel.Optimizer
    else
        error("unknown solver")
    end
    mod = getfield(Main, Symbol(solver))
    r["package_version"] = string(Base.pkgversion(mod))
    r["package_path"] = pathof(mod)
    m = Model(opt)
    set_silent(m)
    solver == "Gurobi" && set_optimizer_attribute(m, "TimeLimit", 30.)
    solver == "HiGHS" && set_optimizer_attribute(m, "threads", 1)
    @variable(m, 0 <= x <= 10, Int)
    @variable(m, y == 1)
    @constraint(m, [x,y,3.] in RotatedSecondOrderCone())
    @objective(m, Min, x)
    r["moi_backend_type"] = string(typeof(backend(m)))
    r["solver_name"] = safe(()->solver_name(m))
    r["native_library_version"] = safe(()->MOI.get(backend(m), MOI.SolverVersion()))
    t = @elapsed optimize!(m)
    r["solve_wall_s"] = t
    r["termination"] = string(termination_status(m))
    r["primal_status"] = string(primal_status(m))
    r["dual_status"] = string(dual_status(m))
    r["result_count"] = result_count(m)
    r["objective_bound_numerical_only"] = safe(()->objective_bound(m))
    r["relative_gap"] = safe(()->relative_gap(m))
    r["nodes"] = safe(()->node_count(m))
    if has_values(m)
        xv,yv = value(x),value(y)
        r["primal"] = [xv,yv]
        r["objective"] = objective_value(m)
        r["linear_residual"] = max(0.,-xv,xv-10.,abs(yv-1.))
        r["integer_residual"] = abs(xv-round(xv))
        r["rsoc_residual"] = max(0.,-xv,-yv,9.-2*xv*yv)
        r["independent_numeric_check"] = maximum([r["linear_residual"],r["integer_residual"],r["rsoc_residual"],abs(xv-5.)]) <= 1e-7
    end
    r["classification"] = termination_status(m)==MOI.OPTIMAL && get(r,"independent_numeric_check",false) ? "supported_only_in_restricted_scope" : "numerical_inconclusive"
catch e
    r["classification"] = "unavailable_with_reason"
    r["error"] = sprint(showerror,e)
    r["error_type"] = string(typeof(e))
    println(stderr,r["error"])
end
r["total_wall_s"] = time()-t0
open(io->JSON.print(io,r,2),out,"w")
println(JSON.json(r))
