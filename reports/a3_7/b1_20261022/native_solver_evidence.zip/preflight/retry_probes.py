import subprocess, pathlib, json, datetime
root=pathlib.Path(__file__).resolve().parent
records=[]
for solver in ['Pajarito','Gurobi','HiGHS','Clarabel','MosekTools']:
    args=['julia','+1.10.11','--startup-file=no','--threads=1',
          '--project='+str(root/'pinned_environment'),str(root/'probe.jl'),solver,str(root/(solver+'.json'))]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        p=subprocess.run(args,cwd=root,capture_output=True,timeout=240)
        code=p.returncode; stdout=p.stdout; stderr=p.stderr
    except subprocess.TimeoutExpired as e:
        code='TIMEOUT'; stdout=e.stdout or b''; stderr=e.stderr or b''
    (root/('retry_'+solver+'.stdout.log')).write_bytes(stdout)
    (root/('retry_'+solver+'.stderr.log')).write_bytes(stderr)
    records.append(dict(solver=solver,args=args,cwd=str(root),start_utc=start,
        end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitcode=code))
    (root/'commands_retry.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    print(solver,code,flush=True)
