import subprocess, pathlib, datetime, json
root=pathlib.Path(__file__).resolve().parent
args=[r'C:\Program Files\Mosek\11.0\tools\platform\win64x86\bin\mosek.exe',
      '-r','-into',str(root/'mosek_integer.sol'),'-jsolo',str(root/'mosek_solution.json'),str(root/'integer_rsoc.ptf')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(args,cwd=root,capture_output=True,timeout=60)
(root/'mosek_native.stdout.log').write_bytes(p.stdout)
(root/'mosek_native.stderr.log').write_bytes(p.stderr)
(root/'mosek_native_command.json').write_text(json.dumps(dict(args=args,cwd=str(root),start_utc=start,
 end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitcode=p.returncode),indent=2),encoding='utf-8')
print(p.returncode)
print(p.stdout.decode(errors='replace'))
print(p.stderr.decode(errors='replace'))
