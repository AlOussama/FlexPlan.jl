import pathlib,subprocess,json,datetime
r=pathlib.Path(__file__).resolve().parent
repo=r'D:\Projekte\Code\FlexPlan_UC_GSCR'
s=subprocess.check_output(['git','show','15ba10c193a562a48cb0e1dcc6fa12d922ac0613:scripts/paper_a/AP3Pipeline.jl'],cwd=repo).decode()
factory=s[s.index('function pajarito_optimizer()'):s.index('writejson(path,x)=')]
(r/'factory_pinned.jl').write_text(factory,encoding='utf-8')
records=[]
for solver in ['Gurobi','Pajarito']:
    args=['julia','+1.10.11','--startup-file=no','--threads=1','--project='+str(r/'pinned_environment'),str(r/'original_probe.jl'),solver]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        p=subprocess.run(args,cwd=r,capture_output=True,timeout=210)
        code=p.returncode; stdout=p.stdout; stderr=p.stderr
    except subprocess.TimeoutExpired as e:
        code='TIMEOUT'; stdout=e.stdout or b''; stderr=e.stderr or b''
    (r/('original_'+solver+'.stdout.log')).write_bytes(stdout)
    (r/('original_'+solver+'.stderr.log')).write_bytes(stderr)
    records.append(dict(solver=solver,args=args,cwd=str(r),start_utc=start,
        end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitcode=code))
    (r/'commands_original.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
    print(solver,code,flush=True)
