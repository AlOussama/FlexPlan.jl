import runpy,pathlib,json
from fractions import Fraction as F
r=pathlib.Path(__file__).resolve().parent
g=runpy.run_path(str(r/'verify_original_points.py'))
point=json.loads((r/'historical_native_point.json').read_text())
check=g['check'](point)
assert check['exact_feasible']
original=json.loads((r/'original_Gurobi.json').read_text())
historical=F(check['exact_serialized_objective'])
bound=F(original['bound_numerical_only'])
incumbent=F(original['objective_numerical'])
out=dict(historical_original_point_verification=check,
    historical_original_objective_display=float(historical),
    gurobi_numerical_bound_minus_exact_feasible_objective=str(bound-historical),
    gurobi_numerical_bound_minus_exact_feasible_objective_display=float(bound-historical),
    gurobi_reported_incumbent_minus_exact_feasible_objective_display=float(incumbent-historical),
    bound_contradicts_exact_feasible_point=bound>historical,
    implication='Numerical Gurobi bound/OPTIMAL cannot be accepted as rigorous global optimality on this original objective' if bound>historical else 'No contradiction detected; bound still not certified')
(r/'historical_witness_comparison.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k!='historical_original_point_verification'},indent=2))
