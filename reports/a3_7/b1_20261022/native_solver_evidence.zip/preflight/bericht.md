# A3.7-B1 — Vorprüfung, Solverbefunde und geschützter Implementierungsstopp

22.10.2026. Rolle: A3.7-B1-IMPLEMENTER. **Gesamteinstufung: `blocked_environment_or_inputs`.**
Die Spezifikation ist `SPECIFICATION_READY`; das Ausführungsgate ist wegen fremder
unversionierter Dateien im aktiven Checkout gesperrt. Es wurde kein Produktionsfix
implementiert, keine Branch angelegt, kein Worktree erstellt und nichts gepusht.
Die nachstehenden frischen Befunde sind lokale Diagnostik und keine unabhängige
Abnahme einer neuen Korrektur.

## 1. Verbindlicher Schutzstopp

Aktiver Checkout: `D:/Projekte/Code/FlexPlan_UC_GSCR`.
Branch: `implementation/paper-a-ap2-regional-optimization-v1`.
HEAD: `725de2e6c1cea21f63902474f72ec614b2358356`.
`git status --porcelain=v1` meldet `?? audit/`; darunter liegen 28 fremde
unversionierte Dateien in `audit/c2a_reproducible_environment/`, einschließlich
Protokollen, Hashnachweisen und Umgebungsberichten. Index und getrackte Dateien
zeigen keine Änderungen. Unversionierte Inhalte gehören ausdrücklich zum Gate.

Abschnitt 5.2 des beauftragten v2-Makroauftrags bestimmt:
„Branchkollision oder verschmutzter Checkout ist eine geschützte Stop-Bedingung
für schreibende Änderungen, kein Grund für einen zweiten Worktree.“
Abschnitt 5.1 verbietet das Verschieben oder Überschreiben fremder Inhalte.
Daher erfolgten weder Branchwechsel noch Stash, Reset, Merge, Rebase oder eine
Integration in einen anderen vorhandenen Checkout. Die sieben vorhandenen
Worktreeeinträge wurden inventarisiert; keiner wurde angelegt oder verändert.
Alle neu geschriebenen Diagnoseprogramme und Ausgaben liegen ausschließlich
in diesem externen Diagnoseverzeichnis. Es enthält kein Git-Checkout.

Die notwendige nächste organisatorische Maßnahme ist ein durch den Eigentümer
sicher bereinigter aktiver Checkout oder eine ausdrückliche Ausnahme von dieser
konkreten Dirty-Checkout-Stopregel. Fremde Dateien dürfen nicht aufgrund dieses
Berichts gelöscht, verschoben oder still in eine Implementierungsbranch übernommen
werden. Es fehlt keine wissenschaftliche Spezifikationsentscheidung.

## 2. Frisch geprüfte Git-Autorität

Alle sieben technischen Referenzcommits des Auftrags sind lokal vorhanden.
Der Produktionsfix `910d44122a37d9ed2cca06940740b46706c73d40` ist Vorfahr von
`15ba10c193a562a48cb0e1dcc6fa12d922ac0613` (`merge-base --is-ancestor`, Exit 0).
`git diff --exit-code` für `src`, `scripts`, `test`, `Project.toml` und
`Manifest-v1.10.toml` zwischen diesen beiden Revisionen liefert Exit 0.
Der gesamte Dateidiff betrifft ausschließlich `reports/`.

Frische Remoteabfrage:

| Referenz | SHA |
|---|---|
| origin HEAD / master | `991d0e99627b9bd57b3df476c66141ae6bb5163d` |
| origin/fix/paper-a-a3-6-b1-opt-v1 | `1147873bf553667aec5cd7eb0e9c6f7e471b370c` |
| origin/codex/a3-6-independent-reaudit-20261021 | `15ba10c193a562a48cb0e1dcc6fa12d922ac0613` |

Die gewünschte neue Implementierungsbranch wurde bei der Remoteabfrage nicht
gefunden und war auch lokal nicht vorhanden. Ihre Anlage unterblieb wegen des
Dirty-Gates. Remote-master ersetzt keine der gepinnten Ausgangsrevisionen.
Der frühere Hinweis im lokalen Gedächtnis auf einen noch nicht unabhängig
akzeptierten A3.6-Fix wurde durch den gelesenen gepinnten Reaudit überholt;
maßgeblich ist dessen begrenzte unabhängige Akzeptanz.

## 3. Tatsächliche Solverfähigkeit

Die isolierte Testumgebung besteht ausschließlich aus den per `git show`
bytegetreu exportierten Project-/Manifestdateien von `15ba10c...`.
Es gab kein `Pkg.add`, `Pkg.update`, `Pkg.resolve`, keine Lizenzänderung und
keine Veränderung der Projektumgebung des Checkouts. Verwendet wurden die
bereits im Depot vorhandenen Pakete; `Pkg.instantiate` wurde hier nicht ausgeführt.
Die aktiv geladenen Versionen stehen in `runtime_inventory.json`.

Julia 1.10.11, JuMP 1.31.1, MOI 1.51.2, Pajarito 0.8.3,
HiGHS.jl 1.24.1 / native 1.15.1, Clarabel 0.11.1, Gurobi.jl 1.9.2.
Gurobi lädt tatsächlich `C:/gurobi1203/win64/bin/gurobi120.DLL`, Version 12.0.3.
MOSEK CLI: `C:/Program Files/Mosek/11.0/tools/platform/win64x86/bin/mosek.exe`,
Version 11.0.29. Ein Julia-Thread; Solveroptionen und native Threads stehen
in den einzelnen Logs. Laufzeiten enthalten teilweise Julia-Kompilation und
sind kein Performancebenchmark.

Identische kleine JuMP-Aufgabe: minimiere x, x ganzzahlig in [0,10], y=1,
und (x,y,3) im rotierten Kegel. Für MOSEK CLI wird die Konstante 3 durch z=3
dargestellt. Die Projektion auf (x,y) ist identisch. Exakt gilt
2*x*1 >= 9, also x >= 9/2 und ganzzahlig x >= 5. Der Punkt (5,1,3) erreicht
diese Schranke. Das ist ein analytisch prüfbarer Integer-RSOC-Test.

| Pfad | Frischer Befund | Geltungsbereich |
|---|---|---|
| Pajarito / HiGHS / Clarabel | OPTIMAL / FEASIBLE_POINT / NO_SOLUTION, Ziel 5 | `supported_only_in_restricted_scope`; kleine Integer-RSOC-Probe |
| Gurobi JuMP/MOI | OPTIMAL / FEASIBLE_POINT / NO_SOLUTION, Ziel 5 | `supported_only_in_restricted_scope`; zusätzlich Originaldiagnostik unten |
| HiGHS direkt | RSOC nicht unterstützt | `unavailable_with_reason` für direkte MISOCP-Nutzung; OA-MIP-Unterproblem bleibt nutzbar |
| Clarabel direkt | Integerrestriktion nicht unterstützt | `unavailable_with_reason` für direkte MISOCP-Nutzung; kontinuierlicher Koniksolver bleibt nutzbar |
| MosekTools JuMP/MOI | Paket nicht im aktiven Project/Depot vorhanden | `unavailable_with_reason`; kein JuMP/MOI-Solve möglich |
| MOSEK native CLI | PRIMAL_FEASIBLE / INTEGER_OPTIMAL, Ziel und Bound 5, Gap 0 | `supported_only_in_restricted_scope`; echte native Integer-RSOC-Probe |

Pajaritos kleine Probe hat lineares Residuum 1.11e-16, Integer- und RSOC-Residuum
0. Gurobis kleine Probe hat alle drei Residuen 0. Die native MOSEK-Lösung (5,1,3)
wurde separat mit rationaler Arithmetik exakt geprüft. Der aktuelle Gurobi-Log
meldet eine akademische Lizenz bis 22.10.2027; der frühere Fehler 10009 wurde
in diesen Aufrufen nicht reproduziert. MOSEK optimiert tatsächlich erfolgreich;
der historische Lizenzfehler 1001 ist kein aktueller Befund dieser CLI-Probe.
Die genaue Lizenzauflösung von MOSEK wurde nicht separat instrumentiert;
Lizenzdateiinhalte wurden nicht gelesen oder veröffentlicht.

Diese Ergebnisse belegen keine native G0-MISDP-Fähigkeit. Für MOSEK fehlt
insbesondere der verlangte JuMP/MOI-Nachweis und der Original-G3-Vergleich.

## 4. Originalvergleich: Pajarito stagniert, Gurobi-OPTIMAL reicht nicht

Das A3.6-Eingangsarchiv wurde direkt aus dem gepinnten Gitobjekt gelesen:
`verified_primal_dual_witnesses.zip`, SHA256
`ca15ee8a3cd73eefe9c75b00896ec4f4cdb71f12e23d6fc55a0916e35417482c`.
Der ausgewählte native Originalexport hat den verlangten SHA256
`fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07`.
Alle sechs gefundenen Archivkopien dieses Originalexports haben denselben Hash.
Die vollständige Archiventry-/historische Mehrarchivverifikation wurde nicht
wiederholt und wird als `not_verified` geführt.

Der Originalexport besitzt 3.680 Variablen, 1.353 Integerrestriktionen und
8.627 Constraints, darunter 144 RSOC-Constraints. Beide Solver lesen genau
dieselbe Datei. Es erfolgen kein Modellneuaufbau, kein Rebase, keine neue
Zielfunktionsskalierung, keine Integerfixierung und keine neu hinzugefügte
Witness-Initialisierung. Die in der Originaldatei gespeicherten
`primal_start`-Werte bleiben erhalten.
Pajaritos Factoryfunktion wurde unverändert aus der gepinnten AP3Pipeline
exportiert. Gurobis eigene Parameter sind im Ergebnis-JSON vollständig erfasst:
ein Thread, 120 s, MIPGap 1e-8, FeasibilityTol und IntFeasTol 1e-8, Seed 20261020.

| Pfad am Original-Defaultmodell | Termination / Primal / Dual | Zielanzeige | numerische Boundanzeige | Solve-Wallzeit |
|---|---|---:|---:|---:|
| gepinnte korrigierte Pajarito-Factory | ITERATION_LIMIT / NO_SOLUTION / NO_SOLUTION | 0.018693570771500315 | 0.018692887177101297 | 47,64 s |
| Gurobi-Diagnose | OPTIMAL / FEASIBLE_POINT / NO_SOLUTION | 0.0187025464149349 | 0.018702546414934892 | 2,81 s |

Die Pajarito-Ziel-/Boundwerte sind ausschließlich auslesbare Solvermetadaten.
Wegen `NO_SOLUTION` werden daraus weder Primalzeugnis noch gültige Bounds
abgeleitet. Der Log enthält wiederholt `integral solution repeated`; der
auslesbare relative Gap beträgt 3.6548871e-5 gegenüber Factory-Toleranz 1e-7.
Das belegt den stagnierenden Integerkandidatenpfad, aber noch nicht die volle
kausale Erklärung jedes betroffenen Cuts oder des Doppeldivisorfalls.

Eine separate Python-Implementierung wertet alle Originalconstraints mit exakt
binär-rational interpretierten Modellkoeffizienten und Lösungskomponenten aus.
Vor dem Solve war die diagnostische numerische Akzeptanzschwelle auf 1e-7
für die unveränderten linearen, Integer- und polynomialen RSOC-Residuen festgelegt.
Gurobis Punkt hat maximal 3.3595771e-10 Gleichungsresiduum, 2.9976022e-15
LessThan-Residuum und 0 Integer-/RSOC-Residuum. Er erfüllt diese numerische
Schwelle, ist wegen der nichtverschwindenden linearen Residuen jedoch kein
exakter rationaler Feasibility-Zeuge. Eine Integerperturbation um 1/2 wird vom
separaten Validator zurückgewiesen. Dies ist ein negativer Oracle-Test und
kein Test globaler Cut-Gültigkeit.

**Entscheidender zusätzlicher Gegenbefund:** Der archivierte vollständige
rationale Originalzeuge `exact_primals/reference_24snap_native_point.json`
wurde frisch gegen sämtliche 8.627 Constraints geprüft: alle Residuen exakt 0.
Sein Zielwert in exakt derselben serialisierten Originalkoordinate beträgt
angezeigt 0.01869304116753802. Gurobis gemeldete numerische Untergrenze liegt
um exakt den in `historical_witness_comparison.json` gespeicherten positiven
Bruch, angezeigt 9.505247396874162e-6, darüber. Ein gültiger globaler LB einer
Minimierung kann keinen zulässigen Punkt übersteigen. Dieser native Bound und
die damit verbundene numerische OPTIMAL-Meldung sind deshalb als rigorose
globale Aussagen widerlegt. Das ist kein Widerspruch zu den historischen neun
Intervallen, deren andere exakte Kostenkoordinate hier nicht umetikettiert wird.

Eine ungeprüfte direkte Umschaltung auf Gurobi wäre somit nicht vertretbar.
Die genaue numerische Ursache dieses Gurobi-Boundbefunds wurde noch nicht
lokalisiert. Es wurden keine Toleranzen gelockert, um ihn verschwinden zu lassen.

## 5. Solverentscheidung und Modell-/Feasible-Set-Erhaltung

Es wurde **keine Produktionsstrategie ausgewählt oder implementiert**.
Die neue Laufzeit eröffnet reale kommerzielle Kandidaten; zugleich zeigt der
Originalvergleich, warum ihre Auswahl mehr als einen OPTIMAL-Status verlangt.
Nach Beseitigung des Checkoutblockers sind eine kontrollierte, mathematisch
begründete Zielfunktions-/Solverkonfiguration für Gurobi und eine genehmigte
MOSEK-Julia-Anbindung mit Originalvergleich sachlich prüfbare Optionen.
Der unabhängig akzeptierte HiGHS-Fix wird nicht zurückgenommen.

Produktionsdiff dieses Workers: leer. Damit wurden die wissenschaftlichen
G0/G3-Gleichungen, B/p/S/M-Objekte, Kanten, Integerdomänen, Kostenfunktionen,
UC-/Dispatch-/Event-/Storagegleichungen und AP3-Ausgabeverträge nicht geändert.
Original-Inputhash und vollständige Originalresiduen sind separat belegt.
Ein neuer Beweis der globalen Äquivalenz eines Produktions-Bridge-/Cutpfads
wird ausdrücklich nicht behauptet; ein solcher Pfad wurde nicht implementiert.
Auch neue OA-Normalisierungen, Rundungsschranken oder Währungsbounds wurden
nicht erzeugt. Die neufestgelegte diagnostische Residuentoleranz ersetzt kein
wissenschaftliches Akzeptanzkriterium und ändert keine Solver-Feasibility-Toleranz.

## 6. Ausgeführt, nicht ausgeführt, Fehlversuche

Frisch ausgeführt: lokale/Remote-Gitprüfung, Codeidentitäts-/Ancestryprüfung,
fünf kleine JuMP/MOI-Capabilityversuche, eine native MOSEK-Integer-RSOC-Probe,
zwei native Original-Defaultmodellläufe, separate rationale Prüfung des neuen
Gurobi-Punkts und des historischen Originalzeugen, negativer Integer-Oracle-Test,
aktuelles Versions-/Bibliotheksinventar und abschließende Zustandserhaltung.

Nicht ausgeführt: neuer Produktionsfix, Doppeldivisorfall, neun registrierte
G3-Läufe, 45-Läufe-Stressmatrix, B1-A-Filter-/Cut-Mutationen, vollständiger
Original-/Bridged-/OA-/MIP-Koeffizientenvergleich, MOSEK-Original-G3-Lauf,
6087er Repositoryregression, 4108er gespeicherte AP3-Prüfung, 42er MOI-Schutzsuite,
16er Domänenmutationen, 171er Zertifikatsuite, kompletter Reviewerprüfpfad sowie
124-Metrik-/8-CLI-Abnahme. Historische Prüfzahlen werden hier nicht als frische
Ergebnisse ausgegeben. Die separate vollständige Prüfung eines historischen
Originalzeugen ist ein begrenzter neuer Befund, kein Ersatz dieser Suiten.

Die erste Version des kleinen Julia-Diagnoseskripts enthielt die mehrdeutige
Schreibweise `9.-2*xv*yv` und endete für alle fünf Aufrufe mit ParseError/Exit 1,
bevor ein Solver aufgerufen wurde. Originalskript und alle fünf Rohlogs bleiben
erhalten (`probe_parse_failed.jl`, `probe_*.stderr.log`). Die korrigierte Fassung
verwendet `9.0 - 2*xv*yv`; ihre Aufrufe und Rohlogs tragen `retry_`.
Exit 0 des Diagnoseprogramms bedeutet auch bei abgefangenen Unsupported-/Import-
Fehlern keinen Solver-PASS; maßgeblich ist jeweils das Ergebnis-JSON.
Ein früher Textvorschauversuch auf der einzeiligen Original-MOF erzeugte eine
zu große, gekürzte Konsolenausgabe; die Datei blieb unverändert und wurde
anschließend strukturiert ausgewertet.

## 7. Reproduktion, Provenienz und Fortsetzung

Die tatsächlich verwendeten Argumentarrays, Zeitstempel und Exitcodes stehen
in `commands.json`, `commands_retry.json`, `commands_original.json` und
`mosek_native_command.json`. Skripte, Rohlogs, aktive Optionen, Originalinput,
ausgegebener Gurobi-Punkt, historischer rationaler Originalpunkt und alle
separaten Prüfergebnisse liegen in diesem Verzeichnis. `sha256_manifest.json`
bindet die Dateien; `preservation_final.json` vergleicht HEAD, Branch, sämtliche
lokalen Referenzen, Worktreeinventar, Indexhash, getrackten Diff, Project/Manifest
und jeden der 28 fremden unversionierten Dateihashes mit dem Ausgangszustand.

Für einen gezielten Oracle-Replay ohne Solver:

```powershell
$pyExe = 'C:/Users/User/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
$runRoot = 'D:/Downloads/A3_7_B1_preflight_20261022_203803'
& $pyExe "$runRoot/compare_historical_witness.py"
```

Solverskripte können mit den gespeicherten Argumentarrays in einer neuen
externen Kopie des Diagnoseverzeichnisses ausgeführt werden. Bereits gespeicherte
Logs und Eingänge nicht überschreiben. `run_preflight.py` ist das historische
Ausführungsskript und wegen seiner absichtlich verweigerten Wiederanlage des
Umgebungsordners kein In-place-Wiederholungskommando.

Es gibt keinen neuen Commit und keinen Remote-Final-SHA dieses Workers.
Der verbindliche neue Implementierungsparent bleibt `15ba10c...`.
Der eigenständige Fortsetzungs-/Reaudit-Handoff steht in `handoff.md`;
Gatezustände stehen in `release_gates.yaml`.

## 8. Getrennte Gates

Der akzeptierte lokale A3.6-Filterfix und die neun historisch unabhängig
akzeptierten normalisierten rationalen Intervalle bleiben im bisherigen
Geltungsbereich bestehen. Die gesamte Intervallprüfung wurde hier nicht erneut
ausgeführt. Kein neuer Produktionskandidat liegt zur unabhängigen Abnahme vor.
`B1_repaired=false`, `native_G3_MISOCP=numerical_inconclusive`,
`m2_technical_candidate_for_reaudit=false`, `integer_optimality_proved=false`,
`integer_globality=case_specific_partial`, `science_amendment_approved=false`,
`independent_A3_5_accepted=false`, `A3_closed=false`, `AP4_ready=false` und
`empirical_study_ready=false`. M3, M4 und Owner-Ratifizierung bleiben getrennt.
