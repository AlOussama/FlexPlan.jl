using JuMP, JSON, LinearAlgebra, Libdl
import HiGHS, Clarabel, Pajarito, Gurobi
const MOI=JuMP.MOI
r=Dict("julia"=>string(VERSION),"julia_threads"=>Threads.nthreads(),
    "blas_threads"=>BLAS.get_num_threads(),"active_project"=>Base.active_project(),
    "packages"=>Dict(string(n)=>string(Base.pkgversion(m)) for (n,m) in
        ((:JuMP,JuMP),(:MathOptInterface,MOI),(:HiGHS,HiGHS),(:Clarabel,Clarabel),(:Pajarito,Pajarito),(:Gurobi,Gurobi))),
    "highs_native_version"=>MOI.get(HiGHS.Optimizer(),MOI.SolverVersion()),
    "gurobi_library_binding"=>Gurobi.libgurobi,
    "native_libraries"=>[p for p in Libdl.dllist() if occursin(r"(?i)gurobi|highs",p)],
    "mosek_julia_packages_in_active_depot"=>Dict(n=>[isdir(joinpath(p,"packages",n)) for p in DEPOT_PATH] for n in ("Mosek","MosekTools")))
open(io->JSON.print(io,r,2),joinpath(@__DIR__,"runtime_inventory.json"),"w")
