using JuMP, JSON, SHA, Libdl
import Gurobi, HiGHS, Clarabel, Pajarito
const MOI=JuMP.MOI
include(joinpath(@__DIR__,"factory_pinned.jl"))
solver=ARGS[1]
input=joinpath(@__DIR__,"original_G3.mof.json")
@assert bytes2hex(sha256(read(input)))=="fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07"
m=read_from_file(input)
r=Dict{String,Any}("solver"=>solver,"input_sha256"=>bytes2hex(sha256(read(input))),
    "scope"=>"read_only_original_default_24snap_diagnostic; no_production_integration",
    "original_residual_check_tolerance"=>1e-7,
    "variables"=>num_variables(m),"integer"=>count(is_integer,all_variables(m)))
safe(f)=try f() catch; nothing end
try
    if solver=="Gurobi"
        set_optimizer(m,Gurobi.Optimizer)
        for (k,v) in (("Threads",1),("TimeLimit",120.),("MIPGap",1e-8),
            ("FeasibilityTol",1e-8),("IntFeasTol",1e-8),("Seed",20261020))
            set_optimizer_attribute(m,k,v)
        end
        r["options"]=Dict("Threads"=>1,"TimeLimit"=>120.,"MIPGap"=>1e-8,
            "FeasibilityTol"=>1e-8,"IntFeasTol"=>1e-8,"Seed"=>20261020)
    else
        set_optimizer(m,pajarito_optimizer())
    end
    r["solve_wall_s"]=@elapsed optimize!(m)
    r["termination"]=string(termination_status(m))
    r["primal_status"]=string(primal_status(m))
    r["dual_status"]=string(dual_status(m))
    r["objective_numerical"]=safe(()->objective_value(m))
    r["bound_numerical_only"]=safe(()->objective_bound(m))
    r["relative_gap_numerical_only"]=safe(()->relative_gap(m))
    r["nodes"]=safe(()->node_count(m))
    r["simplex_iterations"]=safe(()->simplex_iterations(m))
    r["barrier_iterations"]=safe(()->barrier_iterations(m))
    if has_values(m)
        point=Dict(name(v)=>value(v) for v in all_variables(m))
        open(io->JSON.print(io,point),joinpath(@__DIR__,"original_"*solver*"_point.json"),"w")
    end
catch e
    r["error"]=sprint(showerror,e,catch_backtrace())
end
r["loaded_native_libraries"]=[p for p in Libdl.dllist() if occursin(r"(?i)gurobi|highs",p)]
open(io->JSON.print(io,r,2),joinpath(@__DIR__,"original_"*solver*".json"),"w")
