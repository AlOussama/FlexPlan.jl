# Paper A — M2 / A3.7-B1
## Autonomer Makroauftrag: Native G3-MISOCP Solver Robustness Closure

**Rolle:** `A3.7-B1-IMPLEMENTER` — eigenständig arbeitender lokaler Codex-Worker mit Expertise in gemischt-ganzzahliger konischer Optimierung, Outer Approximation (OA), Julia/JuMP/MathOptInterface, Pajarito, HiGHS, Clarabel, numerischer linearer Algebra sowie rigoroser Zertifikatsprüfung.

**Auftraggeber-Ziel:** Schließe die noch offene native G3-MISOCP-Solverzuverlässigkeit für Paper A so weit wie nachweisbar. Entwickle und implementiere **eine kohärente, wissenschaftlich gerechtfertigte Lösung** des verbleibenden numerischen B1-Problems, teste sie end-to-end und publiziere einen revisionssicheren Implementierungs- und Reaudit-Handoff. Stelle keine Mikroschritt-Rückfragen. Das ist **kein** Auftrag zur globalen Integeroptimalitätszertifizierung (M3), Datenqualifikation (M4) oder Wissenschaftsowner-Ratifizierung.

**Arbeitsmodus:** genau **ein vorhandener lokaler FlexPlan-Checkout**, **keine neuen Git-Worktrees**, eine neue kontrollierte M2-Branch, zusammenhängender autonomer Arbeitsdurchlauf. Scratch-/Laufverzeichnisse außerhalb des Checkouts sind zulässig, zusätzliche Git-Checkouts/Worktrees ohne Notwendigkeit nicht. Vorhandene historische Dateien und fremde Branches unverändert lassen.

**Datum des Makroauftrags:** 2026-10-22. Das Datum identifiziert nur diese Arbeitsanweisung, nicht neue wissenschaftliche Autorität.

---

## 1. Normative und technische Referenzen — unveränderlich pinnen

### FlexPlan.jl — primäre technische Referenzen

Repository: https://github.com/AlOussama/FlexPlan.jl

| Objekt | Commit / Version | Rolle |
|---|---|---|
| Original-AP3 | `485b637cc1998a327206c5929434bd26c6f0be16` | unveränderte Negativ-Baseline |
| A3.5-EXEC | `4d9f346c5fca80e00fd01d96c39a2bac91776ac0` | historische ausführbare Evidenz |
| Metadatenfix | `e1e075626b38b478faf57efe62e557fc94753f00` | kein Ersatz für einen Solverfix |
| A3.6-Makroautorität | `e49b64216f82eefda77d6997ed68ed2d12c8ae78` | Vorgängerauftrag |
| **A3.6-Produktionsfix** | **`910d44122a37d9ed2cca06940740b46706c73d40`** | unabhängig begrenzt akzeptierte HiGHS-Option |
| A3.6-Full-Evidence | `1147873bf553667aec5cd7eb0e9c6f7e471b370c` | unveränderliche Inputevidenz und neun rationale Kostenintervalle |
| **A3.6-Independent-REAUDIT** | **`15ba10c193a562a48cb0e1dcc6fa12d922ac0613`** | **verbindliche M2-Ausgangsrevision**; `partially_closed` |

Der Vergleich `910d441...` → `15ba10c...` zeigt ausschließlich Änderungen unter `reports/`, keine Deltas in `src/`, `scripts/`, `test/`, `Project.toml` oder Manifest. **Trotzdem vor der Bearbeitung die Remote-SHAs, Ancestry, tatsächlichen Dateidiffs und Git-Status erneut prüfen.** Ein später veränderter Branch-HEAD ersetzt keine der gepinnten Revisionen.

### Wissenschaft und Daten — ausdrücklich separate Gates

- Mathematischer C2A-Freeze: `AlOussama/research-map@2c2fce769b2ed6ffd4f1ced60c0798776acccc93`.
- Autoritative Dissertationsbasis: `AlOussama/research-map@e8118425adc335a99e85120d943763305f211315`.
- Paper-A-Scope: `672a61c95525bf1d7a03cf745a754a15a23ce78b`.
- Vorgeschlagenes, **nicht ratifiziertes** wissenschaftliches Amendment: Git-Blob `fba4802ecabade61a752833a71106a5bda4ce78f`.
- Producer-Numerik: `AlOussama/PyPSA2MatpowerX@3b8fdb01d931225edc5f8fe1e2c200d0da288a09`; Parameter-Consumer `FlexPlan.jl@e992edc88d39fa0eb2d72e2490e157441223f568`.

Die mathematischen Sollgleichungen kommen aus dem eingefrorenen wissenschaftlichen Modell, nicht aus einer beliebigen aktuellen Solverimplementierung. Forschungs-/Producer-Repositories sind für M2 **read-only**. Kein Owner-Beschluss wird simuliert.

### Verbindlich zuerst lesen, nicht nur zitieren

1. `reports/a3_6/reaudit_20261021/independent_reaudit_report.md` und `release_gates.yaml` @ `15ba10c...`.
2. Ebendort `remaining_gates_handoff.md`, `b1_stage_evidence.json`, `b1_solver_reliability_matrix.csv`, `reproduce.md`, `reproduction_manifest.json`, `independent_certificate_results.json`, `fresh_export_comparison.json`, `attempts.md`.
3. `reports/a3_6/b1_opt_20261020/independent_b1_opt_closure_report.md`, `pre_fix_original_verdict.md`, `b1_root_cause_or_limitation.md`, `b1_original_vs_bridged_vs_oa_stage_evidence.json`, `objective_rebase_derivation.md`, `integer_9cases_bounds.json` und die archivierten originalen MOI-Modelle/Witnesses @ `1147873...`.
4. `scripts/paper_a/AP3Pipeline.jl` @ Original, @ Fix und @ Reaudit; dazu die tatsächlichen relevanten JuMP/MOI/Pajarito/HiGHS-/Conic-Integrations- und Testpfade. Prüfe Versionen und vorhandene Solverfähigkeiten tatsächlich.
5. Nur für die mathematischen Invarianten die eingefrorenen wissenschaftlichen G0/G3-Sätze und den Multi-Repository-Ausführungsplan (research-map `publication_planning/2026-10-15__paper-a-multirepo-execution-freeze-v2.md` @ `e811842...`).

Historische Prüfzahlen und Archivmanifeste sind **Vorleistungen**, keine neuen Tests. Nicht zugängliche ZIP-Rohdaten, Tool-/Lizenzgrenzen und unvollständige Hashverifikation jeweils als solche kennzeichnen.

---

## 2. Ausgangsdefekt und exakt abzugrenzendes Ziel

**Bereits unabhängig akzeptiert:** Im früheren OA-MIP entstanden Koeffizienten von etwa `4.5830185e-11`, `4.5830185e-11`, `1.3046248e-10` bei positiver RHS `3.025002202302713e-8`. HiGHS entfernte die Terme mit Defaultfilter `1e-9`, sodass eine erfüllbare Ungleichung zu `0 >= positive RHS` wurde. `small_matrix_value=1e-12` im Commit `910d441...` behebt genau diesen **lokalen** Defekt. **Diesen Fix nicht wieder als unbewiesen behandeln oder ohne Regressionsgrund austauschen.**

**Unverändert offen:**

- Die **korrigierte native Pajarito/HiGHS/Clarabel-Factory** endet beim ursprünglichen serialisierten `reference_24snap`-G3-Modell im Defaultkostenpfad weiterhin mit `ITERATION_LIMIT/NO_SOLUTION`.
- Die unabhängig wiederholte **45-Läufe-Stressmatrix** enthält `44 × OPTIMAL`, `1 × ITERATION_LIMIT`; der Ausreißer ist `reference_24snap/G3/double_costscale`.
- Die endliche HiGHS-Filterschwelle `1e-12` entfernt konstruktionsgemäß auch kleinere Koeffizienten. Der rational zulässige Gegenfall mit Koeffizient `1.2740476362167553e-13` wurde dokumentiert; er darf nicht als neuer Defekt einer registrierten Instanz ausgegeben werden.
- Globale Validität beliebiger floating-point-OA-Cuts, robuste Interpretation von MIP-Solverbounds sowie vollständige Node-/Dualbeweise sind nicht allgemein zertifiziert.

**M2-Ziel:** Ein qualifizierter Solverpfad für die deklarierten Paper-A-G3-MISOCP-Modelle, der die genannten Restprobleme soweit technisch möglich beseitigt und nachweisbar **keine neuen falschen `INFEASIBLE`-, `OPTIMAL`- oder Kosten-/Boundbehauptungen** erzeugt. Arbeite mit klarer endlicher Testdomäne; verspreche keine universelle Robustheit beliebiger Float64-MISOCP-Instanzen.

**Nicht M2:** Globale Integeroptimalität der neun Studienfälle beweisen, künstlich neue Kostengrenzen erzeugen oder die physikalische Quellen-/Jahresrepräsentativität freigeben. Diese Aufgaben gehören M3/M4 bzw. den jeweiligen Ownern.

---

## 3. Unveränderliche mathematische Invarianten und Proof Obligations

Im deklarierten symmetrischen Z-Matrixbereich ist für jeden Snapshot

\[
M_t=B_t-\alpha S_t,\quad S_t=\operatorname{diag}(p_t),\quad
B_t=B^0+\operatorname{diag}(b_t^{\mathrm{fix}}+b_t^{\mathrm{src}}).
\]

Die G3-Kantenformulierung lautet für jede **genau einmal** gezählte ungerichtete Nichtnullkante \(\{i,j\}\):

\[
q_{ij,t}\ge0,\quad q_{ji,t}\ge0,\quad
(q_{ij,t},q_{ji,t},\sqrt2\,M_{ij,t})\in\mathcal Q_r^3,
\quad M_{ii,t}-\sum_{j\ne i}q_{ij,t}\ge0.
\]

Dabei ist \(\mathcal Q_r^3=\{(u,v,w):u,v\ge0,\ 2uv\ge w^2\}\). Unter den eingefrorenen Matrixklassenbedingungen gilt theoretisch \(G0\Longleftrightarrow G3\); diese Domäne **nicht** still erweitern.

Nach der Bearbeitung gelten als nicht verhandelbare Anforderungen:

- **Exakte Modellsemantik:** gleiche Entscheidungsvariablen/Integerdomänen, gleiche B-/p-/S-/M-Objekte, gleiche G3-Kanten und RSOC-Constraints, gleicher BASE-/G0-/G3-Vergleich, gleiches Investment-/Dispatch-/Event-/Storagemodell und dieselbe physische Zielfunktion. Keine heimliche Relaxation, zusätzliche Restriktion oder unbemerkte Fallauslassung.
- **Cuts müssen global gültig bleiben:** Für einen Kegelschnitt aus einem Dualvektor \(y\in\mathcal K^*\) muss die zugehörige affine Ungleichung die originale Kegelmenge einschließen. Eine positive Skalierung \(s>0\) ist über exakter Arithmetik äquivalent; **sämtliche** Koeffizienten, Konstanten und RHS sind konsistent zu skalieren, mit korrekter Ungleichungsrichtung. Approximate duals, numerische Fehler, Rundungen und Nullkoeffizienten brauchen eigene Validierung/Fehlerklassifikation; `looks_feasible` ist kein Beweis.
- **Numerische Sicherheit:** weder endliche Cut-Terme durch Filterung ohne Nachweis verlieren noch durch unangemessen große Skalierungsfaktoren Overflow, neue Boundfehler oder schlecht konditionierte Zeilen erzeugen. Dokumentiere Zeilennorm-/Koefﬁzientenbereiche, kleinste erhaltene Terme, Solvergrenzen und den tatsächlich an HiGHS übergebenen Modellinhalt.
- **Verlässliche Statussemantik:** `INFEASIBLE`, `OPTIMAL`, `ITERATION_LIMIT`, `TIME_LIMIT`, `NO_SOLUTION` und `numerical_inconclusive` getrennt führen. Keine Feasibility-Toleranz lockern, um einen gewünschten Status zu erzwingen. Kein Problem allein deshalb als mathematisch infeasible einstufen, weil ein floating Solver so terminiert.
- **Zielfunktionsintegrität:** dokumentierte Objective-Inkrement-/Offset-/Skalierungskonvention erhalten. Wenn Solverziel-Transformationen verändert werden, die beiden tatsächlichen Float64-Kostenkoordinaten einschließlich \(\delta(x)\) erneut nachrechnen. Keinen nativen numerischen Bound ohne rigorose Transformations- und Rundungsabschätzung als exakten Währungsbound ausgeben.
- **Bestehende mathematische Zertifikate:** Die neun in A3.6 akzeptierten rationalen Kostenintervalle nur in ihrer ursprünglichen **normalisierten binär-rationalen** Domäne zitieren; bei veränderten Modell-/Objective-Koeffizienten sind sie nicht automatisch übertragbar. Bestehende exakte Daten und historische negative Gaps nicht überschreiben.

**Hinweis:** Für HiGHS ist `small_matrix_value=1e-12` bereits die dokumentierte untere Optionsgrenze. Ein Vorschlag, lediglich `small_matrix_value` weiter zu senken, ist daher keine belastbare Hauptlösung.

---

## 4. Technische Lösungsfreiheit — selbst entscheiden, nicht um Mikroschritte fragen

Die folgenden Wege sind **Optionen, keine obligatorischen Teilaufträge und keine vorgeschriebene Reihenfolge**. Analysiere den tatsächlichen Fehlerpfad, bewerte die Optionen nach Korrektheit, Einfachheit, Robustheit und Wartbarkeit und wähle **einen zusammenhängenden tragfähigen Ansatz**:

**A. Mathematisch äquivalente Cut-/Zeilennormalisierung** am passenden JuMP/MOI-/OA-Übergabepunkt, sodass relevante Koeffizienten im Zielsolver nicht unbemerkt verschwinden. Möglich sind begründete positive Skalierungsregeln, zweierpotenznahe Faktoren, explizit geprüfte Cut-Normale und numerisch abgesicherte Cut-Emission.

**B. Skalierung/Präkonditionierung zulässiger Kegel-/Variablenkoordinaten**, sofern die Rückabbildung, Integrality, Bounds, Kosten und RSOC-Konvention exakt nachvollziehbar bleiben. Nicht mit einer Änderung des physikalischen G3-Modells verwechseln.

**C. Bewusste Algorithmus-/Factory-Konfiguration** von Pajarito/HiGHS/Conic-Subsolver, soweit sie die ursprüngliche MISOCP-Menge erhält und den tatsächlichen `ITERATION_LIMIT`-Mechanismus nachvollziehbar verbessert. Eine bloße willkürliche Erhöhung aller Limits oder Absenkung von Qualitätsanforderungen genügt nicht; ein begründeter Ressourcenparameter darf ergänzend getestet werden.

**D. Gurobi-/MOSEK- und andere tatsächlich verfügbare MISOCP-Solverrouten (explizit qualifizieren).** Gurobi und MOSEK sind nach Angabe des Auftraggebers lokal installiert und **als reale Kandidaten zu untersuchen**, nicht nur abstrakt zu erwähnen. Das ist keine Bestätigung einer zur Laufzeit gültigen Lizenz. Historische Gurobi-Fehler 10009 und MOSEK-Fehler 1001/Lizenzablauf wurden auf einer älteren Laufzeit dokumentiert; prüfe den aktuellen Zustand und den tatsächlich verwendeten Lizenz-/Backendpfad mit einem echten JuMP/MOI-Integer-RSOC-Probesolve. Führe für jeden erreichbaren Kandidaten einen nachvollziehbaren Capability- und Versionscheck durch (installiertes Paket, native Bibliotheksversion, Lizenzstatus ohne Geheimnisse auszugeben, MOI-Bridges, verwendete Konustypen, Integerfähigkeit, tatsächliche Termination-/Primal-/Dualstatus). Eine Paketinstallation, successful `using`, ein Lizenzdateipfad oder ein reiner Continuous-SOCP-PASS genügt nicht. G3 ist **MISOCP**; daraus darf **keine** native G0-MISDP-Fähigkeit gefolgert werden. Eine nicht verwendbare Lizenz begrenzt nur diesen Solverpfad und ist **kein** globaler Schutzstopp für andere verfügbare Solver oder read-only-Analysen. Keine Lizenzumgehung, Lizenzänderung oder Paketaktualisierung ohne expliziten Bedarf und Zustimmung.

**Auswahlpräferenz:** Wenn mindestens einer der bereits installierten Solver das originalgetreue G3-MISOCP inklusive `reference_24snap` und kritischer Skalierung zuverlässig löst, prüfe zuerst, ob seine Integration mit minimalem, gepflegtem Factory-/Solverdispatch vertretbar ist. Vergleiche ihn gegen den eingefrorenen Pajarito/HiGHS/Clarabel-Pfad auf **identischen Originalmodellen**, nicht auf eigenmächtig umgeformten Fällen. Wenn die kommerziellen Solver nicht verfügbar sind, nicht reproduzierbar funktionieren oder nur einen Teil der erforderlichen Modellklasse unterstützen, dokumentiere das und gehe eigenständig zu Cut-/OA-/Scaling-Maßnahmen über. Der Worker ist nicht verpflichtet, Gurobi oder MOSEK als Produktionsbackend zu wählen; die Entscheidung folgt mathematischer Korrektheit, Reproduzierbarkeit, Wartbarkeit und den tatsächlichen Laufzeitbelegen.

**E. Kombination der Wege**, nur wenn die einzelnen Änderungen einen gemeinsamen, prüfbaren numerischen Mechanismus adressieren. Bevorzuge kleine, klar abgrenzbare Änderungen. **Keine breit angelegte Neuimplementierung** von G0/G3, UC, Datenvertrag, Kostenfunktionen oder Pajarito als Projektfork, wenn eine kontrollierte lokale Integration genügt.

**Entscheidungsgate für Solveralternativen:** Prüfe zunächst ohne Änderung von Produktionscode die verfügbaren Solver-Capabilities für Gurobi und MOSEK sowie den bestehenden Pajarito-Pfad. Auf einem identisch erzeugten kleinen Integer-RSOC-Modell und, bei erfolgreich verfügbarem Backend, auf der originalen problematischen G3-Instanz sind Primalstatus, Integer-/Linear-/RSOC-Residual, Objective, MIP-Gap, Bound-Semantik und Laufzeit getrennt zu vergleichen. Kein bloßer `OPTIMAL`-Status ist ein exakter Integer- oder globaler Cutbeweis. Ist ein Solver nicht lauffähig, protokolliere den Fehler und gehe zu den übrigen Ansätzen über, ohne Nutzer-Mikrorückfrage und ohne auf Lizenzbeschaffung zu warten.

Erstelle intern eine kurze technische Entscheidung mit Alternativen und Gründen. Führe anschließend selbstständig den ausgewählten Weg aus, einschließlich der für eine stabile Lösung nötigen Diagnosen und zielgerichteten Korrekturen. **Kein ständiges Wechseln zwischen Nutzer-Rückfragen, Mikrotasks oder separaten Teilprompts.** Interne mathematische/numerische Untersuchungen bleiben selbstverständlich zulässig; „keine Iterationen“ bedeutet hier **keine endlosen organisatorischen Korrekturzyklen**, nicht das Verbot eines iterativen Optimierungsalgorithmus.

Bei objektiv ungeeigneten/fehlenden Tools oder einem fundamental begrenzten Solver darfst du einen robusten **fail-closed**-Mechanismus liefern, der `numerical_inconclusive` statt falscher Freigabe erzeugt. Das ist ein wertvolles Teilresultat, **kein** vollständiger B1-Abschluss.

---

## 5. Ein-Checkout-/Branch-Governance

1. Identifiziere den **bereits vorhandenen** lokalen FlexPlan-Checkout und dessen `HEAD`, Branch, Index, uncommitted/untracked Inhalte, vorhandene Git-Worktrees sowie das Remote. Erzeuge **keinen** zusätzlichen Worktree; führe keinen Reset, Rebase, Stash, Force-Push, Merge, PR, Cherry-Pick oder Branch-Delete aus. Uncommitted fremde Inhalte nicht verschieben oder überschreiben.
2. Prüfe die Existenz der Ausgangsrevision `15ba10c...`, den Remote-HEAD und den Codeidentitätsvergleich zum Fix `910d441...`. Wenn der aktive Checkout sauber und sicher umschaltbar ist, erzeuge **genau eine neue Implementierungsbranch** aus `15ba10c...`, vorzugsweise `fix/paper-a-a3-7-b1-native-solver-v1`. Ein gleichnamiger vorhandener Remote-/Lokalbranch darf nicht blind überschrieben werden. Branchkollision oder verschmutzter Checkout ist eine geschützte Stop-Bedingung für schreibende Änderungen, kein Grund für einen zweiten Worktree.
3. Nutze eindeutige neue Laufordner **außerhalb** historischer Ergebnisbäume; kein Überschreiben der A3.5-/A3.6-ZIPs, Originalmodelle, Manifeste oder `reports/ap3_runs/20261020_macro/`.
4. Arbeitsänderungen auf Produktions-/Test-/Reproduktions-/Dokumentationsumfang begrenzen; nicht mehrere neue Featurebranches erzeugen. Committe/pushe ausschließlich deine eigene M2-Branch. Nach Publikation Remote-SHA, Parent/Ancestry, Diff, Dateihashes und bewahrte Baselines prüfen. **Keine automatische Integration in `master`.**

Wenn der Checkout nicht sicher geändert werden kann, führe zulässige read-only-Prüfungen durch und gib einen genauen Blockerbericht ab; täusche keine fertige Implementierung vor.

---

## 6. Evidence- und Testcontract — ein integrierter Prüfblock statt Mikrotasks

Wähle interne Testmethoden frei, aber dokumentiere **vor** substanzieller Produktionskorrektur den unveränderten Baselinebefund und halte mindestens folgende fachlichen Gruppen auseinander:

**B1-A: Minimale Kausalität und Filterrestgrenze.** Reproduziere die bekannte Ein-Zeilen-Falsch-Infeasibilität mit Defaultfilter sowie den A3.6-Fix. Prüfe den neu dokumentierten `<1e-12`-Fall als adversariale Grenze. Für deinen neuen Ansatz muss klar nachweisbar sein, ob er kleine gültige Cuts korrekt erhält, sicher normalisiert oder andernfalls bewusst und überprüfbar `numerical_inconclusive` liefert. Prüfe mindestens eine negative Veränderung (falsches Vorzeichen, inkonsistente RHS oder fehlender Term), sodass dein Validator nicht bloß immer PASS meldet.

**B1-B: Original-/OA-/Kegelmodellidentität.** Vergleiche die ursprünglichen serialisierten MOI-Modelle (für `reference_24snap` Originalhash `fcd52695238591d6c6019385d64e4407e1ea480849ca4125e1191b992581ab07`) gegen den neu aufgebauten Solverinput, den gebridgten Kegelteil, erzeugte OA-Schnitte und tatsächlich übergebene MIP-Koeffizienten. Bestehende rationale G0-/G3-Primalzeugen nur als geprüfte Inputs verwenden und zusätzlich unabhängige Residuums-/Kegelprüfungen aus dem **originalen** Modell durchführen. Unterschiede im Solverbackend dürfen die zulässige Menge nicht still ändern.

**B1-C: Native Problemfälle und Stressmatrix.** Wiederhole das korrigierte Original-24-Snapshot-Defaultmodell und die `reference_24snap/G3/double_costscale`-Variante unter der gewählten Lösung. Prüfe die **neun** registrierten G3-Fälle und die bestehende **45-Läufe-Matrix** (Primär-, Halb-, Doppeldivisor, engere Feasibility, G0-Vergleiche) oder eine streng begründete äquivalente Matrix mit separat markierten Abweichungen. Baseline: `44 × OPTIMAL`, `1 × ITERATION_LIMIT`. Erforderlich ist ein nachvollziehbarer Nachhervergleich mit allen Termination-/Primal-/Dualstatus, Kegel-/Linear-/Integerresiduen, Objective, Lauf-/Iterations-/Node-Metadaten und tatsächlich geprüften Bound-Aussagen. Ein vermeintlicher `OPTIMAL`-Status mit verletztem Originalmodell zählt nicht als Erfolg.

**B1-D: Solver-Capability und Schnittgültigkeit.** Prüfe Gurobi/MOSEK explizit durch echte Integer-RSOC-Probesolves und—falls verfügbar—durch reproduzierte native Original-G3-Läufe auf demselben Modell; halte Gründe für Nichtverfügbarkeit fest, ohne solche Solvers als gescheitert oder ungenutzt zu übergehen. Reproduziere die aktiven Solveroptionen und Versionen (Referenz: Julia 1.10.11; JuMP 1.31.1; MOI 1.51.2; Pajarito 0.8.3; HiGHS.jl 1.24.1 / Library 1.15.1; Clarabel 0.11.1) ohne blindes `Pkg.update`. Prüfe relevante Zeilenskalierungen, Filter-/Large-Coefficient-Grenzen, Kegel-Dualmitgliedschaft und Cut-Gültigkeit bei zulässigen und gezielt gestörten Punkten. Belege die Original-MIP-Inferenz nur in der tatsächlich geprüften Solver-/Numerikdomäne; ein vollständiger Integer-Baumbeweis ist **M3**.

**B1-E: Regressionen und konservierte Zertifikate.** Führe auf der finalen Produktionsrevision die vollen Repositorytests (historisch `6087/6087`), gespeicherte AP3-Evidenztests (`4108/4108`), JuMP/MOI-Schutzsuite (`42/42`) und Raw-Domänenmutationen (`16/16`) neu aus, sofern lauffähige Eingänge vorhanden sind. Ergänze gezielte neue Cut-/Skalierungs-/Factory-Tests. Wiederhole die bestehende exakte Zertifikatsprüfung (`171/171`) und den separaten A3.6-Reviewerprüfpfad oder belege unveränderte und neu überprüfte SHA-gebundene Zertifikatseingänge. Die akzeptierten neun Integerintervalle und beide tatsächlichen Objective-Koordinaten dürfen nicht widersprochen oder als stärkere globale Optimalitätsbeweise umetikettiert werden. Relevante 124-Metrik-/8-CLI-Verträge erhalten; bei Änderung dieser Codebereiche vollständig neu prüfen.

**Prüfmethodik:** Gefährdete mathematische Identitäten möglichst durch separate rationale/BigFloat/analytische Oracles prüfen, nicht nur mit demselben Solver, dessen Verhalten korrigiert wird. Prozess-Exit 0, `MOI.OPTIMAL` oder ein historischer Testreport reichen für sich allein nicht. Vollständige Rohlogs und negative Versuche erhalten. Unvollständige Archivverifikation als `not_verified` führen.

---

## 7. Eindeutige M2-Akzeptanzkriterien und Grenzen

Eine vorgeschlagene Lösung ist **technisch abnahmereif**, wenn **alle** folgenden Punkte nachvollziehbar erfüllt sind:

- Der Vorher-/Nachher-Vergleich beweist die fachliche Modellgleichheit und die sichere Behandlung numerisch winziger OA-Koeffizienten im tatsächlich benutzten Solverpfad.
- Ursprüngliches `reference_24snap` und Doppeldivisor-Stressfall besitzen einen **gültigen, reproduzierbaren** Solverabschluss innerhalb einer expliziten Ressourcen-/Toleranzkonfiguration; die erfolgreichen bisherigen registrierten Fälle regressieren nicht. Bloßes Ignorieren des `ITERATION_LIMIT` oder erzwungene günstigere Statusmeldungen zählt nicht.
- Für ausgegebene G3-Integerlösungen sind die Original-Linear-/Integer-/RSOC-Constraints unabhängig innerhalb vorab offengelegter numerischer Toleranzen geprüft; exakte Zeugenaussagen werden nur gemacht, wenn eine rationale Prüfung vorliegt.
- Der neue Cut-/Transformationspfad ist mit mathematischem Gültigkeitsargument **und** adversarialen Tests dokumentiert. Restbereiche unter endlichen Filterschwellen oder Solverfähigkeitsgrenzen sind abgefangen beziehungsweise transparent als Restblocker klassifiziert.
- Die vollständige Regression und die betroffenen historischen A3.6-Zertifikate bleiben nachweisbar gültig und die Kosten-/Provenienzidentität gewahrt.
- Gurobi und MOSEK sind für die vorhandene Laufzeit mit einem echten MISOCP-Probesolve als `available_and_verified`, `unavailable_with_reason` oder `supported_only_in_restricted_scope` klassifiziert. Wenn verwendbar, ist mindestens ein Original-G3-Vergleich mit unabhängigen Residualprüfungen dokumentiert.
- Die endgültige neue Produktionsrevision ist auf Remote gepinnt, mit vollständiger Evidenz und einem **getrennten** Reaudit-Handoff.

**Wichtig:** Selbst wenn der Implementierungsworker alle Tests besteht, ist die neue materielle Korrektur noch **nicht unabhängig akzeptiert**. Sein zulässiger Beststatus ist `correction_ready_for_independent_reaudit`. `B1_repaired=true` oder `native_G3_MISOCP=qualified` darf erst ein **separater unabhängiger Reviewer** mit eigenen Oracles und explizit begrenztem Urteil setzen. Ein hartnäckiger echter Ressourcenlimitfall darf offengelegt werden, erlaubt aber keine Vollclosure.

**Keine Scope-Ausweitung:** `integer_optimality_proved=false`, `integer_globality=case_specific_partial`, `science_amendment_approved=false`, `independent_A3_5_accepted=false`, `A3_closed=false`, `AP4_ready=false`, `empirical_study_ready=false`, solange keine gesonderte neue Owner-/M3-/Gesamtabnahme vorliegt.

---

## 8. Veröffentlichungsartefakte — neue Pfade, keine Überschreibungen

Lege ein **einziges** revisionssicheres Ergebnispaket z. B. unter `reports/a3_7/b1_20261022/` an; wenn ein Pfad bereits belegt ist, verwende einen eindeutigen Suffix **innerhalb derselben Branch**. Erwarteter **Inhalt**, nicht vorgeschriebene mikrogranulare Dateistruktur:

1. **Fachlich-technischer Hauptbericht (Deutsch):** genaue Commit-/Solveridentität, reproduzierter Baselinefehler, Kausaldiagnose `ITERATION_LIMIT`, Alternativenabwägung, gewählter Lösungsweg und mathematisches Äquivalenzargument; klarer Vorher-/Nachher-Befund und Restgrenzen.
2. **Maschinenlesbarer Solververgleich:** alle registrierten Testfälle/Skalierungsarten, G0/G3, Run-IDs, Input-/Modellhashes, Status, Objective, Residuen, Iterations-/Node-Daten, zugehörige Verifikationsbefunde und kategorisierte Fehler/Abbrüche; ausdrücklich Gurobi/MOSEK-Capability-/Lizenz-/Integer-RSOC-Befunde und—bei tatsächlich nutzbarem Backend—feste Original-G3-Cross-Solver-Vergleiche.
3. **Cut-/Transformationsnachweis:** ursprüngliche und veränderte OA-Zeilen/RSOC-zu-Affine-Abbildungen, Normierung, Koeffizientenfilter-/Range-Diagnostik, Vorzeichen-/Dual-/Rundungsargument, positive und adversariale Cases.
4. **Reproduktionspaket:** tatsächliche Befehle und Exitcodes, Julia-/Paket-/Solveroptionen, Hash-/ZIP-Manifest, Rohlogs, Original- und neue Modell-/Witnessreferenzen, Negativtests, eindeutig benannte Testordner. Archive nur additiv, keine Neupublikation unveränderter sehr großer Eingänge ohne Bedarf.
5. **Produktionsdiff/Regression:** betroffene Dateien, Before/After-Gleichungen, ausschließliche Solver-/Numerikänderungen, unveränderte wissenschaftliche Formulierungen und vollständige Regression mit frischen Zahlen statt Kopien alter PASS-Flags.
6. **Reaudit-Handoff und Status-YAML:** genaue neue Prüf-SHA, Kandidatenstatus, Grenzen und zu überprüfende Pflichtfälle für den **neuen** unabhängigen `A3.7-B1-REVIEWER`. Niemals eine eigene Korrektur selbst endgültig abnehmen.

Nutze sprechende Dateinamen und SHA256-Herkunft. Der Remote-Final-SHA kann nach einem Push separat im Abschlussbericht/Chat verifiziert werden; keine selbstreferenzierende Selbst-SHA in unveränderlichen Manifesteinträgen erfinden.

---

## 9. Autonomie, Priorisierung und geschützte Stop-Bedingungen

**Keine Mikroschritt-Rückfragen.** Du darfst selbständig relevante Quellstellen suchen, die fachlich beste Strategie auswählen, Hilfsprogramme schreiben, schlüssige Regressionen bündeln, einen notwendigen zusammenhängenden Fix implementieren, lokal diagnostizieren und die neue Branch veröffentlichen. Es werden keine vorgeschriebenen Zeilenänderungen, festen Reihenfolgen von Solveroptionen oder künstlichen Zeitlimits als Ersatz für deine fachliche Entscheidung auferlegt.

**Arbeite zielorientiert, nicht in endlosen Iterationsschleifen:** Führe zunächst einen belastbaren Baseline- und Optionsvergleich durch, entscheide dich für den stärksten nachweisbaren Lösungsweg, implementiere einen kohärenten Fix und absolviere eine zusammenhängende Validierung. Wenn diese einen konkreten Fehler aufdeckt, korrigiere ihn gezielt **innerhalb desselben Makroauftrags und derselben Branch**. Keine fortlaufenden Zwischenfreigaben beim Nutzer und keine neuen Micro-Prompts. Bei fundamentaler Blockade einen vollständigen Fehlernachweis und nächste entscheidbare Maßnahme liefern statt Schein-Fix.

**Sofortige Schutzstopps für destruktive Arbeiten:** fremder Dirty Worktree, Branch-/Parentkonflikt ohne sichere Lösung, fehlender verifizierbarer Modellinput, geänderte Theorem-/Integer-/Objective-Semantik, unerklärte SHA-Differenz, unhaltbare Cut-Gültigkeit oder fehlender notwendiger Prüforacle. Die Nichtverfügbarkeit **eines einzelnen** Solver-/Lizenzpfades ist dagegen nur für diesen Pfad ein Stop und darf die anderen Solverstrategien nicht verhindern. Bereits erlaubte read-only-/mathematische Analysen und Dokumentation nach Möglichkeit abschließen; Stopper konkret nachweisen. Keine Toleranzlockerung, Fake-Lizenzen, manipulierten Statusflags, alten Archiveingriffe oder zweckwidrige Modellmodifikationen.

**Kein automatischer PR, Merge, Reset, Rebase, Stash, Force-Push oder neue Worktrees.** Producer und `research-map` nicht verändern.

---

## 10. Ergebnisklassen und Abgabe

Liefere genau **eine** Gesamteinstufung:

- `m2_implementation_verdict: correction_ready_for_independent_reaudit` — fachlich belastbarer, getesteter und veröffentlichter Fix, **noch ohne personell unabhängige Schlussabnahme**;
- `m2_implementation_verdict: partial_with_explicit_limits` — ein wesentlicher Teilproblembeitrag wurde belegt, aber B1 bleibt offen;
- `m2_implementation_verdict: blocked_environment_or_inputs` — sichere Ausführung war nachweislich nicht möglich;
- `m2_implementation_verdict: no_defensible_fix` — untersuchte Lösungswege bestehen die Mathematik-/Solverprüfung nicht; dokumentiere reproduzierbar, warum.

Der finale deutschsprachige Handoff beantwortet ausdrücklich:

1. **Was** verursacht nach der akzeptierten `1e-12`-Korrektur die verbleibenden Default- und Doppeldivisor-`ITERATION_LIMIT`-Fälle?
2. **Welcher** Solver-/Skalierungsansatz wurde gewählt und weshalb ist er auf der deklarierten Modellklasse mathematisch äquivalent und numerisch kontrolliert?
3. **Welche** Fälle, Koeffizientengrenzen und Statuspfade wurden tatsächlich neu ausgeführt, welche nicht?
4. **Welche** ursprünglichen Daten, Gleichungen, Integerdomänen, Ziele, rationalen Kostenintervalle und historischen Archive blieben byte- bzw. semantisch unverändert?
5. **Welche** konkreten neuen Commits, Hashes, Outputs und Original-Residual-/Cutbeweise kann der unabhängige Reaudit ohne Vertrauen in Implementierer-PASS nachrechnen?
6. **Welche** Bedingungen bleiben für `B1_repaired=true`, M3, A3.5-Gesamtabschluss und AP4 offen?

**Erlaubter Implementierer-Endzustand ohne neuen unabhängigen Reaudit:**

```yaml
science_amendment_approved: false
owner_ratification: pending
production_correction_A3_6_scoped_accepted: true
m2_new_correction_independent_reaudit: pending
B1_repaired: false
native_G3_MISOCP: numerical_inconclusive
m2_technical_candidate_for_reaudit: true  # nur bei erfolgreich dokumentierter Implementierung
integer_bounds_proved: true  # nur neun bisher akzeptierte, normalisierte Intervalle
integer_optimality_proved: false
integer_globality: case_specific_partial
independent_A3_5_accepted: false
A3_closed: false
AP4_ready: false
empirical_study_ready: false
```

**Schlussregel:** Beweise einen realen Qualitätsgewinn des tatsächlichen Solverpfads, nicht bloß eine Veränderung des Statusstrings. Erhalte die mathematische Semantik, die exakten bisherigen Zertifikate und die Git-Provenienz. Wenn ein zuverlässiger nativer B1-Abschluss nicht erreichbar ist, publiziere eine unabhängig überprüfbare, klar begrenzte Teilantwort — ohne zusätzliche Mikrorunden mit dem Auftraggeber.
